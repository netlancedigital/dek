import React, { useState } from "react";
import { cn } from "@/lib/utils";

interface ComparisonItem {
	left: string;
	right: string;
}

interface ComparisonTableProps {
	leftTitle?: string;
	rightTitle?: string;
	leftColor?: string;
	rightColor?: string;
	comparisonItems?: ComparisonItem[];
	backgroundColor?: string;
	containerBg?: string;
	enableAnimations?: boolean;
	onCellClick?: (side: "left" | "right", index: number, text: string) => void;
	className?: string;
}

const defaultItems: ComparisonItem[] = [
	{ left: "Focus on identity and values", right: "Focus on promotion and sales" },
	{ left: "Long-term strategy", right: "Short to mid-term campaigns" },
	{ left: "Builds emotional connection", right: "Drives immediate action" },
	{ left: "Defines who you are", right: "Communicates what you offer" },
	{ left: "Creates loyalty and trust", right: "Generates leads and conversions" },
	{ left: "Consistent across all touchpoints", right: "Varies by campaign and channel" },
	{ left: "Shapes perception and reputation", right: "Measures ROI and performance" },
];

export function ComparisonTable({
	leftTitle = "Branding",
	rightTitle = "Marketing",
	leftColor = "#ee6f2d",
	rightColor = "#5dd5ed",
	comparisonItems = defaultItems,
	backgroundColor = "#1a1a2e",
	containerBg = "#16162a",
	enableAnimations = true,
	onCellClick,
	className,
}: ComparisonTableProps) {
	const [activeCell, setActiveCell] = useState<string | null>(null);

	const handleCellClick = (side: "left" | "right", index: number, text: string) => {
		setActiveCell(`${side}-${index}`);
		onCellClick?.(side, index, text);
		setTimeout(() => setActiveCell(null), 200);
	};

	return (
		<div
			className={cn(
				"w-full max-w-4xl mx-auto p-4 sm:p-6 lg:p-8 rounded-2xl",
				enableAnimations && "animate-fade-in-up",
				className
			)}
			style={{ backgroundColor }}
		>
			{/* Header Pills */}
			<div className="flex justify-center gap-4 sm:gap-8 mb-6 sm:mb-8">
				<div
					className={cn(
						"px-6 sm:px-10 py-2.5 sm:py-3 rounded-full text-white font-bold text-base sm:text-lg shadow-lg cursor-pointer transition-all duration-300 hover:-translate-y-1 hover:shadow-xl",
						enableAnimations && "animate-slide-down-left"
					)}
					style={{ backgroundColor: leftColor }}
				>
					{leftTitle}
				</div>
				<div
					className={cn(
						"px-6 sm:px-10 py-2.5 sm:py-3 rounded-full text-white font-bold text-base sm:text-lg shadow-lg cursor-pointer transition-all duration-300 hover:-translate-y-1 hover:shadow-xl",
						enableAnimations && "animate-slide-down-right"
					)}
					style={{ backgroundColor: rightColor }}
				>
					{rightTitle}
				</div>
			</div>

			{/* Comparison Grid */}
			<div className="rounded-xl overflow-hidden" style={{ backgroundColor: containerBg }}>
				{comparisonItems.map((item, index) => (
					<div
						key={index}
						className={cn(
							"grid grid-cols-2 border-b border-white/10 last:border-b-0",
							enableAnimations && "animate-row-cascade"
						)}
						style={enableAnimations ? { animationDelay: `${0.3 + index * 0.1}s` } : undefined}
					>
						{/* Left Cell */}
						<div
							className={cn(
								"p-3 sm:p-4 lg:p-5 border-r border-white/10 cursor-pointer transition-all duration-300 group",
								"hover:bg-white/5 hover:translate-x-1",
								activeCell === `left-${index}` && "bg-white/10"
							)}
							onClick={() => handleCellClick("left", index, item.left)}
						>
							<div className="flex items-start gap-2 sm:gap-3">
								<span
									className="inline-block w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-sm mt-1.5 flex-shrink-0 transition-all duration-300 group-hover:scale-150 group-hover:rotate-45 group-hover:rounded-full"
									style={{ backgroundColor: leftColor }}
								/>
								<span className="text-white/90 text-xs sm:text-sm lg:text-base leading-relaxed group-hover:text-white transition-colors">
									{item.left}
								</span>
							</div>
						</div>

						{/* Right Cell */}
						<div
							className={cn(
								"p-3 sm:p-4 lg:p-5 cursor-pointer transition-all duration-300 group",
								"hover:bg-white/5 hover:translate-x-1",
								activeCell === `right-${index}` && "bg-white/10"
							)}
							onClick={() => handleCellClick("right", index, item.right)}
						>
							<div className="flex items-start gap-2 sm:gap-3">
								<span
									className="inline-block w-2 h-2 sm:w-2.5 sm:h-2.5 rounded-sm mt-1.5 flex-shrink-0 transition-all duration-300 group-hover:scale-150 group-hover:rotate-45 group-hover:rounded-full"
									style={{ backgroundColor: rightColor }}
								/>
								<span className="text-white/90 text-xs sm:text-sm lg:text-base leading-relaxed group-hover:text-white transition-colors">
									{item.right}
								</span>
							</div>
						</div>
					</div>
				))}
			</div>

			{/* Footer */}
			<div className="mt-4 sm:mt-6 text-center">
				<p className="text-white/40 text-xs sm:text-sm">
					Click any item to learn more
				</p>
			</div>
		</div>
	);
}

export default ComparisonTable;

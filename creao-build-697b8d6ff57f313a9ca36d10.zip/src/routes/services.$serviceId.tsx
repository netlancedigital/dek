import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronLeft, ChevronRight, Palette, RotateCcw } from "lucide-react";
import { useState } from "react";
import emailjs from "@emailjs/browser";
import { ComparisonTable } from "@/components/ComparisonTable";

export const Route = createFileRoute("/services/$serviceId")({
	component: ServicePage,
});

const servicesData: Record<
	string,
	{
		name: string;
		description: string;
		features: string[];
		serviceOptions: string[];
		serviceLabel: string;
	}
> = {
	"music-promotion": {
		name: "Music Promotion",
		description:
			"Get your music heard by the right audience. We use targeted strategies to promote your tracks across multiple platforms, ensuring maximum reach and engagement.",
		features: [
			"Targeted playlist placements",
			"Social media campaigns",
			"Influencer partnerships",
			"Radio promotion",
			"Press coverage",
		],
		serviceOptions: [
			"Playlist Placements",
			"Social Media Campaigns",
			"Influencer Marketing",
			"Radio Promotion",
			"Press Coverage",
			"Others",
		],
		serviceLabel: "Music Promotion Service",
	},
	"youtube-growth": {
		name: "YouTube Video Promotion",
		description:
			"Promote your YouTube videos and increase views & subscribers through our distributed publisher network. Starting from just $10, get your content discovered by passionate audiences across social networks, blogs, websites, games, and mobile apps.",
		features: [
			"Multi-platform video distribution",
			"Real-time campaign monitoring",
			"Targeted audience selection",
			"Social network promotion",
			"Blog & website placements",
			"Mobile app exposure",
			"Quality-focused reach",
			"Trusted publisher network",
		],
		serviceOptions: [
			"Video Promotion",
			"Channel Growth",
			"Subscribers",
			"Views Campaign",
			"Engagement Boost",
			"Targeted Ads",
			"Others",
		],
		serviceLabel: "YouTube Promotion Service",
	},
	"marketing-and-branding": {
		name: "Branding vs Marketing",
		description:
			"Understand the key differences between branding and marketing strategies. Use our interactive comparison tool to explore how each approach can benefit your music career.",
		features: [
			"Brand identity focus",
			"Marketing strategy comparison",
			"Long-term vs short-term",
			"Organic vs Paid growth",
			"Spotify vs YouTube",
		],
		serviceOptions: [
			"Brand Identity Design",
			"Visual Content Creation",
			"Marketing Strategy",
			"Campaign Management",
			"Analytics & Reporting",
			"Others",
		],
		serviceLabel: "Marketing & Branding Service",
	},
	"playlist-pitching": {
		name: "Playlist Pitching",
		description:
			"Get your music featured on popular playlists across Spotify, Apple Music, and other streaming platforms. We connect you with curators who love discovering new music.",
		features: [
			"Spotify playlist pitching",
			"Apple Music placements",
			"Independent curator outreach",
			"Genre-specific targeting",
			"Performance tracking",
		],
		serviceOptions: [
			"Spotify Playlists",
			"Apple Music Playlists",
			"Independent Curators",
			"Genre-Specific Targeting",
			"Performance Tracking",
			"Others",
		],
		serviceLabel: "Playlist Pitching Service",
	},
	"music-distribution": {
		name: "Music Distribution",
		description:
			"Upload your music to 200+ streaming platforms worldwide including Spotify, Apple Music, Amazon Music, TikTok, YouTube Music, Beatport, Deezer, TIDAL, and more. Keep 100% of your royalties with our transparent distribution service.",
		features: [
			"200+ platforms worldwide",
			"100% royalty retention",
			"Full Control Over Your Music",
			"Spotify & Apple Music pitching",
			"Release scheduling & pre-saves",
		],
		serviceOptions: [
			"Single Distribution",
			"EP Distribution",
			"Album Distribution",
			"Beatport & Traxsource",
			"YouTube Content ID",
			"Spotify Editorial Pitching",
			"Apple Music Pitching",
			"Others",
		],
		serviceLabel: "Music Distribution Service",
	},
	"social-media-growth": {
		name: "Social Media Growth",
		description:
			"Build your presence across TikTok, Instagram, Facebook, and more. We help you create engaging content and grow your follower base organically.",
		features: [
			"Content strategy",
			"Engagement optimization",
			"Hashtag research",
			"Cross-platform growth",
			"Community management",
		],
		serviceOptions: [
			"TikTok Growth",
			"Instagram Growth",
			"Facebook Growth",
			"X (Twitter) Growth",
			"Content Strategy",
			"Community Management",
			"Others",
		],
		serviceLabel: "Social Media Service",
	},
};

function ServicePage() {
	const { serviceId } = Route.useParams();
	const service = servicesData[serviceId];

	// Form state for service orders
	const [formData, setFormData] = useState({
		name: "",
		phone: "",
		email: "",
		services: [] as string[],
		otherServices: "",
		engagementTypes: [] as string[],
		otherEngagement: "",
		engagementQuantity: 0,
		url: "",
		budget: "",
		customBudget: "",
		fileName: "",
		file: null as File | null,
	});

	const [formErrors, setFormErrors] = useState({
		otherServices: false,
		customBudget: false,
		engagementType: false,
		otherEngagement: false,
		socialUrl: false,
		engagementQuantity: false,
	});

	// Check if this is the Social Media Growth page
	const isSocialMediaGrowth = serviceId === "social-media-growth";

	// Social media platforms that require engagement type selection
	const socialPlatforms = [
		"TikTok Growth",
		"Instagram Growth",
		"Facebook Growth",
		"X (Twitter) Growth",
	];

	// Check if any social platform is selected (for Social Media Growth page)
	const hasSocialPlatformSelected =
		serviceId === "social-media-growth" &&
		formData.services.some((s) => socialPlatforms.includes(s));

	const engagementOptions = ["Followers", "Likes", "Views", "Others"];

	// Pricing in USD per 500 units (except comments which is per 5)
	// USD to UGX exchange rate (approximate)
	const USD_TO_UGX = 3700;

	// Pricing in USD (different units for different services)
	const pricingPerUnit = {
		followers: 3, // $3 per 500 followers
		likes: 0.8, // $0.8 per 500 likes
		views: 1, // $1 per 500 views
		shares: 1, // $1 per 500 shares
		saves: 0.5, // $0.5 per 100 saves
		comments: 1, // $1 per 5 comments (special case)
	};

	// Detect custom service type from otherEngagement text
	const getCustomServiceType = (): "shares" | "comments" | "saves" | null => {
		const text = formData.otherEngagement.toLowerCase().trim();
		if (text.includes("share")) return "shares";
		if (text.includes("comment")) return "comments";
		if (text.includes("save")) return "saves";
		return null;
	};

	const customServiceType = getCustomServiceType();

	// Check if comments is the custom service (needs different slider: 0-50, step 5)
	const isCommentsService = customServiceType === "comments";

	// Check if saves is the custom service (needs different slider: 0-2000, step 400)
	const isSavesService = customServiceType === "saves";

	// Check if TikTok is selected
	const isTikTokSelected = formData.services.includes("TikTok Growth");

	// TikTok discount rules:
	// - Likes: 10% off for quantity > 2500, in 500 intervals (3000, 3500, 4000, etc.)
	// - Views: 10% off for quantity > 1000, in 1000 intervals (2000, 3000, 4000, etc.)
	// Note: Followers no longer have dedicated discounts
	const getTikTokDiscount = (
		type: "followers" | "likes" | "views",
		quantity: number
	): { hasDiscount: boolean; discountPercent: number } => {
		if (!isTikTokSelected) return { hasDiscount: false, discountPercent: 0 };

		if (type === "likes") {
			// 10% discount for > 2500, in 500 intervals
			if (quantity > 2500 && quantity % 500 === 0) {
				return { hasDiscount: true, discountPercent: 10 };
			}
		} else if (type === "views") {
			// 10% discount for > 1000, in 1000 intervals
			if (quantity > 1000 && quantity % 1000 === 0) {
				return { hasDiscount: true, discountPercent: 10 };
			}
		}

		return { hasDiscount: false, discountPercent: 0 };
	};

	// Calculate price in UGX
	const calculatePrice = (): {
		total: number;
		breakdown: {
			type: string;
			basePrice: number;
			discount: number;
			finalPrice: number;
		}[];
	} => {
		const breakdown: {
			type: string;
			basePrice: number;
			discount: number;
			finalPrice: number;
		}[] = [];
		const quantity = formData.engagementQuantity;

		if (quantity === 0) return { total: 0, breakdown: [] };

		// Calculate for each selected engagement type
		if (formData.engagementTypes.includes("Followers")) {
			const baseUSD = (quantity / 500) * pricingPerUnit.followers;
			const discountInfo = getTikTokDiscount("followers", quantity);
			const discountAmount = discountInfo.hasDiscount
				? baseUSD * (discountInfo.discountPercent / 100)
				: 0;
			const finalUSD = baseUSD - discountAmount;
			breakdown.push({
				type: "Followers",
				basePrice: Math.round(baseUSD * USD_TO_UGX),
				discount: Math.round(discountAmount * USD_TO_UGX),
				finalPrice: Math.round(finalUSD * USD_TO_UGX),
			});
		}
		if (formData.engagementTypes.includes("Likes")) {
			const baseUSD = (quantity / 500) * pricingPerUnit.likes;
			const discountInfo = getTikTokDiscount("likes", quantity);
			const discountAmount = discountInfo.hasDiscount
				? baseUSD * (discountInfo.discountPercent / 100)
				: 0;
			const finalUSD = baseUSD - discountAmount;
			breakdown.push({
				type: "Likes",
				basePrice: Math.round(baseUSD * USD_TO_UGX),
				discount: Math.round(discountAmount * USD_TO_UGX),
				finalPrice: Math.round(finalUSD * USD_TO_UGX),
			});
		}
		if (formData.engagementTypes.includes("Views")) {
			const baseUSD = (quantity / 500) * pricingPerUnit.views;
			const discountInfo = getTikTokDiscount("views", quantity);
			const discountAmount = discountInfo.hasDiscount
				? baseUSD * (discountInfo.discountPercent / 100)
				: 0;
			const finalUSD = baseUSD - discountAmount;
			breakdown.push({
				type: "Views",
				basePrice: Math.round(baseUSD * USD_TO_UGX),
				discount: Math.round(discountAmount * USD_TO_UGX),
				finalPrice: Math.round(finalUSD * USD_TO_UGX),
			});
		}

		// Handle custom services (no TikTok discounts for these)
		if (formData.engagementTypes.includes("Others") && customServiceType) {
			let baseUSD = 0;
			let typeName = "";
			if (customServiceType === "comments") {
				baseUSD = (quantity / 5) * pricingPerUnit.comments;
				typeName = "Comments";
			} else if (customServiceType === "shares") {
				baseUSD = (quantity / 500) * pricingPerUnit.shares;
				typeName = "Shares";
			} else if (customServiceType === "saves") {
				baseUSD = (quantity / 100) * pricingPerUnit.saves;
				typeName = "Saves";
			}
			if (typeName) {
				breakdown.push({
					type: typeName,
					basePrice: Math.round(baseUSD * USD_TO_UGX),
					discount: 0,
					finalPrice: Math.round(baseUSD * USD_TO_UGX),
				});
			}
		}

		const total = breakdown.reduce((sum, item) => sum + item.finalPrice, 0);
		return { total, breakdown };
	};

	const priceInfo = calculatePrice();
	const totalPriceUGX = priceInfo.total;

	// Format UGX currency
	const formatUGX = (amount: number): string => {
		return `UGX ${amount.toLocaleString()}`;
	};

	// URL validation for social media platforms
	const validateSocialMediaUrl = (url: string): { valid: boolean; message: string } => {
		if (!url.trim()) {
			return { valid: false, message: "Please enter a valid social media URL" };
		}

		const selectedPlatforms = formData.services.filter((s) =>
			socialPlatforms.includes(s)
		);
		const hasLikes = formData.engagementTypes.includes("Likes");
		const hasViews = formData.engagementTypes.includes("Views");
		const hasFollowers = formData.engagementTypes.includes("Followers");
		const hasTikTok = selectedPlatforms.includes("TikTok Growth");

		// For TikTok: Likes requires a video/post URL (not profile)
		// For other platforms: Likes can use profile URL
		const needsVideoUrl = hasViews || (hasTikTok && hasLikes);
		const needsProfileUrl = hasFollowers || (hasLikes && !hasTikTok);

		// Platform-specific URL patterns
		const urlPatterns: Record<string, { profile: RegExp; video: RegExp }> = {
			"TikTok Growth": {
				profile: /^https?:\/\/(www\.)?(tiktok\.com\/@[\w.-]+|vm\.tiktok\.com\/[\w]+)/i,
				video: /^https?:\/\/(www\.)?(tiktok\.com\/@[\w.-]+\/video\/\d+|vm\.tiktok\.com\/[\w]+|tiktok\.com\/t\/[\w]+)/i,
			},
			"Instagram Growth": {
				profile: /^https?:\/\/(www\.)?instagram\.com\/[\w.-]+\/?$/i,
				video: /^https?:\/\/(www\.)?instagram\.com\/(p|reel|tv)\/[\w-]+/i,
			},
			"Facebook Growth": {
				profile: /^https?:\/\/(www\.)?(facebook\.com|fb\.com)\/(profile\.php\?id=\d+|[\w.-]+)\/?$/i,
				video: /^https?:\/\/(www\.)?(facebook\.com|fb\.com)\/(watch\/?\?v=\d+|[\w.-]+\/videos\/\d+|reel\/\d+)/i,
			},
			"X (Twitter) Growth": {
				profile: /^https?:\/\/(www\.)?(twitter\.com|x\.com)\/[\w]+\/?$/i,
				video: /^https?:\/\/(www\.)?(twitter\.com|x\.com)\/[\w]+\/status\/\d+/i,
			},
		};

		// Check if URL matches any selected platform
		for (const platform of selectedPlatforms) {
			const patterns = urlPatterns[platform];
			if (!patterns) continue;

			// Special handling for TikTok + Likes: must be a video URL
			if (platform === "TikTok Growth" && hasLikes && !hasViews && !hasFollowers) {
				if (patterns.video.test(url)) {
					return { valid: true, message: "" };
				}
				// Don't check profile for TikTok Likes
				continue;
			}

			if (needsVideoUrl && patterns.video.test(url)) {
				return { valid: true, message: "" };
			}
			if (needsProfileUrl && patterns.profile.test(url)) {
				return { valid: true, message: "" };
			}
			// If "Others" engagement is selected, accept either profile or video URL
			if (formData.engagementTypes.includes("Others")) {
				if (patterns.profile.test(url) || patterns.video.test(url)) {
					return { valid: true, message: "" };
				}
			}
		}

		// Build error message based on what's needed
		// Special message for TikTok Likes
		if (hasTikTok && hasLikes && selectedPlatforms.length === 1) {
			return {
				valid: false,
				message: "Please enter a valid TikTok video/post URL (for Likes)",
			};
		}
		if (needsVideoUrl && needsProfileUrl) {
			return {
				valid: false,
				message: `Please enter a valid ${selectedPlatforms.map((p) => p.replace(" Growth", "")).join("/")} profile or video URL`,
			};
		}
		if (needsVideoUrl) {
			return {
				valid: false,
				message: `Please enter a valid ${selectedPlatforms.map((p) => p.replace(" Growth", "")).join("/")} video URL (for Views/Likes)`,
			};
		}
		if (needsProfileUrl) {
			return {
				valid: false,
				message: `Please enter a valid ${selectedPlatforms.map((p) => p.replace(" Growth", "")).join("/")} profile/page URL (for Followers/Likes)`,
			};
		}

		return {
			valid: false,
			message: `Please enter a valid ${selectedPlatforms.map((p) => p.replace(" Growth", "")).join("/")} URL`,
		};
	};

	// Get dynamic URL label and placeholder for Social Media Growth
	const getSocialMediaUrlInfo = () => {
		const selectedPlatforms = formData.services.filter((s) =>
			socialPlatforms.includes(s)
		);
		const platformNames = selectedPlatforms.map((p) => p.replace(" Growth", "")).join("/");
		const hasLikes = formData.engagementTypes.includes("Likes");
		const hasViews = formData.engagementTypes.includes("Views");
		const hasFollowers = formData.engagementTypes.includes("Followers");
		const hasTikTok = selectedPlatforms.includes("TikTok Growth");

		// For TikTok: Likes requires a video/post URL (not profile)
		const needsVideoUrl = hasViews || (hasTikTok && hasLikes);
		const needsProfileUrl = hasFollowers || (hasLikes && !hasTikTok);

		// Special case: TikTok only with Likes
		if (hasTikTok && hasLikes && !hasViews && !hasFollowers && selectedPlatforms.length === 1) {
			return {
				label: "TikTok Video/Post URL",
				placeholder: "Enter a valid TikTok video URL (for Likes)",
			};
		}

		if (needsVideoUrl && needsProfileUrl) {
			return {
				label: `${platformNames} Profile or Video URL`,
				placeholder: `Enter your ${platformNames} profile or video URL`,
			};
		}
		if (needsVideoUrl) {
			return {
				label: `${platformNames} Video URL`,
				placeholder: `Enter your ${platformNames} video URL (for Views/Likes)`,
			};
		}
		if (needsProfileUrl) {
			return {
				label: `${platformNames} Profile/Page URL`,
				placeholder: `Enter your ${platformNames} profile or page URL`,
			};
		}
		return {
			label: `${platformNames} URL`,
			placeholder: `Enter your ${platformNames} URL`,
		};
	};

	const [socialUrlError, setSocialUrlError] = useState("");

	const handleServiceToggle = (serviceName: string) => {
		setFormData((prev) => {
			const newServices = prev.services.includes(serviceName)
				? prev.services.filter((s) => s !== serviceName)
				: [...prev.services, serviceName];

			// Clear otherServices if Others is deselected
			if (serviceName === "Others" && prev.services.includes("Others")) {
				return { ...prev, services: newServices, otherServices: "" };
			}

			// Clear engagement types if all social platforms are deselected
			if (socialPlatforms.includes(serviceName)) {
				const remainingSocialPlatforms = newServices.filter((s) =>
					socialPlatforms.includes(s)
				);
				if (remainingSocialPlatforms.length === 0) {
					return {
						...prev,
						services: newServices,
						engagementTypes: [],
						otherEngagement: "",
					};
				}
			}

			return { ...prev, services: newServices };
		});

		// Clear error when Others is deselected
		if (serviceName === "Others") {
			setFormErrors((prev) => ({ ...prev, otherServices: false }));
		}

		// Clear engagement errors when social platform is deselected
		if (socialPlatforms.includes(serviceName)) {
			setFormErrors((prev) => ({
				...prev,
				engagementType: false,
				otherEngagement: false,
			}));
		}
	};

	const handleEngagementToggle = (engagementType: string) => {
		setFormData((prev) => {
			const newEngagementTypes = prev.engagementTypes.includes(engagementType)
				? prev.engagementTypes.filter((e) => e !== engagementType)
				: [...prev.engagementTypes, engagementType];

			// Clear otherEngagement if Others is deselected
			if (
				engagementType === "Others" &&
				prev.engagementTypes.includes("Others")
			) {
				return { ...prev, engagementTypes: newEngagementTypes, otherEngagement: "" };
			}
			return { ...prev, engagementTypes: newEngagementTypes };
		});

		// Clear errors when engagement type changes
		setFormErrors((prev) => ({
			...prev,
			engagementType: false,
			otherEngagement: engagementType === "Others" ? false : prev.otherEngagement,
		}));
	};

	const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		const file = e.target.files?.[0];
		if (file) {
			setFormData((prev) => ({ ...prev, fileName: file.name, file: file }));
		}
	};

	// Share files via Web Share API (for mobile devices)
	const shareFileViaWebShare = async (file: File, messageText: string) => {
		// Check if Web Share API with files is supported
		if (navigator.share && navigator.canShare && navigator.canShare({ files: [file] })) {
			try {
				await navigator.share({
					text: messageText.replace(/%0A/g, "\n"),
					files: [file],
				});
				return true;
			} catch (err) {
				// User cancelled or error occurred
				console.log("Web Share cancelled or failed:", err);
				return false;
			}
		}
		return false;
	};

	// EmailJS configuration - Replace these with your actual EmailJS credentials
	const EMAILJS_SERVICE_ID = "service_troydigital";
	const EMAILJS_TEMPLATE_ID = "template_confirmation";
	const EMAILJS_PUBLIC_KEY = "YOUR_EMAILJS_PUBLIC_KEY";

	// Send confirmation email to user
	const sendConfirmationEmail = async (emailData: {
		to_email: string;
		to_name: string;
		inquiry_type: string;
		order_details: string;
	}) => {
		try {
			await emailjs.send(
				EMAILJS_SERVICE_ID,
				EMAILJS_TEMPLATE_ID,
				{
					to_email: emailData.to_email,
					to_name: emailData.to_name,
					inquiry_type: emailData.inquiry_type,
					order_details: emailData.order_details,
					company_name: "Troy Digital Desk",
					company_website: "troydigitaldesk.online",
					reply_to: "info@troydigitaldesk.online",
				},
				EMAILJS_PUBLIC_KEY
			);
			return true;
		} catch {
			console.error("Failed to send confirmation email");
			return false;
		}
	};

	const handleSubmitOrder = async () => {
		// Validation
		const hasOthersSelected = formData.services.includes("Others");
		const hasCustomSelected = formData.budget === "Custom";
		const otherServicesError =
			hasOthersSelected && !formData.otherServices.trim();
		const customBudgetError =
			!isSocialMediaGrowth && hasCustomSelected && !formData.customBudget.trim();

		// Engagement type validation for Social Media Growth
		const engagementTypeError =
			hasSocialPlatformSelected && formData.engagementTypes.length === 0;
		const hasOtherEngagementSelected =
			formData.engagementTypes.includes("Others");
		const otherEngagementError =
			hasOtherEngagementSelected && !formData.otherEngagement.trim();

		// Social media URL validation
		let socialUrlError = false;
		if (hasSocialPlatformSelected && formData.engagementTypes.length > 0) {
			const urlValidation = validateSocialMediaUrl(formData.url);
			if (!urlValidation.valid) {
				socialUrlError = true;
				setSocialUrlError(urlValidation.message);
			} else {
				setSocialUrlError("");
			}
		}

		// Quantity validation for Social Media Growth
		const hasQuantifiableEngagement =
			formData.engagementTypes.some((t) =>
				["Followers", "Likes", "Views"].includes(t)
			) ||
			(formData.engagementTypes.includes("Others") && customServiceType !== null);
		const engagementQuantityError =
			hasSocialPlatformSelected &&
			hasQuantifiableEngagement &&
			formData.engagementQuantity === 0;

		if (
			otherServicesError ||
			customBudgetError ||
			engagementTypeError ||
			otherEngagementError ||
			socialUrlError ||
			engagementQuantityError
		) {
			setFormErrors({
				otherServices: otherServicesError,
				customBudget: customBudgetError,
				engagementType: engagementTypeError,
				otherEngagement: otherEngagementError,
				socialUrl: socialUrlError,
				engagementQuantity: engagementQuantityError,
			});
			return;
		}

		const selectedServices = formData.services.includes("Others")
			? [...formData.services.filter((s) => s !== "Others"), `Others: ${formData.otherServices}`].join(", ")
			: formData.services.join(", ") || "None selected";
		const urlInfo = formData.url || "Not provided";

		// Build engagement types info for Social Media Growth
		let engagementInfo = "";
		let quantityInfo = "";
		let priceInfo = "";
		let engagementList = "";
		if (hasSocialPlatformSelected && formData.engagementTypes.length > 0) {
			engagementList = formData.engagementTypes.includes("Others")
				? [...formData.engagementTypes.filter((e) => e !== "Others"), `Others: ${formData.otherEngagement}`].join(", ")
				: formData.engagementTypes.join(", ");
			engagementInfo = `%0A*Engagement Type:* ${engagementList}`;

			// Add quantity if applicable
			const hasQuantifiableService =
				formData.engagementTypes.some((t) =>
					["Followers", "Likes", "Views"].includes(t)
				) ||
				(formData.engagementTypes.includes("Others") && customServiceType);

			if (hasQuantifiableService && formData.engagementQuantity > 0) {
				quantityInfo = `%0A*Quantity:* ${formData.engagementQuantity.toLocaleString()}`;
				priceInfo = `%0A*Total Price:* ${formatUGX(totalPriceUGX)}`;
			}
		}

		// Build message based on service type
		let message: string;
		let emailOrderDetails: string;

		if (isSocialMediaGrowth) {
			// Social Media Growth - no budget or file fields, includes pricing
			message = `*${service.name} Service Order*%0A%0A*Name:* ${formData.name}%0A*Phone:* ${formData.phone}%0A*Email:* ${formData.email}%0A*Services:* ${selectedServices}${engagementInfo}${quantityInfo}${priceInfo}%0A*URL:* ${urlInfo}`;

			// Build email order details
			emailOrderDetails = `Service: ${service.name}\n\n`;
			emailOrderDetails += `Name: ${formData.name}\n`;
			emailOrderDetails += `Phone: ${formData.phone}\n`;
			emailOrderDetails += `Email: ${formData.email}\n`;
			emailOrderDetails += `Selected Services: ${selectedServices}\n`;
			if (engagementList) {
				emailOrderDetails += `Engagement Type: ${engagementList}\n`;
			}
			if (formData.engagementQuantity > 0) {
				emailOrderDetails += `Quantity: ${formData.engagementQuantity.toLocaleString()}\n`;
				emailOrderDetails += `Total Price: ${formatUGX(totalPriceUGX)}\n`;
			}
			emailOrderDetails += `URL: ${urlInfo}\n`;
		} else {
			// Other services - include budget and file
			const fileInfo = formData.fileName ? formData.fileName : "No file attached";
			const budgetInfo =
				formData.budget === "Custom"
					? `Custom: ${formData.customBudget}`
					: formData.budget || "Not selected";

			// Add note about file being shared separately if there's a file
			const fileNote = formData.file ? `%0A_(File will be shared separately after this message)_` : "";
			message = `*${service.name} Service Order*%0A%0A*Name:* ${formData.name}%0A*Phone:* ${formData.phone}%0A*Email:* ${formData.email}%0A*Services:* ${selectedServices}${engagementInfo}%0A*URL:* ${urlInfo}%0A*Budget:* ${budgetInfo}%0A*File:* ${fileInfo}${fileNote}`;

			// Build email order details
			emailOrderDetails = `Service: ${service.name}\n\n`;
			emailOrderDetails += `Name: ${formData.name}\n`;
			emailOrderDetails += `Phone: ${formData.phone}\n`;
			emailOrderDetails += `Email: ${formData.email}\n`;
			emailOrderDetails += `Selected Services: ${selectedServices}\n`;
			if (engagementList) {
				emailOrderDetails += `Engagement Type: ${engagementList}\n`;
			}
			emailOrderDetails += `URL: ${urlInfo}\n`;
			emailOrderDetails += `Budget: ${budgetInfo}\n`;
			emailOrderDetails += `File: ${fileInfo}\n`;
		}

		// Check if we have a file to share
		const hasFileToShare = !isSocialMediaGrowth && formData.file !== null;

		// Try to use Web Share API for files (works on mobile)
		if (hasFileToShare && formData.file) {
			const fileShared = await shareFileViaWebShare(formData.file, message);
			if (!fileShared) {
				// If Web Share failed or not supported, open WhatsApp with message first
				window.open(`https://wa.me/256701705378?text=${message}`, "_blank");

				// Show alert about manual file sharing
				setTimeout(() => {
					alert(
						`Your order has been sent to WhatsApp!\n\nTo send your file (${formData.fileName}):\n\n1. Open WhatsApp\n2. Go to the chat with Troy Digital Desk\n3. Tap the attachment icon (+)\n4. Select and send your file manually\n\nAlternatively, you can share via Google Drive, Dropbox, or any file sharing service and send the link.`
					);
				}, 500);
			}
		} else {
			// No file or social media growth, just open WhatsApp with the message
			window.open(`https://wa.me/256701705378?text=${message}`, "_blank");
		}

		// Send confirmation email to user
		await sendConfirmationEmail({
			to_email: formData.email,
			to_name: formData.name,
			inquiry_type: `${service.name} Service Order`,
			order_details: emailOrderDetails,
		});
	};

	const budgetOptions = ["$30", "$50", "$100", "$200", "$500", "Custom"];

	if (!service) {
		return (
			<div className="min-h-screen bg-zinc-950 text-white flex items-center justify-center px-4">
				<div className="text-center">
					<h1 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4">Service Not Found</h1>
					<Link
						to="/"
						className="text-[#BFFF00] hover:underline inline-flex items-center gap-2 text-sm sm:text-base"
					>
						<ChevronLeft className="size-4" />
						Back to Home
					</Link>
				</div>
			</div>
		);
	}

	// Special design for Music Distribution page (iMusician-inspired)
	if (serviceId === "music-distribution") {
		return (
			<div className="min-h-screen bg-white text-zinc-900 relative overflow-hidden">
				{/* Header */}
				<header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-zinc-200">
					<div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
						<div className="flex items-center justify-between">
							<Link
								to="/"
								className="flex items-center gap-2 text-zinc-600 hover:text-zinc-900 transition-colors"
							>
								<ChevronLeft className="size-5" />
								<span className="text-sm font-medium">Back to Home</span>
							</Link>
							<img
								src="https://troydigitaldesk.online/wp-content/uploads/2025/09/logo-top.png"
								alt="Troy Digital Desk"
								className="h-6 sm:h-8 w-auto"
							/>
							<div className="w-16" />
						</div>
					</div>
				</header>

				{/* Hero Section */}
				<div className="relative bg-gradient-to-br from-[#BFFF00]/10 via-white to-orange-50">
					<div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-[#BFFF00]/5 via-transparent to-transparent" />

					<div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-28">
						<div className="text-center max-w-4xl mx-auto">
							{/* Badge */}
							<div className="inline-flex items-center gap-2 bg-[#BFFF00]/20 border border-[#BFFF00]/50 rounded-full px-4 py-1.5 mb-6">
								<span className="size-2 bg-[#BFFF00] rounded-full" />
								<span className="text-zinc-700 text-xs sm:text-sm font-medium">Trusted by 1000+ Artists</span>
							</div>

							<h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-zinc-900 mb-6">
								Digital Music Distribution
							</h1>
							<p className="text-lg sm:text-xl md:text-2xl text-zinc-600 mb-4">
								Upload Your Music to <span className="text-[#BFFF00] font-bold">200+</span> Platforms
							</p>
							<p className="text-base sm:text-lg text-zinc-500 max-w-2xl mx-auto mb-8">
								Distribute your music worldwide to Spotify, Apple Music, Amazon, TikTok, YouTube Music, Beatport, Deezer, TIDAL and 200+ more stores and streaming services.
							</p>

							{/* CTA Buttons */}
							<div className="flex flex-col sm:flex-row gap-4 justify-center">
								<a
									href="#pricing"
									className="inline-flex items-center justify-center gap-2 bg-[#BFFF00] hover:bg-[#a8e600] text-zinc-900 font-semibold px-8 py-4 rounded-full transition-all hover:scale-105 shadow-lg shadow-[#BFFF00]/30"
								>
									Start Distributing
									<ChevronRight className="size-5" />
								</a>
								<a
									href="#how-it-works"
									className="inline-flex items-center justify-center gap-2 bg-white hover:bg-zinc-50 border border-zinc-300 text-zinc-700 font-medium px-8 py-4 rounded-full transition-all"
								>
									How It Works
								</a>
							</div>
						</div>
					</div>
				</div>

				{/* Platform Logos Section */}
				<div className="bg-zinc-900 py-12 sm:py-16">
					<div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
						<p className="text-center text-zinc-400 text-sm mb-8">Distribute to all major platforms worldwide</p>
						<div className="flex flex-wrap justify-center items-center gap-6 sm:gap-8 md:gap-12">
							{/* Spotify */}
							<div className="flex items-center gap-2 text-white opacity-80 hover:opacity-100 transition-opacity">
								<svg className="size-8 sm:size-10" viewBox="0 0 24 24" fill="currentColor">
									<path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/>
								</svg>
								<span className="text-sm font-medium hidden sm:block">Spotify</span>
							</div>
							{/* Apple Music */}
							<div className="flex items-center gap-2 text-white opacity-80 hover:opacity-100 transition-opacity">
								<svg className="size-8 sm:size-10" viewBox="0 0 24 24" fill="currentColor">
									<path d="M23.994 6.124a9.23 9.23 0 00-.24-2.19c-.317-1.31-1.062-2.31-2.18-3.043a5.022 5.022 0 00-1.877-.726 10.496 10.496 0 00-1.564-.15c-.04-.003-.083-.01-.124-.013H5.986c-.152.01-.303.017-.455.026-.747.043-1.49.123-2.193.401-1.336.53-2.3 1.452-2.865 2.78-.192.448-.292.925-.363 1.408-.056.392-.088.785-.1 1.18 0 .032-.007.062-.01.093v12.223c.01.14.017.283.027.424.05.815.154 1.624.497 2.373.65 1.42 1.738 2.353 3.234 2.801.42.127.856.187 1.293.228.555.053 1.11.06 1.667.06h11.03c.525 0 1.048-.034 1.57-.1.823-.106 1.597-.35 2.296-.81a5.046 5.046 0 001.88-2.207c.186-.42.293-.87.37-1.324.113-.675.138-1.358.137-2.04-.002-3.8 0-7.595-.003-11.393zm-6.423 3.99v5.712c0 .417-.058.827-.244 1.206-.29.59-.76.962-1.388 1.14-.35.1-.706.157-1.07.173-.95.042-1.785-.364-2.172-1.158-.39-.804-.245-1.773.397-2.388.41-.393.91-.63 1.46-.752.407-.09.823-.14 1.234-.217.29-.053.444-.207.476-.498.01-.075.01-.15.01-.224V8.373c0-.315-.117-.467-.43-.423-.164.023-.326.063-.49.096-1.35.27-2.7.538-4.05.81-.34.07-.477.222-.477.57v7.63c0 .4-.05.793-.214 1.166-.278.626-.757 1.033-1.415 1.22-.35.1-.71.163-1.074.178-.972.045-1.825-.334-2.23-1.164-.394-.807-.24-1.793.422-2.406.4-.37.873-.596 1.397-.72.407-.1.823-.16 1.236-.227.25-.04.413-.175.458-.42.015-.083.017-.168.017-.252V5.664c0-.354.134-.546.477-.623.265-.06.532-.108.8-.162l3.694-.74 2.097-.42c.24-.05.48-.1.722-.14.158-.027.263.053.3.207.02.083.025.17.025.254v6.074z"/>
								</svg>
								<span className="text-sm font-medium hidden sm:block">Apple Music</span>
							</div>
							{/* Amazon Music */}
							<div className="flex items-center gap-2 text-white opacity-80 hover:opacity-100 transition-opacity">
								<svg className="size-8 sm:size-10" viewBox="0 0 24 24" fill="currentColor">
									<path d="M13.958 10.09c0 1.232.029 2.256-.591 3.351-.502.891-1.301 1.438-2.186 1.438-1.214 0-1.922-.924-1.922-2.292 0-2.692 2.415-3.182 4.7-3.182v.685zm3.186 7.705a.66.66 0 01-.753.077c-1.058-.876-1.248-1.282-1.828-2.117-1.748 1.784-2.984 2.318-5.251 2.318-2.682 0-4.772-1.653-4.772-4.969 0-2.586 1.399-4.347 3.395-5.206 1.729-.754 4.145-.886 5.991-1.1v-.41c0-.755.058-1.647-.385-2.298-.385-.58-1.123-.82-1.77-.82-1.204 0-2.277.618-2.54 1.898-.054.285-.261.566-.549.58l-3.063-.333c-.259-.056-.545-.266-.472-.66C6.455 1.134 9.678 0 12.547 0c1.479 0 3.407.394 4.572 1.515 1.479 1.38 1.338 3.224 1.338 5.229v4.736c0 1.423.591 2.046 1.145 2.816.196.273.24.6-.01.803-.624.52-1.735 1.485-2.345 2.027l-.104-.33zm4.683-14.149C19.53 1.32 16.078 0 13.095 0 8.052 0 3.654 1.96.961 5.303-.227 6.64-.757 8.234.744 9.478c.87.723 2.277-.111 2.905-.913 1.93-2.467 5.192-4.041 8.462-4.041 2.004 0 3.994.522 5.707 1.497.62.352 1.3-.294 1.3-.294.854-.617 1.694-1.466 2.009-2.08z"/>
								</svg>
								<span className="text-sm font-medium hidden sm:block">Amazon</span>
							</div>
							{/* TikTok */}
							<div className="flex items-center gap-2 text-white opacity-80 hover:opacity-100 transition-opacity">
								<svg className="size-8 sm:size-10" viewBox="0 0 24 24" fill="currentColor">
									<path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/>
								</svg>
								<span className="text-sm font-medium hidden sm:block">TikTok</span>
							</div>
							{/* YouTube Music */}
							<div className="flex items-center gap-2 text-white opacity-80 hover:opacity-100 transition-opacity">
								<svg className="size-8 sm:size-10" viewBox="0 0 24 24" fill="currentColor">
									<path d="M12 0C5.376 0 0 5.376 0 12s5.376 12 12 12 12-5.376 12-12S18.624 0 12 0zm0 19.104c-3.924 0-7.104-3.18-7.104-7.104S8.076 4.896 12 4.896s7.104 3.18 7.104 7.104-3.18 7.104-7.104 7.104zm0-13.332c-3.432 0-6.228 2.796-6.228 6.228S8.568 18.228 12 18.228s6.228-2.796 6.228-6.228S15.432 5.772 12 5.772zM9.684 15.54V8.46L15.816 12l-6.132 3.54z"/>
								</svg>
								<span className="text-sm font-medium hidden sm:block">YouTube</span>
							</div>
							{/* Beatport */}
							<div className="flex items-center gap-2 text-white opacity-80 hover:opacity-100 transition-opacity">
								<svg className="size-8 sm:size-10" viewBox="0 0 24 24" fill="currentColor">
									<path d="M21.429 17.055c-.636 3.03-2.376 4.884-5.636 4.987-.143 0-.263-.012-.406-.012V13.5l5.79-5.791c.155.715.239 1.465.239 2.239.012 2.446-.716 4.893-1.987 7.107zM13.18 22.078c-.39.018-.787.024-1.18.024-6.627 0-12-5.373-12-12S5.373-1.898 12-1.898c.393 0 .79.006 1.18.024v23.952zM22.584 5.91l-4.5 4.499V.978c2.076.93 3.666 2.606 4.5 4.932zM2.572 12.048c0-4.689 3.407-8.58 7.88-9.336v18.684c-4.473-.768-7.88-4.659-7.88-9.348z"/>
								</svg>
								<span className="text-sm font-medium hidden sm:block">Beatport</span>
							</div>
							{/* Deezer */}
							<div className="flex items-center gap-2 text-white opacity-80 hover:opacity-100 transition-opacity">
								<svg className="size-8 sm:size-10" viewBox="0 0 24 24" fill="currentColor">
									<path d="M18.81 4.16v3.03H24V4.16h-5.19zM6.27 8.38v3.027h5.189V8.38h-5.19zm12.54 0v3.027H24V8.38h-5.19zM6.27 12.6v3.03h5.189v-3.03h-5.19zm6.271 0v3.03h5.19v-3.03h-5.19zm6.27 0v3.03H24v-3.03h-5.19zM0 16.83v3.03h5.19v-3.03H0zm6.27 0v3.03h5.189v-3.03h-5.19zm6.271 0v3.03h5.19v-3.03h-5.19zm6.27 0v3.03H24v-3.03h-5.19z"/>
								</svg>
								<span className="text-sm font-medium hidden sm:block">Deezer</span>
							</div>
							{/* TIDAL */}
							<div className="flex items-center gap-2 text-white opacity-80 hover:opacity-100 transition-opacity">
								<svg className="size-8 sm:size-10" viewBox="0 0 24 24" fill="currentColor">
									<path d="M12.012 3.992L8.008 7.996 4.004 3.992 0 7.996l4.004 4.004 4.004-4.004 4.004 4.004-4.004 4.004 4.004 4.004 4.004-4.004-4.004-4.004 4.004-4.004 4.004 4.004 4.004-4.004L20.02 3.992l-4.004 4.004z"/>
								</svg>
								<span className="text-sm font-medium hidden sm:block">TIDAL</span>
							</div>
						</div>
						<p className="text-center text-zinc-500 text-xs mt-6">+ 200 more platforms worldwide</p>
					</div>
				</div>

				{/* Key Features Section */}
				<div className="py-16 sm:py-20 bg-white">
					<div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
						<div className="text-center mb-12 sm:mb-16">
							<h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-zinc-900 mb-4">
								Everything You Need to <span className="text-[#BFFF00]">Succeed</span>
							</h2>
							<p className="text-zinc-600 text-base sm:text-lg max-w-2xl mx-auto">
								Our distribution service gives you all the tools to release your music professionally
							</p>
						</div>

						<div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
							{/* Feature 1 */}
							<div className="bg-zinc-50 rounded-2xl p-6 sm:p-8 border border-zinc-200 hover:border-[#BFFF00]/50 hover:shadow-lg hover:shadow-[#BFFF00]/10 transition-all">
								<div className="size-14 bg-[#BFFF00]/20 rounded-xl flex items-center justify-center mb-5">
									<svg className="size-7 text-[#BFFF00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
										<path strokeLinecap="round" strokeLinejoin="round" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
									</svg>
								</div>
								<h3 className="text-xl font-bold text-zinc-900 mb-3">200+ Platforms Worldwide</h3>
								<p className="text-zinc-600">
									Reach fans everywhere with distribution to Spotify, Apple Music, Amazon, TikTok, YouTube Music, Beatport, and 200+ more stores globally.
								</p>
							</div>

							{/* Feature 2 */}
							<div className="bg-zinc-50 rounded-2xl p-6 sm:p-8 border border-zinc-200 hover:border-[#BFFF00]/50 hover:shadow-lg hover:shadow-[#BFFF00]/10 transition-all">
								<div className="size-14 bg-[#BFFF00]/20 rounded-xl flex items-center justify-center mb-5">
									<svg className="size-7 text-[#BFFF00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
										<path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
									</svg>
								</div>
								<h3 className="text-xl font-bold text-zinc-900 mb-3">100% Royalty Retention</h3>
								<p className="text-zinc-600">
									Keep all your earnings. No commission on streaming royalties. You earned it, you keep it. Transparent pricing with no hidden fees.
								</p>
							</div>

							{/* Feature 3 */}
							<div className="bg-zinc-50 rounded-2xl p-6 sm:p-8 border border-zinc-200 hover:border-[#BFFF00]/50 hover:shadow-lg hover:shadow-[#BFFF00]/10 transition-all">
								<div className="size-14 bg-[#BFFF00]/20 rounded-xl flex items-center justify-center mb-5">
									<svg className="size-7 text-[#BFFF00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
										<path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
									</svg>
								</div>
								<h3 className="text-xl font-bold text-zinc-900 mb-3">Full Control Over Your Music</h3>
								<p className="text-zinc-600">
									You own your music. Edit, update, or remove your releases anytime. Complete control over your catalog with no restrictions.
								</p>
							</div>

							{/* Feature 4 */}
							<div className="bg-zinc-50 rounded-2xl p-6 sm:p-8 border border-zinc-200 hover:border-[#BFFF00]/50 hover:shadow-lg hover:shadow-[#BFFF00]/10 transition-all">
								<div className="size-14 bg-[#BFFF00]/20 rounded-xl flex items-center justify-center mb-5">
									<svg className="size-7 text-[#BFFF00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
										<path strokeLinecap="round" strokeLinejoin="round" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
									</svg>
								</div>
								<h3 className="text-xl font-bold text-zinc-900 mb-3">Editorial Playlist Pitching</h3>
								<p className="text-zinc-600">
									Get your music featured on Spotify and Apple Music editorial playlists with our built-in pitching tools for maximum exposure.
								</p>
							</div>

							{/* Feature 5 */}
							<div className="bg-zinc-50 rounded-2xl p-6 sm:p-8 border border-zinc-200 hover:border-[#BFFF00]/50 hover:shadow-lg hover:shadow-[#BFFF00]/10 transition-all">
								<div className="size-14 bg-[#BFFF00]/20 rounded-xl flex items-center justify-center mb-5">
									<svg className="size-7 text-[#BFFF00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
										<path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
									</svg>
								</div>
								<h3 className="text-xl font-bold text-zinc-900 mb-3">Release Scheduling & Pre-saves</h3>
								<p className="text-zinc-600">
									Schedule your release up to 6 months in advance. Set up pre-save campaigns to build hype and maximize your release day impact.
								</p>
							</div>

							{/* Feature 6 */}
							<div className="bg-zinc-50 rounded-2xl p-6 sm:p-8 border border-zinc-200 hover:border-[#BFFF00]/50 hover:shadow-lg hover:shadow-[#BFFF00]/10 transition-all">
								<div className="size-14 bg-[#BFFF00]/20 rounded-xl flex items-center justify-center mb-5">
									<svg className="size-7 text-[#BFFF00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
										<path strokeLinecap="round" strokeLinejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
									</svg>
								</div>
								<h3 className="text-xl font-bold text-zinc-900 mb-3">Real-Time Analytics</h3>
								<p className="text-zinc-600">
									Track your streams, downloads, and earnings in real-time. Get insights into your audience demographics and top-performing tracks.
								</p>
							</div>
						</div>
					</div>
				</div>

				{/* How It Works Section */}
				<div id="how-it-works" className="py-16 sm:py-20 bg-zinc-50">
					<div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
						<div className="text-center mb-12 sm:mb-16">
							<h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-zinc-900 mb-4">
								How It Works
							</h2>
							<p className="text-zinc-600 text-base sm:text-lg max-w-2xl mx-auto">
								Get your music on all major platforms in just 3 simple steps
							</p>
						</div>

						<div className="grid md:grid-cols-3 gap-8">
							{/* Step 1 */}
							<div className="text-center">
								<div className="size-16 bg-[#BFFF00] rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-[#BFFF00]/30">
									<span className="text-2xl font-bold text-zinc-900">1</span>
								</div>
								<h3 className="text-xl font-bold text-zinc-900 mb-3">Upload Your Music</h3>
								<p className="text-zinc-600">
									Upload your tracks, add artwork, and fill in your release details. Our system supports all major audio formats.
								</p>
							</div>

							{/* Step 2 */}
							<div className="text-center">
								<div className="size-16 bg-[#BFFF00] rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-[#BFFF00]/30">
									<span className="text-2xl font-bold text-zinc-900">2</span>
								</div>
								<h3 className="text-xl font-bold text-zinc-900 mb-3">Choose Your Platforms</h3>
								<p className="text-zinc-600">
									Select from 200+ streaming platforms and stores worldwide. Target specific regions or go global with one click.
								</p>
							</div>

							{/* Step 3 */}
							<div className="text-center">
								<div className="size-16 bg-[#BFFF00] rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg shadow-[#BFFF00]/30">
									<span className="text-2xl font-bold text-zinc-900">3</span>
								</div>
								<h3 className="text-xl font-bold text-zinc-900 mb-3">Get Paid</h3>
								<p className="text-zinc-600">
									Start earning from day one. Receive 100% of your royalties with transparent monthly payouts to your account.
								</p>
							</div>
						</div>
					</div>
				</div>

				{/* Pricing Section */}
				<div id="pricing" className="py-16 sm:py-20 bg-white">
					<div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
						<div className="text-center mb-12 sm:mb-16">
							<h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-zinc-900 mb-4">
								Simple, Transparent Pricing
							</h2>
							<p className="text-zinc-600 text-base sm:text-lg max-w-2xl mx-auto">
								Pay once, keep 100% of your royalties forever. No subscriptions, no hidden fees.
							</p>
						</div>

						<div className="grid md:grid-cols-3 gap-6 sm:gap-8 max-w-5xl mx-auto">
							{/* Single */}
							<div className="bg-white border-2 border-zinc-200 rounded-2xl p-6 sm:p-8 hover:border-[#BFFF00] hover:shadow-xl hover:shadow-[#BFFF00]/10 transition-all">
								<div className="text-center mb-6">
									<h3 className="text-lg font-bold text-zinc-900 mb-2">Single</h3>
									<div className="text-4xl font-bold text-zinc-900">$15</div>
									<p className="text-zinc-500 text-sm mt-1">one-time payment</p>
								</div>
								<ul className="space-y-3 mb-8">
									<li className="flex items-center gap-2 text-zinc-700 text-sm">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										1-2 tracks
									</li>
									<li className="flex items-center gap-2 text-zinc-700 text-sm">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										200+ platforms
									</li>
									<li className="flex items-center gap-2 text-zinc-700 text-sm">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										100% royalties
									</li>
									<li className="flex items-center gap-2 text-zinc-700 text-sm">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Forever online
									</li>
								</ul>
								<a
									href={`https://wa.me/256701705378?text=${encodeURIComponent("Hi! I want to distribute my SINGLE to all platforms. Please help me get started.")}`}
									target="_blank"
									rel="noopener noreferrer"
									className="block w-full text-center bg-zinc-900 hover:bg-zinc-800 text-white font-semibold py-3 rounded-full transition-all"
								>
									Get Started
								</a>
							</div>

							{/* EP - Popular */}
							<div className="bg-zinc-900 border-2 border-[#BFFF00] rounded-2xl p-6 sm:p-8 relative shadow-xl shadow-[#BFFF00]/20">
								<div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#BFFF00] text-zinc-900 text-xs font-bold px-4 py-1 rounded-full">
									MOST POPULAR
								</div>
								<div className="text-center mb-6">
									<h3 className="text-lg font-bold text-white mb-2">EP</h3>
									<div className="text-4xl font-bold text-white">$30</div>
									<p className="text-zinc-400 text-sm mt-1">one-time payment</p>
								</div>
								<ul className="space-y-3 mb-8">
									<li className="flex items-center gap-2 text-zinc-300 text-sm">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										3-6 tracks
									</li>
									<li className="flex items-center gap-2 text-zinc-300 text-sm">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										200+ platforms
									</li>
									<li className="flex items-center gap-2 text-zinc-300 text-sm">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										100% royalties
									</li>
									<li className="flex items-center gap-2 text-zinc-300 text-sm">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Playlist pitching
									</li>
									<li className="flex items-center gap-2 text-zinc-300 text-sm">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Forever online
									</li>
								</ul>
								<a
									href={`https://wa.me/256701705378?text=${encodeURIComponent("Hi! I want to distribute my EP to all platforms. Please help me get started.")}`}
									target="_blank"
									rel="noopener noreferrer"
									className="block w-full text-center bg-[#BFFF00] hover:bg-[#a8e600] text-zinc-900 font-semibold py-3 rounded-full transition-all"
								>
									Get Started
								</a>
							</div>

							{/* Album */}
							<div className="bg-white border-2 border-zinc-200 rounded-2xl p-6 sm:p-8 hover:border-[#BFFF00] hover:shadow-xl hover:shadow-[#BFFF00]/10 transition-all">
								<div className="text-center mb-6">
									<h3 className="text-lg font-bold text-zinc-900 mb-2">Album</h3>
									<div className="text-4xl font-bold text-zinc-900">$50</div>
									<p className="text-zinc-500 text-sm mt-1">one-time payment</p>
								</div>
								<ul className="space-y-3 mb-8">
									<li className="flex items-center gap-2 text-zinc-700 text-sm">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										7+ tracks
									</li>
									<li className="flex items-center gap-2 text-zinc-700 text-sm">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										200+ platforms
									</li>
									<li className="flex items-center gap-2 text-zinc-700 text-sm">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										100% royalties
									</li>
									<li className="flex items-center gap-2 text-zinc-700 text-sm">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Playlist pitching
									</li>
									<li className="flex items-center gap-2 text-zinc-700 text-sm">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										YouTube Content ID
									</li>
									<li className="flex items-center gap-2 text-zinc-700 text-sm">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Forever online
									</li>
								</ul>
								<a
									href={`https://wa.me/256701705378?text=${encodeURIComponent("Hi! I want to distribute my ALBUM to all platforms. Please help me get started.")}`}
									target="_blank"
									rel="noopener noreferrer"
									className="block w-full text-center bg-zinc-900 hover:bg-zinc-800 text-white font-semibold py-3 rounded-full transition-all"
								>
									Get Started
								</a>
							</div>
						</div>
					</div>
				</div>

				{/* CTA Section */}
				<div className="py-16 sm:py-20 bg-gradient-to-br from-zinc-900 via-zinc-800 to-zinc-900">
					<div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
						<h2 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-4">
							Ready to Share Your Music with the World?
						</h2>
						<p className="text-zinc-400 text-base sm:text-lg max-w-2xl mx-auto mb-8">
							Join thousands of artists who trust us to distribute their music to 200+ platforms worldwide.
						</p>
						<div className="flex flex-col sm:flex-row gap-4 justify-center">
							<a
								href={`https://wa.me/256701705378?text=${encodeURIComponent("Hi! I'm interested in music distribution services. Please tell me more.")}`}
								target="_blank"
								rel="noopener noreferrer"
								className="inline-flex items-center justify-center gap-2 bg-[#BFFF00] hover:bg-[#a8e600] text-zinc-900 font-semibold px-8 py-4 rounded-full transition-all hover:scale-105 shadow-lg shadow-[#BFFF00]/30"
							>
								<svg className="size-5" viewBox="0 0 24 24" fill="currentColor">
									<path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
								</svg>
								Start Distributing Now
							</a>
							<Link
								to="/"
								className="inline-flex items-center justify-center gap-2 bg-white/10 hover:bg-white/20 border border-white/20 text-white font-medium px-8 py-4 rounded-full transition-all"
							>
								Back to Home
							</Link>
						</div>
					</div>
				</div>

				{/* Footer */}
				<footer className="bg-zinc-900 border-t border-zinc-800 px-4 sm:px-6 py-6 sm:py-8">
					<div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
						<img
							src="https://troydigitaldesk.online/wp-content/uploads/2025/09/logo-top.png"
							alt="Troy Digital Desk"
							className="h-5 sm:h-6 w-auto"
						/>
						<p className="text-zinc-500 text-xs sm:text-sm">
							© 2025 Troy Digital Desk. All rights reserved.
						</p>
						<Link to="/" className="text-zinc-400 hover:text-white text-xs sm:text-sm transition-colors">
							Back to Home
						</Link>
					</div>
				</footer>
			</div>
		);
	}

	// Special design for Playlist Pitching page (pitchplaylists.com inspired)
	if (serviceId === "playlist-pitching") {
		return (
			<div className="min-h-screen bg-[#020202] text-white relative overflow-hidden">
				{/* Hero Section with Gradient Background */}
				<div className="relative">
					{/* Background Gradient */}
					<div className="absolute inset-0 bg-gradient-to-br from-purple-900/40 via-[#020202] to-blue-900/30" />
					<div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-[#BFFF00]/10 via-transparent to-transparent" />

					{/* Header */}
					<header className="relative z-20 px-4 sm:px-6 lg:px-12 py-4 sm:py-6">
						<div className="flex items-center justify-between max-w-6xl mx-auto">
							<Link
								to="/"
								className="flex items-center gap-2 text-zinc-400 hover:text-white transition-colors"
							>
								<ChevronLeft className="size-4 sm:size-5" />
								<span className="text-sm sm:text-base">Back to Home</span>
							</Link>
							<img
								src="https://troydigitaldesk.online/wp-content/uploads/2025/09/logo-top.png"
								alt="Troy Digital Desk"
								className="h-6 sm:h-8 w-auto"
							/>
							<div className="w-12 sm:w-16" />
						</div>
					</header>

					{/* Hero Content */}
					<div className="relative z-10 px-4 sm:px-6 lg:px-12 py-12 sm:py-16 md:py-20 lg:py-28 text-center max-w-5xl mx-auto">
						<div className="inline-flex items-center gap-2 bg-[#BFFF00]/10 border border-[#BFFF00]/30 rounded-full px-4 py-1.5 mb-6">
							<span className="size-2 bg-[#BFFF00] rounded-full animate-pulse" />
							<span className="text-[#BFFF00] text-xs sm:text-sm font-medium">Now accepting new artists</span>
						</div>

						<h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold mb-4 sm:mb-6 leading-tight">
							Get Your Music on<br />
							<span className="text-transparent bg-clip-text bg-gradient-to-r from-[#BFFF00] via-green-400 to-emerald-500">
								Popular Playlists
							</span>
						</h1>

						<p className="text-zinc-400 text-sm sm:text-base md:text-lg lg:text-xl max-w-2xl mx-auto mb-8 sm:mb-10">
							We pitch your music to real playlist curators on Spotify, Apple Music, and other major streaming platforms. Get discovered by millions of listeners.
						</p>

						<div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center">
							<a
								href="#pricing"
								className="inline-flex items-center justify-center gap-2 bg-[#BFFF00] hover:bg-[#a8e600] text-zinc-900 font-semibold px-6 sm:px-8 py-3 sm:py-4 rounded-full transition-all hover:scale-105 text-sm sm:text-base"
							>
								Submit Your Music
								<svg className="size-4 sm:size-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
									<path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
								</svg>
							</a>
							<Link
								to="/active-campaigns"
								className="inline-flex items-center justify-center gap-2 bg-[#BFFF00]/20 hover:bg-[#BFFF00]/30 border border-[#BFFF00]/50 text-[#BFFF00] font-semibold px-6 sm:px-8 py-3 sm:py-4 rounded-full transition-all hover:scale-105 text-sm sm:text-base"
							>
								<svg className="size-4 sm:size-5" fill="currentColor" viewBox="0 0 24 24">
									<path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
								</svg>
								Active Campaign
							</Link>
							<a
								href="#how-it-works"
								className="inline-flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 border border-white/20 text-white font-medium px-6 sm:px-8 py-3 sm:py-4 rounded-full transition-all text-sm sm:text-base"
							>
								How It Works
							</a>
						</div>
					</div>

					{/* Platform Logos */}
					<div className="relative z-10 px-4 sm:px-6 pb-12 sm:pb-16">
						<p className="text-center text-zinc-500 text-xs sm:text-sm mb-6">Trusted by artists featured on</p>
						<div className="flex flex-wrap items-center justify-center gap-6 sm:gap-8 md:gap-12 opacity-60">
							{/* Spotify */}
							<svg className="h-6 sm:h-8 w-auto" viewBox="0 0 24 24" fill="#1DB954">
								<path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/>
							</svg>
							{/* Apple Music */}
							<svg className="h-6 sm:h-8 w-auto" viewBox="0 0 24 24" fill="#FC3C44">
								<path d="M23.997 6.124a9.23 9.23 0 00-.24-2.19c-.317-1.31-1.062-2.31-2.18-3.043a5.022 5.022 0 00-1.877-.726 10.496 10.496 0 00-1.564-.15c-.04-.003-.083-.01-.124-.013H5.988c-.152.01-.303.017-.455.026-.747.043-1.49.123-2.193.4-1.336.53-2.3 1.452-2.865 2.78-.192.448-.292.925-.363 1.408-.056.392-.088.785-.1 1.18 0 .032-.007.062-.01.093v12.223c.01.14.017.283.027.424.05.815.154 1.624.497 2.373.65 1.42 1.738 2.353 3.234 2.8.42.127.856.187 1.293.228.555.053 1.11.06 1.667.06h11.03a12.5 12.5 0 001.57-.1c.822-.107 1.596-.35 2.296-.81a5.046 5.046 0 001.88-2.208c.186-.42.293-.87.37-1.324.113-.675.138-1.358.137-2.04-.002-3.8 0-7.595-.003-11.393zm-6.423 3.99v5.712c0 .417-.058.827-.244 1.206-.29.59-.76.962-1.388 1.14-.35.1-.706.157-1.07.173-.95.042-1.8-.6-1.965-1.483-.18-.965.407-1.94 1.353-2.224.338-.1.69-.155 1.04-.198.396-.05.79-.104 1.177-.2.3-.074.46-.248.477-.553.004-.072.003-.146.003-.22V8.648c0-.116-.013-.218-.14-.252-.18-.047-.363-.086-.546-.122l-3.306-.644c-.065-.013-.13-.023-.196-.03-.128-.017-.224.023-.253.143-.014.055-.02.113-.02.17v7.7a8.59 8.59 0 01-.058.996c-.073.65-.4 1.15-.98 1.473-.323.18-.672.285-1.04.334-.726.097-1.39-.02-1.97-.507-.502-.42-.71-.962-.675-1.596.04-.725.417-1.256 1.042-1.6.32-.175.664-.28 1.02-.354.42-.088.842-.157 1.258-.256.297-.07.462-.242.49-.543.006-.067.004-.135.004-.2v-8.24c0-.1.01-.2.025-.3.045-.278.21-.443.486-.49.095-.016.192-.027.288-.038l5.09-.97.616-.116c.088-.018.177-.03.267-.034.206-.007.323.1.336.306.007.093.008.187.008.28l.003 5.63z"/>
							</svg>
							{/* Audiomack */}
							<svg className="h-6 sm:h-8 w-auto" viewBox="0 0 24 24" fill="#FFA500">
								<path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 17.703c-.185.308-.59.403-.898.218-2.462-1.505-5.563-1.847-9.213-1.012-.352.08-.703-.14-.783-.492-.08-.35.14-.702.492-.782 3.995-.914 7.42-.52 10.184 1.17.308.185.403.59.218.898zm1.594-3.567c-.234.386-.736.507-1.12.273-2.816-1.73-7.107-2.232-10.43-1.222-.43.132-.885-.11-1.017-.541-.13-.43.11-.884.541-1.016 3.795-1.156 8.51-.596 11.753 1.387.385.233.507.735.273 1.12zm.137-3.712c-3.375-2.005-8.944-2.19-12.17-1.212-.517.157-1.063-.134-1.22-.65-.157-.518.134-1.064.65-1.222 3.7-1.124 9.85-.907 13.74 1.403.465.276.617.876.342 1.34-.276.464-.877.617-1.342.341z"/>
							</svg>
							{/* YouTube Music */}
							<svg className="h-6 sm:h-8 w-auto" viewBox="0 0 24 24" fill="#FF0000">
								<path d="M12 0C5.376 0 0 5.376 0 12s5.376 12 12 12 12-5.376 12-12S18.624 0 12 0zm0 19.104c-3.924 0-7.104-3.18-7.104-7.104S8.076 4.896 12 4.896s7.104 3.18 7.104 7.104-3.18 7.104-7.104 7.104zm0-13.332c-3.432 0-6.228 2.796-6.228 6.228S8.568 18.228 12 18.228s6.228-2.796 6.228-6.228S15.432 5.772 12 5.772zM9.684 15.54V8.46L15.816 12l-6.132 3.54z"/>
							</svg>
							{/* Deezer */}
							<svg className="h-5 sm:h-7 w-auto" viewBox="0 0 24 24" fill="#FF0092">
								<path d="M18.81 4.16v3.03H24V4.16h-5.19zM6.27 8.38v3.027h5.189V8.38h-5.19zm12.54 0v3.027H24V8.38h-5.19zM0 12.594v3.027h5.19v-3.027H0zm6.27 0v3.027h5.189v-3.027h-5.19zm6.271 0v3.027h5.19v-3.027h-5.19zm6.27 0v3.027H24v-3.027h-5.19zM0 16.81v3.028h5.19v-3.027H0zm6.27 0v3.028h5.189v-3.027h-5.19zm6.271 0v3.028h5.19v-3.027h-5.19zm6.27 0v3.028H24v-3.027h-5.19z"/>
							</svg>
						</div>
					</div>
				</div>

				{/* Stats Section */}
				<div className="relative z-10 bg-zinc-900/50 border-y border-white/5 py-12 sm:py-16">
					<div className="max-w-6xl mx-auto px-4 sm:px-6">
						<div className="grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8">
							<div className="text-center">
								<div className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#BFFF00] mb-1 sm:mb-2">500+</div>
								<div className="text-zinc-400 text-xs sm:text-sm">Curators Network</div>
							</div>
							<div className="text-center">
								<div className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#BFFF00] mb-1 sm:mb-2">10M+</div>
								<div className="text-zinc-400 text-xs sm:text-sm">Total Playlist Reach</div>
							</div>
							<div className="text-center">
								<div className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#BFFF00] mb-1 sm:mb-2">1,000+</div>
								<div className="text-zinc-400 text-xs sm:text-sm">Artists Helped</div>
							</div>
							<div className="text-center">
								<div className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#BFFF00] mb-1 sm:mb-2">95%</div>
								<div className="text-zinc-400 text-xs sm:text-sm">Placement Rate</div>
							</div>
						</div>
					</div>
				</div>

				{/* How It Works Section */}
				<div id="how-it-works" className="relative z-10 py-16 sm:py-20 md:py-24 px-4 sm:px-6">
					<div className="max-w-5xl mx-auto">
						<div className="text-center mb-12 sm:mb-16">
							<h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
								How It <span className="text-[#BFFF00]">Works</span>
							</h2>
							<p className="text-zinc-400 text-sm sm:text-base max-w-2xl mx-auto">
								Our simple 4-step process gets your music in front of the right curators
							</p>
						</div>

						<div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
							{/* Step 1 */}
							<div className="relative bg-zinc-900/50 border border-white/10 rounded-2xl p-6 sm:p-8 hover:border-[#BFFF00]/30 transition-all group">
								<div className="absolute -top-3 -left-3 size-8 sm:size-10 bg-[#BFFF00] rounded-full flex items-center justify-center text-zinc-900 font-bold text-sm sm:text-base">
									1
								</div>
								<div className="size-12 sm:size-14 bg-[#BFFF00]/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-[#BFFF00]/20 transition-colors">
									<svg className="size-6 sm:size-7 text-[#BFFF00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
										<path strokeLinecap="round" strokeLinejoin="round" d="M9 8.25H7.5a2.25 2.25 0 00-2.25 2.25v9a2.25 2.25 0 002.25 2.25h9a2.25 2.25 0 002.25-2.25v-9a2.25 2.25 0 00-2.25-2.25H15m0-3l-3-3m0 0l-3 3m3-3v11.25" />
									</svg>
								</div>
								<h3 className="text-lg sm:text-xl font-semibold mb-2">Submit Your Track</h3>
								<p className="text-zinc-400 text-sm">Upload your song and provide details about your music and target audience.</p>
							</div>

							{/* Step 2 */}
							<div className="relative bg-zinc-900/50 border border-white/10 rounded-2xl p-6 sm:p-8 hover:border-[#BFFF00]/30 transition-all group">
								<div className="absolute -top-3 -left-3 size-8 sm:size-10 bg-[#BFFF00] rounded-full flex items-center justify-center text-zinc-900 font-bold text-sm sm:text-base">
									2
								</div>
								<div className="size-12 sm:size-14 bg-[#BFFF00]/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-[#BFFF00]/20 transition-colors">
									<svg className="size-6 sm:size-7 text-[#BFFF00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
										<path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
									</svg>
								</div>
								<h3 className="text-lg sm:text-xl font-semibold mb-2">We Find Curators</h3>
								<p className="text-zinc-400 text-sm">Our team identifies the best playlists and curators that match your genre.</p>
							</div>

							{/* Step 3 */}
							<div className="relative bg-zinc-900/50 border border-white/10 rounded-2xl p-6 sm:p-8 hover:border-[#BFFF00]/30 transition-all group">
								<div className="absolute -top-3 -left-3 size-8 sm:size-10 bg-[#BFFF00] rounded-full flex items-center justify-center text-zinc-900 font-bold text-sm sm:text-base">
									3
								</div>
								<div className="size-12 sm:size-14 bg-[#BFFF00]/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-[#BFFF00]/20 transition-colors">
									<svg className="size-6 sm:size-7 text-[#BFFF00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
										<path strokeLinecap="round" strokeLinejoin="round" d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5" />
									</svg>
								</div>
								<h3 className="text-lg sm:text-xl font-semibold mb-2">Pitch Your Music</h3>
								<p className="text-zinc-400 text-sm">We personally pitch your track to curators with a compelling story.</p>
							</div>

							{/* Step 4 */}
							<div className="relative bg-zinc-900/50 border border-white/10 rounded-2xl p-6 sm:p-8 hover:border-[#BFFF00]/30 transition-all group">
								<div className="absolute -top-3 -left-3 size-8 sm:size-10 bg-[#BFFF00] rounded-full flex items-center justify-center text-zinc-900 font-bold text-sm sm:text-base">
									4
								</div>
								<div className="size-12 sm:size-14 bg-[#BFFF00]/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-[#BFFF00]/20 transition-colors">
									<svg className="size-6 sm:size-7 text-[#BFFF00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
										<path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" />
									</svg>
								</div>
								<h3 className="text-lg sm:text-xl font-semibold mb-2">Get Results</h3>
								<p className="text-zinc-400 text-sm">Track your placements and watch your streams grow organically.</p>
							</div>
						</div>
					</div>
				</div>

				{/* Pricing Section */}
				<div id="pricing" className="relative z-10 py-16 sm:py-20 md:py-24 px-4 sm:px-6 bg-gradient-to-b from-transparent via-zinc-900/30 to-transparent">
					<div className="max-w-6xl mx-auto">
						<div className="text-center mb-12 sm:mb-16">
							<h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
								Choose Your <span className="text-[#BFFF00]">Package</span>
							</h2>
							<p className="text-zinc-400 text-sm sm:text-base max-w-2xl mx-auto">
								Flexible pricing options to fit your goals and budget
							</p>
						</div>

						<div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
							{/* Starter Package */}
							<div className="relative bg-zinc-900/70 border border-white/10 rounded-2xl p-6 sm:p-8 hover:border-white/20 transition-all">
								<div className="mb-6">
									<h3 className="text-lg sm:text-xl font-semibold mb-2">Starter</h3>
									<p className="text-zinc-400 text-sm">Perfect for new artists</p>
								</div>
								<div className="mb-6">
									<span className="text-3xl sm:text-4xl font-bold">$130</span>
									<span className="text-zinc-500 text-sm">/track</span>
								</div>
								<ul className="space-y-3 mb-8">
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										5-10 playlist submissions
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Spotify focus
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										7-day delivery
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Placement report
									</li>
								</ul>
								<a
									href="https://wa.me/256701705378?text=Hi!%20I'm%20interested%20in%20the%20Starter%20Playlist%20Pitching%20package%20($130)"
									target="_blank"
									rel="noopener noreferrer"
									className="block w-full text-center bg-white/10 hover:bg-white/20 border border-white/20 text-white font-medium py-3 rounded-xl transition-all text-sm sm:text-base"
								>
									Get Started
								</a>
							</div>

							{/* Pro Package - Featured */}
							<div className="relative bg-gradient-to-b from-[#BFFF00]/10 to-zinc-900/70 border-2 border-[#BFFF00]/50 rounded-2xl p-6 sm:p-8 hover:border-[#BFFF00] transition-all scale-[1.02] sm:scale-105">
								<div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#BFFF00] text-zinc-900 text-xs font-bold px-4 py-1 rounded-full">
									MOST POPULAR
								</div>
								<div className="mb-6 pt-2">
									<h3 className="text-lg sm:text-xl font-semibold mb-2">Pro</h3>
									<p className="text-zinc-400 text-sm">Best value for serious artists</p>
								</div>
								<div className="mb-6">
									<span className="text-3xl sm:text-4xl font-bold text-[#BFFF00]">$175</span>
									<span className="text-zinc-500 text-sm">/track</span>
								</div>
								<ul className="space-y-3 mb-8">
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										20-30 playlist submissions
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Spotify + Apple Music
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										14-day campaign
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Detailed analytics report
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Priority support
									</li>
								</ul>
								<a
									href="https://wa.me/256701705378?text=Hi!%20I'm%20interested%20in%20the%20Pro%20Playlist%20Pitching%20package%20($175)"
									target="_blank"
									rel="noopener noreferrer"
									className="block w-full text-center bg-[#BFFF00] hover:bg-[#a8e600] text-zinc-900 font-semibold py-3 rounded-xl transition-all text-sm sm:text-base"
								>
									Get Started
								</a>
							</div>

							{/* Premium Package */}
							<div className="relative bg-zinc-900/70 border border-white/10 rounded-2xl p-6 sm:p-8 hover:border-white/20 transition-all sm:col-span-2 lg:col-span-1">
								<div className="mb-6">
									<h3 className="text-lg sm:text-xl font-semibold mb-2">Premium</h3>
									<p className="text-zinc-400 text-sm">Maximum exposure campaign</p>
								</div>
								<div className="mb-6">
									<span className="text-3xl sm:text-4xl font-bold">$250</span>
									<span className="text-zinc-500 text-sm">/track</span>
								</div>
								<ul className="space-y-3 mb-8">
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										50+ playlist submissions
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										All major platforms
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										30-day campaign
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Blog & press features
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										1-on-1 strategy call
									</li>
								</ul>
								<a
									href="https://wa.me/256701705378?text=Hi!%20I'm%20interested%20in%20the%20Premium%20Playlist%20Pitching%20package%20($250)"
									target="_blank"
									rel="noopener noreferrer"
									className="block w-full text-center bg-white/10 hover:bg-white/20 border border-white/20 text-white font-medium py-3 rounded-xl transition-all text-sm sm:text-base"
								>
									Get Started
								</a>
							</div>
						</div>

						{/* Custom Package CTA */}
						<div className="mt-8 sm:mt-12 text-center">
							<p className="text-zinc-400 text-sm mb-4">Need a custom package for multiple tracks or labels?</p>
							<a
								href="https://wa.me/256701705378?text=Hi!%20I'm%20interested%20in%20a%20custom%20Playlist%20Pitching%20package"
								target="_blank"
								rel="noopener noreferrer"
								className="inline-flex items-center gap-2 text-[#BFFF00] hover:text-[#a8e600] font-medium text-sm sm:text-base transition-colors"
							>
								Contact us for custom pricing
								<svg className="size-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
									<path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
								</svg>
							</a>
						</div>
					</div>
				</div>

				{/* Final CTA Section */}
				<div className="relative z-10 py-16 sm:py-20 md:py-24 px-4 sm:px-6">
					<div className="max-w-3xl mx-auto text-center">
						<h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 sm:mb-6">
							Ready to Get Your Music<br />
							<span className="text-[#BFFF00]">Heard by Millions?</span>
						</h2>
						<p className="text-zinc-400 text-sm sm:text-base mb-8">
							Join thousands of artists who have grown their audience through our playlist pitching service.
						</p>
						<a
							href="https://wa.me/256701705378?text=Hi!%20I'm%20interested%20in%20your%20Playlist%20Pitching%20service"
							target="_blank"
							rel="noopener noreferrer"
							className="inline-flex items-center gap-2 bg-[#BFFF00] hover:bg-[#a8e600] text-zinc-900 font-semibold px-8 py-4 rounded-full transition-all hover:scale-105 text-sm sm:text-base"
						>
							<svg className="size-5" viewBox="0 0 24 24" fill="currentColor">
								<path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
							</svg>
							Start Your Campaign on WhatsApp
						</a>
					</div>
				</div>

				{/* Footer */}
				<footer className="relative z-10 border-t border-white/5 px-4 sm:px-6 py-6 sm:py-8">
					<div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
						<img
							src="https://troydigitaldesk.online/wp-content/uploads/2025/09/logo-top.png"
							alt="Troy Digital Desk"
							className="h-5 sm:h-6 w-auto"
						/>
						<p className="text-zinc-500 text-xs sm:text-sm">
							© 2025 Troy Digital Desk. All rights reserved.
						</p>
						<Link to="/" className="text-zinc-400 hover:text-white text-xs sm:text-sm transition-colors">
							Back to Home
						</Link>
					</div>
				</footer>
			</div>
		);
	}

	// Special design for YouTube Growth page (Promolta-inspired)
	if (serviceId === "youtube-growth") {
		return (
			<div className="min-h-screen bg-[#0a0a0a] text-white relative overflow-hidden">
				{/* Hero Section */}
				<div className="relative">
					{/* Background Gradient */}
					<div className="absolute inset-0 bg-gradient-to-br from-red-900/30 via-[#0a0a0a] to-zinc-900/30" />
					<div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-red-600/10 via-transparent to-transparent" />

					{/* Header */}
					<header className="relative z-20 px-4 sm:px-6 lg:px-12 py-4 sm:py-6">
						<div className="flex items-center justify-between max-w-6xl mx-auto">
							<Link
								to="/"
								className="flex items-center gap-2 text-zinc-400 hover:text-white transition-colors"
							>
								<ChevronLeft className="size-4 sm:size-5" />
								<span className="text-sm sm:text-base">Back to Home</span>
							</Link>
							<img
								src="https://troydigitaldesk.online/wp-content/uploads/2025/09/logo-top.png"
								alt="Troy Digital Desk"
								className="h-6 sm:h-8 w-auto"
							/>
							<div className="w-12 sm:w-16" />
						</div>
					</header>

					{/* Hero Content */}
					<div className="relative z-10 px-4 sm:px-6 lg:px-12 py-12 sm:py-16 md:py-20 lg:py-28 text-center max-w-5xl mx-auto">
						<div className="inline-flex items-center gap-2 bg-red-500/10 border border-red-500/30 rounded-full px-4 py-1.5 mb-6">
							<span className="size-2 bg-red-500 rounded-full animate-pulse" />
							<span className="text-red-400 text-xs sm:text-sm font-medium">Start from just $10</span>
						</div>

						<h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-bold mb-4 sm:mb-6 leading-tight">
							Promote Your Videos<br />
							<span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-red-400 to-orange-500">
								Get More Views
							</span>
						</h1>

						<p className="text-zinc-400 text-sm sm:text-base md:text-lg lg:text-xl max-w-2xl mx-auto mb-8 sm:mb-10">
							Distribute your YouTube videos across our network of social platforms, blogs, websites, and apps. Quality audiences, not bots. Real results you can measure.
						</p>

						<div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center">
							<a
								href="#start-campaign"
								className="inline-flex items-center justify-center gap-2 bg-red-600 hover:bg-red-500 text-white font-semibold px-6 sm:px-8 py-3 sm:py-4 rounded-full transition-all hover:scale-105 text-sm sm:text-base"
							>
								Start Campaign
								<svg className="size-4 sm:size-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
									<path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
								</svg>
							</a>
							<a
								href="#how-it-works"
								className="inline-flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 border border-white/20 text-white font-medium px-6 sm:px-8 py-3 sm:py-4 rounded-full transition-all text-sm sm:text-base"
							>
								How It Works
							</a>
						</div>
					</div>

					{/* Distribution Channels */}
					<div className="relative z-10 px-4 sm:px-6 pb-12 sm:pb-16">
						<p className="text-center text-zinc-500 text-xs sm:text-sm mb-6">Your videos displayed on</p>
						<div className="flex flex-wrap items-center justify-center gap-4 sm:gap-8 md:gap-12">
							<div className="flex items-center gap-2 text-zinc-400">
								<svg className="size-5 sm:size-6" fill="currentColor" viewBox="0 0 24 24">
									<path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
								</svg>
								<span className="text-xs sm:text-sm">Social Networks</span>
							</div>
							<div className="flex items-center gap-2 text-zinc-400">
								<svg className="size-5 sm:size-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
									<path strokeLinecap="round" strokeLinejoin="round" d="M12 7.5h1.5m-1.5 3h1.5m-7.5 3h7.5m-7.5 3h7.5m3-9h3.375c.621 0 1.125.504 1.125 1.125V18a2.25 2.25 0 01-2.25 2.25M16.5 7.5V18a2.25 2.25 0 002.25 2.25M16.5 7.5V4.875c0-.621-.504-1.125-1.125-1.125H4.125C3.504 3.75 3 4.254 3 4.875V18a2.25 2.25 0 002.25 2.25h13.5M6 7.5h3v3H6v-3z" />
								</svg>
								<span className="text-xs sm:text-sm">Blogs & Websites</span>
							</div>
							<div className="flex items-center gap-2 text-zinc-400">
								<svg className="size-5 sm:size-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
									<path strokeLinecap="round" strokeLinejoin="round" d="M14.25 6.087c0-.355.186-.676.401-.959.221-.29.349-.634.349-1.003 0-1.036-1.007-1.875-2.25-1.875s-2.25.84-2.25 1.875c0 .369.128.713.349 1.003.215.283.401.604.401.959v0a.64.64 0 01-.657.643 48.39 48.39 0 01-4.163-.3c.186 1.613.293 3.25.315 4.907a.656.656 0 01-.658.663v0c-.355 0-.676-.186-.959-.401a1.647 1.647 0 00-1.003-.349c-1.036 0-1.875 1.007-1.875 2.25s.84 2.25 1.875 2.25c.369 0 .713-.128 1.003-.349.283-.215.604-.401.959-.401v0c.31 0 .555.26.532.57a48.039 48.039 0 01-.642 5.056c1.518.19 3.058.309 4.616.354a.64.64 0 00.657-.643v0c0-.355-.186-.676-.401-.959a1.647 1.647 0 01-.349-1.003c0-1.035 1.008-1.875 2.25-1.875 1.243 0 2.25.84 2.25 1.875 0 .369-.128.713-.349 1.003-.215.283-.4.604-.4.959v0c0 .333.277.599.61.58a48.1 48.1 0 005.427-.63 48.05 48.05 0 00.582-4.717.532.532 0 00-.533-.57v0c-.355 0-.676.186-.959.401-.29.221-.634.349-1.003.349-1.035 0-1.875-1.007-1.875-2.25s.84-2.25 1.875-2.25c.37 0 .713.128 1.003.349.283.215.604.401.96.401v0a.656.656 0 00.658-.663 48.422 48.422 0 00-.37-5.36c-1.886.342-3.81.574-5.766.689a.578.578 0 01-.61-.58v0z" />
								</svg>
								<span className="text-xs sm:text-sm">Games</span>
							</div>
							<div className="flex items-center gap-2 text-zinc-400">
								<svg className="size-5 sm:size-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
									<path strokeLinecap="round" strokeLinejoin="round" d="M10.5 1.5H8.25A2.25 2.25 0 006 3.75v16.5a2.25 2.25 0 002.25 2.25h7.5A2.25 2.25 0 0018 20.25V3.75a2.25 2.25 0 00-2.25-2.25H13.5m-3 0V3h3V1.5m-3 0h3m-3 18.75h3" />
								</svg>
								<span className="text-xs sm:text-sm">Mobile Apps</span>
							</div>
						</div>
					</div>
				</div>

				{/* Success Stories */}
				<div className="relative z-10 bg-zinc-900/50 border-y border-white/5 py-12 sm:py-16">
					<div className="max-w-6xl mx-auto px-4 sm:px-6">
						<div className="text-center mb-8 sm:mb-12">
							<h2 className="text-xl sm:text-2xl md:text-3xl font-bold mb-2">
								Our <span className="text-red-500">Success Stories</span> Playlist
							</h2>
							<p className="text-zinc-400 text-sm">Watch videos we've helped promote to millions of views</p>
						</div>
						<div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8">
							<div className="text-center p-6 bg-zinc-800/30 rounded-2xl border border-white/5">
								<img
									src="https://i.ytimg.com/vi/M8vcWjlN6OQ/hqdefault.jpg"
									alt="Omega 256 ft Cindy Sanyu - See You Tonight"
									className="w-full aspect-video mx-auto mb-4 rounded-lg object-cover shadow-lg"
								/>
								<div className="text-xs text-zinc-500 mb-1">Omega 256 ft Cindy Sanyu</div>
								<div className="text-xs text-white/70 mb-2">"See You Tonight"</div>
								<div className="flex items-center justify-center gap-2 text-lg sm:text-xl">
									<span className="text-zinc-500">50K</span>
									<svg className="size-4 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
										<path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
									</svg>
									<span className="text-[#BFFF00] font-bold">2M+</span>
								</div>
								<div className="text-xs text-zinc-500 mt-1">views</div>
							</div>
							<div className="text-center p-6 bg-zinc-800/30 rounded-2xl border border-white/5">
								<img
									src="https://i.ytimg.com/vi/w2HZFJqdrtU/maxresdefault.jpg"
									alt="Acidic Vokoz - It's Okay"
									className="w-full aspect-video mx-auto mb-4 rounded-lg object-cover shadow-lg"
								/>
								<div className="text-xs text-zinc-500 mb-1">Acidic Vokoz</div>
								<div className="text-xs text-white/70 mb-2">"It's Okay"</div>
								<div className="flex items-center justify-center gap-2 text-lg sm:text-xl">
									<span className="text-zinc-500">50K</span>
									<svg className="size-4 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
										<path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
									</svg>
									<span className="text-[#BFFF00] font-bold">3.3M+</span>
								</div>
								<div className="text-xs text-zinc-500 mt-1">views</div>
							</div>
							<div className="text-center p-6 bg-zinc-800/30 rounded-2xl border border-white/5">
								<img
									src="https://i.ytimg.com/vi/pnbcGZljjq4/maxresdefault.jpg"
									alt="Lil Pazo - Enkudi"
									className="w-full aspect-video mx-auto mb-4 rounded-lg object-cover shadow-lg"
								/>
								<div className="text-xs text-zinc-500 mb-1">Lil Pazo</div>
								<div className="text-xs text-white/70 mb-2">"Enkudi"</div>
								<div className="flex items-center justify-center gap-2 text-lg sm:text-xl">
									<span className="text-zinc-500">100K</span>
									<svg className="size-4 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
										<path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
									</svg>
									<span className="text-[#BFFF00] font-bold">1.5M+</span>
								</div>
								<div className="text-xs text-zinc-500 mt-1">views</div>
							</div>
						</div>
					</div>
				</div>

				{/* YouTube Playlist Section */}
				<div className="relative z-10 py-12 sm:py-16 px-4 sm:px-6">
					<div className="max-w-4xl mx-auto">
						<div className="text-center mb-8">
							<h2 className="text-xl sm:text-2xl md:text-3xl font-bold mb-2">
								Get your music video on Youtube <span className="text-red-500">#trending</span> for Music
							</h2>
							<p className="text-zinc-400 text-sm">See how creators grew their channels</p>
						</div>
						<div className="aspect-video w-full max-w-2xl mx-auto rounded-2xl overflow-hidden shadow-2xl shadow-red-500/10 border border-white/10">
							<iframe
								src="https://www.youtube.com/embed/videoseries?list=PL4fGSI1pDJn75xappx8QlV4-0nuyXlDAr&autoplay=0"
								title="Troy Digital Desk - Success Stories Playlist"
								allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
								allowFullScreen
								className="w-full h-full"
							/>
						</div>
					</div>
				</div>

				{/* How It Works Section */}
				<div id="how-it-works" className="relative z-10 py-16 sm:py-20 md:py-24 px-4 sm:px-6">
					<div className="max-w-5xl mx-auto">
						<div className="text-center mb-12 sm:mb-16">
							<h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
								How It <span className="text-red-500">Works</span>
							</h2>
							<p className="text-zinc-400 text-sm sm:text-base max-w-2xl mx-auto">
								Simple 3-step process to promote your videos
							</p>
						</div>

						<div className="grid sm:grid-cols-3 gap-6 sm:gap-8">
							{/* Step 1 */}
							<div className="relative bg-zinc-900/50 border border-white/10 rounded-2xl p-6 sm:p-8 hover:border-red-500/30 transition-all group">
								<div className="absolute -top-3 -left-3 size-8 sm:size-10 bg-red-600 rounded-full flex items-center justify-center text-white font-bold text-sm sm:text-base">
									1
								</div>
								<div className="size-12 sm:size-14 bg-red-500/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-red-500/20 transition-colors">
									<svg className="size-6 sm:size-7 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
										<path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
									</svg>
								</div>
								<h3 className="text-lg sm:text-xl font-semibold mb-2">Start Campaign</h3>
								<p className="text-zinc-400 text-sm">Search for your video, select your budget starting from $10, and choose your target audience.</p>
							</div>

							{/* Step 2 */}
							<div className="relative bg-zinc-900/50 border border-white/10 rounded-2xl p-6 sm:p-8 hover:border-red-500/30 transition-all group">
								<div className="absolute -top-3 -left-3 size-8 sm:size-10 bg-red-600 rounded-full flex items-center justify-center text-white font-bold text-sm sm:text-base">
									2
								</div>
								<div className="size-12 sm:size-14 bg-red-500/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-red-500/20 transition-colors">
									<svg className="size-6 sm:size-7 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
										<path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
										<path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
									</svg>
								</div>
								<h3 className="text-lg sm:text-xl font-semibold mb-2">Get Seen</h3>
								<p className="text-zinc-400 text-sm">Your video gets distributed across blogs, websites, apps, and social networks in our publisher network.</p>
							</div>

							{/* Step 3 */}
							<div className="relative bg-zinc-900/50 border border-white/10 rounded-2xl p-6 sm:p-8 hover:border-red-500/30 transition-all group">
								<div className="absolute -top-3 -left-3 size-8 sm:size-10 bg-red-600 rounded-full flex items-center justify-center text-white font-bold text-sm sm:text-base">
									3
								</div>
								<div className="size-12 sm:size-14 bg-red-500/10 rounded-xl flex items-center justify-center mb-4 group-hover:bg-red-500/20 transition-colors">
									<svg className="size-6 sm:size-7 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
										<path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-5.94-2.28m5.94 2.28l-2.28 5.941" />
									</svg>
								</div>
								<h3 className="text-lg sm:text-xl font-semibold mb-2">Gain Popularity</h3>
								<p className="text-zinc-400 text-sm">Monitor your real-time results as passionate target audiences discover and engage with your content.</p>
							</div>
						</div>
					</div>
				</div>

				{/* Pricing Section */}
				<div id="start-campaign" className="relative z-10 py-16 sm:py-20 md:py-24 px-4 sm:px-6 bg-gradient-to-b from-transparent via-zinc-900/30 to-transparent">
					<div className="max-w-6xl mx-auto">
						<div className="text-center mb-12 sm:mb-16">
							<h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
								Start Your <span className="text-red-500">Campaign</span>
							</h2>
							<p className="text-zinc-400 text-sm sm:text-base max-w-2xl mx-auto">
								Flexible budgets to fit every creator. Quality over quantity.
							</p>
						</div>

						<div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
							{/* Starter */}
							<div className="relative bg-zinc-900/70 border border-white/10 rounded-2xl p-6 sm:p-8 hover:border-white/20 transition-all">
								<div className="mb-6">
									<h3 className="text-lg sm:text-xl font-semibold mb-2">Starter</h3>
									<p className="text-zinc-400 text-sm">Test the waters</p>
								</div>
								<div className="mb-6">
									<span className="text-3xl sm:text-4xl font-bold">$10</span>
									<span className="text-zinc-500 text-sm">/video</span>
								</div>
								<ul className="space-y-3 mb-8">
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										1,000-2,000 impressions
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Social network distribution
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Real-time monitoring
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										3-day campaign
									</li>
								</ul>
								<a
									href="https://wa.me/256701705378?text=Hi!%20I'm%20interested%20in%20the%20Starter%20YouTube%20Promotion%20package%20($10)"
									target="_blank"
									rel="noopener noreferrer"
									className="block w-full text-center bg-white/10 hover:bg-white/20 border border-white/20 text-white font-medium py-3 rounded-xl transition-all text-sm sm:text-base"
								>
									Get Started
								</a>
							</div>

							{/* Growth - Featured */}
							<div className="relative bg-gradient-to-b from-red-500/10 to-zinc-900/70 border-2 border-red-500/50 rounded-2xl p-6 sm:p-8 hover:border-red-500 transition-all scale-[1.02] sm:scale-105">
								<div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-red-600 text-white text-xs font-bold px-4 py-1 rounded-full">
									MOST POPULAR
								</div>
								<div className="mb-6 pt-2">
									<h3 className="text-lg sm:text-xl font-semibold mb-2">Growth</h3>
									<p className="text-zinc-400 text-sm">Best value for creators</p>
								</div>
								<div className="mb-6">
									<span className="text-3xl sm:text-4xl font-bold text-red-500">$50</span>
									<span className="text-zinc-500 text-sm">/video</span>
								</div>
								<ul className="space-y-3 mb-8">
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										10,000-15,000 impressions
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Multi-platform distribution
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Targeted audience selection
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										7-day campaign
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Priority support
									</li>
								</ul>
								<a
									href="https://wa.me/256701705378?text=Hi!%20I'm%20interested%20in%20the%20Growth%20YouTube%20Promotion%20package%20($50)"
									target="_blank"
									rel="noopener noreferrer"
									className="block w-full text-center bg-red-600 hover:bg-red-500 text-white font-semibold py-3 rounded-xl transition-all text-sm sm:text-base"
								>
									Get Started
								</a>
							</div>

							{/* Viral */}
							<div className="relative bg-zinc-900/70 border border-white/10 rounded-2xl p-6 sm:p-8 hover:border-white/20 transition-all sm:col-span-2 lg:col-span-1">
								<div className="mb-6">
									<h3 className="text-lg sm:text-xl font-semibold mb-2">Viral</h3>
									<p className="text-zinc-400 text-sm">Maximum exposure</p>
								</div>
								<div className="mb-6">
									<span className="text-3xl sm:text-4xl font-bold">$150</span>
									<span className="text-zinc-500 text-sm">/video</span>
								</div>
								<ul className="space-y-3 mb-8">
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										50,000+ impressions
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Premium publisher network
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Advanced targeting
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										14-day campaign
									</li>
									<li className="flex items-center gap-3 text-sm text-zinc-300">
										<svg className="size-5 text-red-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
										</svg>
										Detailed analytics report
									</li>
								</ul>
								<a
									href="https://wa.me/256701705378?text=Hi!%20I'm%20interested%20in%20the%20Viral%20YouTube%20Promotion%20package%20($150)"
									target="_blank"
									rel="noopener noreferrer"
									className="block w-full text-center bg-white/10 hover:bg-white/20 border border-white/20 text-white font-medium py-3 rounded-xl transition-all text-sm sm:text-base"
								>
									Get Started
								</a>
							</div>
						</div>

						{/* Custom Budget CTA */}
						<div className="mt-8 sm:mt-12 text-center">
							<p className="text-zinc-400 text-sm mb-4">Need a custom budget for multiple videos or channels?</p>
							<a
								href="https://wa.me/256701705378?text=Hi!%20I'm%20interested%20in%20a%20custom%20YouTube%20Promotion%20package"
								target="_blank"
								rel="noopener noreferrer"
								className="inline-flex items-center gap-2 text-red-500 hover:text-red-400 font-medium text-sm sm:text-base transition-colors"
							>
								Contact us for custom pricing
								<svg className="size-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
									<path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
								</svg>
							</a>
						</div>
					</div>
				</div>

				{/* Final CTA Section */}
				<div className="relative z-10 py-16 sm:py-20 md:py-24 px-4 sm:px-6">
					<div className="max-w-3xl mx-auto text-center">
						<h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 sm:mb-6">
							Ready to Grow Your<br />
							<span className="text-red-500">YouTube Channel?</span>
						</h2>
						<p className="text-zinc-400 text-sm sm:text-base mb-8">
							Join thousands of creators who have boosted their views through our video promotion network.
						</p>
						<a
							href="https://wa.me/256701705378?text=Hi!%20I'm%20interested%20in%20promoting%20my%20YouTube%20videos"
							target="_blank"
							rel="noopener noreferrer"
							className="inline-flex items-center gap-2 bg-red-600 hover:bg-red-500 text-white font-semibold px-8 py-4 rounded-full transition-all hover:scale-105 text-sm sm:text-base"
						>
							<svg className="size-5" viewBox="0 0 24 24" fill="currentColor">
								<path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
							</svg>
							Start Your Campaign on WhatsApp
						</a>
					</div>
				</div>

				{/* Footer */}
				<footer className="relative z-10 border-t border-white/5 px-4 sm:px-6 py-6 sm:py-8">
					<div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
						<img
							src="https://troydigitaldesk.online/wp-content/uploads/2025/09/logo-top.png"
							alt="Troy Digital Desk"
							className="h-5 sm:h-6 w-auto"
						/>
						<p className="text-zinc-500 text-xs sm:text-sm">
							© 2025 Troy Digital Desk. All rights reserved.
						</p>
						<Link to="/" className="text-zinc-400 hover:text-white text-xs sm:text-sm transition-colors">
							Back to Home
						</Link>
					</div>
				</footer>
			</div>
		);
	}

	// Special design for Marketing and Branding page (Comparison Tool)
	if (serviceId === "marketing-and-branding") {
		// Comparison data sets
		const comparisonSets = {
			brandingVsMarketing: {
				leftTitle: "Branding",
				rightTitle: "Marketing",
				leftColor: "#ee6f2d",
				rightColor: "#5dd5ed",
				items: [
					{ left: "Focus on identity and values", right: "Focus on promotion and sales" },
					{ left: "Long-term strategy", right: "Short to mid-term campaigns" },
					{ left: "Builds emotional connection", right: "Drives immediate action" },
					{ left: "Defines who you are", right: "Communicates what you offer" },
					{ left: "Creates loyalty and trust", right: "Generates leads and conversions" },
					{ left: "Consistent across all touchpoints", right: "Varies by campaign and channel" },
					{ left: "Shapes perception and reputation", right: "Measures ROI and performance" },
				],
			},
			organicVsPaid: {
				leftTitle: "Organic Growth",
				rightTitle: "Paid Promotion",
				leftColor: "#22c55e",
				rightColor: "#ef4444",
				items: [
					{ left: "Free but time-intensive", right: "Fast results with budget" },
					{ left: "Builds authentic audience", right: "Reaches targeted demographics" },
					{ left: "Long-term sustainable growth", right: "Immediate visibility boost" },
					{ left: "Higher engagement rates", right: "Scalable reach potential" },
					{ left: "Algorithm-dependent", right: "Guaranteed impressions" },
					{ left: "Requires consistent content", right: "Requires ad spend management" },
				],
			},
			spotifyVsYoutube: {
				leftTitle: "Spotify",
				rightTitle: "YouTube",
				leftColor: "#1DB954",
				rightColor: "#FF0000",
				items: [
					{ left: "Audio-focused streaming", right: "Video content platform" },
					{ left: "Playlist discovery", right: "Search & recommendation" },
					{ left: "Per-stream royalties", right: "Ad revenue sharing" },
					{ left: "Curated editorial playlists", right: "Algorithm-driven suggestions" },
					{ left: "Background listening", right: "Active viewing engagement" },
					{ left: "Mood-based discovery", right: "Content creator ecosystem" },
				],
			},
		};

		const [activeSet, setActiveSet] = useState<keyof typeof comparisonSets>("brandingVsMarketing");
		const [customColors, setCustomColors] = useState({
			left: comparisonSets.brandingVsMarketing.leftColor,
			right: comparisonSets.brandingVsMarketing.rightColor,
		});
		const [showColorPicker, setShowColorPicker] = useState(false);

		const currentSet = comparisonSets[activeSet];

		const handleSetChange = (set: keyof typeof comparisonSets) => {
			setActiveSet(set);
			setCustomColors({
				left: comparisonSets[set].leftColor,
				right: comparisonSets[set].rightColor,
			});
		};

		const resetColors = () => {
			setCustomColors({
				left: currentSet.leftColor,
				right: currentSet.rightColor,
			});
		};

		return (
			<div className="min-h-screen bg-zinc-950">
				{/* Header */}
				<header className="sticky top-0 z-50 bg-zinc-950/90 backdrop-blur-md border-b border-zinc-800">
					<div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
						<div className="flex items-center justify-between">
							<Link
								to="/"
								className="flex items-center gap-2 text-zinc-400 hover:text-white transition-colors"
							>
								<ChevronLeft className="size-5" />
								<span className="text-sm font-medium">Back to Home</span>
							</Link>

							<h1 className="text-lg sm:text-xl font-bold text-white">
								Your Target Market Awaits
							</h1>

							<button
								onClick={() => setShowColorPicker(!showColorPicker)}
								className="flex items-center gap-2 px-3 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white transition-colors"
							>
								<Palette className="size-4" />
								<span className="hidden sm:inline text-sm">Customize</span>
							</button>
						</div>
					</div>
				</header>

				<main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
					{/* Template Selector */}
					<div className="mb-8 text-center">
						<h2 className="text-white font-semibold mb-4">Define your Goal</h2>
						<div className="flex flex-wrap gap-3 justify-center">
							{Object.entries(comparisonSets).map(([key, set]) => (
								<button
									key={key}
									onClick={() => handleSetChange(key as keyof typeof comparisonSets)}
									className={`px-4 py-2 rounded-lg font-medium text-sm transition-all ${
										activeSet === key
											? "bg-[#BFFF00] text-zinc-900"
											: "bg-zinc-800 text-white hover:bg-zinc-700"
									}`}
								>
									{set.leftTitle} vs {set.rightTitle}
								</button>
							))}
						</div>
					</div>

					{/* Color Customization Panel */}
					{showColorPicker && (
						<div className="mb-8 p-4 sm:p-6 rounded-xl bg-zinc-900 border border-zinc-800">
							<div className="flex items-center justify-between mb-4">
								<h3 className="text-white font-semibold">Customize Colors</h3>
								<button
									onClick={resetColors}
									className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white text-sm transition-colors"
								>
									<RotateCcw className="size-3" />
									Reset
								</button>
							</div>
							<div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
								<div>
									<label className="block text-zinc-400 text-sm mb-2">
										Left Column Color
									</label>
									<div className="flex items-center gap-3">
										<input
											type="color"
											value={customColors.left}
											onChange={(e) =>
												setCustomColors({ ...customColors, left: e.target.value })
											}
											className="w-12 h-10 rounded cursor-pointer border-0"
										/>
										<input
											type="text"
											value={customColors.left}
											onChange={(e) =>
												setCustomColors({ ...customColors, left: e.target.value })
											}
											className="flex-1 px-3 py-2 rounded-lg bg-zinc-800 border border-zinc-700 text-white text-sm font-mono"
										/>
									</div>
								</div>
								<div>
									<label className="block text-zinc-400 text-sm mb-2">
										Right Column Color
									</label>
									<div className="flex items-center gap-3">
										<input
											type="color"
											value={customColors.right}
											onChange={(e) =>
												setCustomColors({ ...customColors, right: e.target.value })
											}
											className="w-12 h-10 rounded cursor-pointer border-0"
										/>
										<input
											type="text"
											value={customColors.right}
											onChange={(e) =>
												setCustomColors({ ...customColors, right: e.target.value })
											}
											className="flex-1 px-3 py-2 rounded-lg bg-zinc-800 border border-zinc-700 text-white text-sm font-mono"
										/>
									</div>
								</div>
							</div>
						</div>
					)}

					{/* Comparison Table */}
					<ComparisonTable
						key={activeSet}
						leftTitle={currentSet.leftTitle}
						rightTitle={currentSet.rightTitle}
						leftColor={customColors.left}
						rightColor={customColors.right}
						comparisonItems={currentSet.items}
						backgroundColor="#18181b"
						containerBg="#09090b"
						enableAnimations={true}
						onCellClick={(side, index, text) => {
							console.log(`Clicked ${side} cell ${index}: ${text}`);
						}}
					/>
				</main>

				{/* Footer */}
				<footer className="border-t border-zinc-800 mt-16">
					<div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex justify-center">
						<Link
							to="/"
							className="px-8 py-3 bg-[#BFFF00] hover:bg-[#a8e600] text-zinc-900 font-semibold rounded-full transition-all hover:scale-105 shadow-lg shadow-[#BFFF00]/20"
						>
							Start Campaign
						</Link>
					</div>
				</footer>
			</div>
		);
	}

	return (
		<div className="min-h-screen bg-zinc-950 text-white relative overflow-hidden">
			{/* Background */}
			<div className="absolute inset-0 bg-gradient-to-b from-zinc-900 via-zinc-950 to-black" />
			<div
				className="absolute inset-0 opacity-20"
				style={{
					backgroundImage: `
						linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px),
						linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px)
					`,
					backgroundSize: "60px 60px",
				}}
			/>

			{/* Content */}
			<div className="relative z-10 min-h-screen flex flex-col">
				{/* Header */}
				<header className="px-4 sm:px-6 lg:px-12 py-3 sm:py-4 border-b border-white/10">
					<div className="flex items-center justify-between max-w-6xl mx-auto">
						<Link
							to="/"
							className="flex items-center gap-1.5 sm:gap-2 text-zinc-400 hover:text-white transition-colors"
						>
							<ChevronLeft className="size-4 sm:size-5" />
							<span className="text-sm sm:text-base">Back to Home</span>
						</Link>
						<img
							src="https://troydigitaldesk.online/wp-content/uploads/2025/09/logo-top.png"
							alt="Troy Digital Desk"
							className="h-6 sm:h-8 w-auto"
						/>
						<div className="w-12 sm:w-16" />
					</div>
				</header>

				{/* Main Content */}
				<main className="flex-1 px-4 sm:px-6 lg:px-12 py-8 sm:py-12 lg:py-20">
					<div className="max-w-4xl mx-auto">
						{/* Service Title */}
						<div className="mb-8 sm:mb-12">
							<div className="flex gap-1 mb-3 sm:mb-4">
								<div className="w-1.5 sm:w-2 h-6 sm:h-8 bg-[#BFFF00]" />
								<div className="w-1.5 sm:w-2 h-6 sm:h-8 bg-[#BFFF00]" />
							</div>
							<h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-6xl font-bold mb-4 sm:mb-6">
								{service.name}
							</h1>
							<p className="text-sm sm:text-base md:text-lg lg:text-xl text-zinc-400 leading-relaxed">
								{service.description}
							</p>
						</div>

						{/* Features */}
						<div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-4 sm:p-6 md:p-8 mb-8 sm:mb-12">
							<h2 className="text-lg sm:text-xl md:text-2xl font-semibold mb-4 sm:mb-6 text-[#BFFF00]">
								What's Included
							</h2>
							<ul className="space-y-2 sm:space-y-3 md:space-y-4">
								{service.features.map((feature, index) => (
									<li key={index} className="flex items-start sm:items-center gap-2 sm:gap-3">
										<div className="size-1.5 sm:size-2 rounded-full bg-[#BFFF00] mt-1.5 sm:mt-0 flex-shrink-0" />
										<span className="text-sm sm:text-base text-zinc-300">{feature}</span>
									</li>
								))}
							</ul>
						</div>

						{/* CTA */}
						<div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-xl p-4 sm:p-6 md:p-8 hover:border-[#BFFF00]/30 transition-colors">
							<h2 className="text-lg sm:text-xl md:text-2xl font-semibold mb-3 sm:mb-4">
								Ready to Get Started?
							</h2>
							<p className="text-sm sm:text-base text-zinc-400 mb-4 sm:mb-6">
								Let's discuss how we can help you achieve your goals with{" "}
								{service.name.toLowerCase()}.
							</p>

							<div className="space-y-4 sm:space-y-6">
								{/* Order Form */}
								<div className="grid gap-3 sm:gap-4">
										{/* Name */}
										<div>
											<label className="block text-xs sm:text-sm font-medium text-zinc-300 mb-1.5 sm:mb-2">
												Name
											</label>
											<input
												type="text"
												value={formData.name}
												onChange={(e) =>
													setFormData((prev) => ({
														...prev,
														name: e.target.value,
													}))
												}
												placeholder="Enter your name"
												className="w-full px-3 sm:px-4 py-2.5 sm:py-3 bg-zinc-800/50 border border-zinc-700 rounded-lg text-sm sm:text-base text-white placeholder-zinc-500 focus:outline-none focus:border-[#BFFF00] transition-colors"
											/>
										</div>

										{/* Phone Number */}
										<div>
											<label className="block text-xs sm:text-sm font-medium text-zinc-300 mb-1.5 sm:mb-2">
												Phone Number
											</label>
											<input
												type="tel"
												value={formData.phone}
												onChange={(e) =>
													setFormData((prev) => ({
														...prev,
														phone: e.target.value,
													}))
												}
												placeholder="Enter your phone number"
												className="w-full px-3 sm:px-4 py-2.5 sm:py-3 bg-zinc-800/50 border border-zinc-700 rounded-lg text-sm sm:text-base text-white placeholder-zinc-500 focus:outline-none focus:border-[#BFFF00] transition-colors"
											/>
										</div>

										{/* Email Address */}
										<div>
											<label className="block text-xs sm:text-sm font-medium text-zinc-300 mb-1.5 sm:mb-2">
												Email Address
											</label>
											<input
												type="email"
												value={formData.email}
												onChange={(e) =>
													setFormData((prev) => ({
														...prev,
														email: e.target.value,
													}))
												}
												placeholder="Enter your email address"
												className="w-full px-3 sm:px-4 py-2.5 sm:py-3 bg-zinc-800/50 border border-zinc-700 rounded-lg text-sm sm:text-base text-white placeholder-zinc-500 focus:outline-none focus:border-[#BFFF00] transition-colors"
											/>
										</div>

										{/* Service Options */}
										<div>
											<label className="block text-xs sm:text-sm font-medium text-zinc-300 mb-2 sm:mb-3">
												{service.serviceLabel}
											</label>
											<div className="grid grid-cols-1 xs:grid-cols-2 gap-2 sm:gap-3">
												{service.serviceOptions.map((option: string) => (
													<label
														key={option}
														className={`flex items-center gap-2 sm:gap-3 p-2.5 sm:p-3 rounded-lg border cursor-pointer transition-all ${
															formData.services.includes(option)
																? "bg-[#BFFF00]/20 border-[#BFFF00] text-[#BFFF00]"
																: "bg-zinc-800/50 border-zinc-700 text-zinc-300 hover:border-zinc-500"
														}`}
													>
														<input
															type="checkbox"
															checked={formData.services.includes(option)}
															onChange={() => handleServiceToggle(option)}
															className="sr-only"
														/>
														<div
															className={`size-4 sm:size-5 rounded border-2 flex items-center justify-center flex-shrink-0 ${
																formData.services.includes(option)
																	? "bg-[#BFFF00] border-[#BFFF00]"
																	: "border-zinc-500"
															}`}
														>
															{formData.services.includes(option) && (
																<svg
																	className="size-2.5 sm:size-3 text-zinc-900"
																	fill="none"
																	viewBox="0 0 24 24"
																	stroke="currentColor"
																	strokeWidth={3}
																>
																	<path
																		strokeLinecap="round"
																		strokeLinejoin="round"
																		d="M5 13l4 4L19 7"
																	/>
																</svg>
															)}
														</div>
														<span className="text-xs sm:text-sm">{option}</span>
													</label>
												))}
											</div>
											<p className="text-[10px] sm:text-xs text-zinc-500 mt-1.5 sm:mt-2 text-left">
												Select multiple
											</p>

											{/* Others Message Field */}
											{formData.services.includes("Others") && (
												<div className="mt-3 sm:mt-4">
													<label className="block text-xs sm:text-sm font-medium text-zinc-300 mb-1.5 sm:mb-2">
														Describe the services you need{" "}
														<span className="text-red-500">*</span>
													</label>
													<textarea
														value={formData.otherServices}
														onChange={(e) => {
															setFormData((prev) => ({
																...prev,
																otherServices: e.target.value,
															}));
															if (e.target.value.trim()) {
																setFormErrors((prev) => ({
																	...prev,
																	otherServices: false,
																}));
															}
														}}
														placeholder="Please describe which services you're looking for..."
														rows={3}
														className={`w-full px-3 sm:px-4 py-2.5 sm:py-3 bg-zinc-800/50 border rounded-lg text-sm sm:text-base text-white placeholder-zinc-500 focus:outline-none transition-colors resize-none ${
															formErrors.otherServices
																? "border-red-500 focus:border-red-500"
																: "border-zinc-700 focus:border-[#BFFF00]"
														}`}
													/>
													{formErrors.otherServices && (
														<p className="text-[10px] sm:text-xs text-red-500 mt-1">
															This field is required when "Others" is selected
														</p>
													)}
												</div>
											)}
										</div>

										{/* Engagement Type - Only for Social Media Growth with platform selected */}
										{hasSocialPlatformSelected && (
											<div>
												<label className="block text-xs sm:text-sm font-medium text-zinc-300 mb-2 sm:mb-3">
													What type of engagement do you need?{" "}
													<span className="text-red-500">*</span>
												</label>
												<div className="grid grid-cols-2 gap-2 sm:gap-3">
													{engagementOptions.map((option) => (
														<label
															key={option}
															className={`flex items-center gap-2 sm:gap-3 p-2.5 sm:p-3 rounded-lg border cursor-pointer transition-all ${
																formData.engagementTypes.includes(option)
																	? "bg-[#BFFF00]/20 border-[#BFFF00] text-[#BFFF00]"
																	: "bg-zinc-800/50 border-zinc-700 text-zinc-300 hover:border-zinc-500"
															}`}
														>
															<input
																type="checkbox"
																checked={formData.engagementTypes.includes(option)}
																onChange={() => handleEngagementToggle(option)}
																className="sr-only"
															/>
															<div
																className={`size-4 sm:size-5 rounded border-2 flex items-center justify-center flex-shrink-0 ${
																	formData.engagementTypes.includes(option)
																		? "bg-[#BFFF00] border-[#BFFF00]"
																		: "border-zinc-500"
																}`}
															>
																{formData.engagementTypes.includes(option) && (
																	<svg
																		className="size-2.5 sm:size-3 text-zinc-900"
																		fill="none"
																		viewBox="0 0 24 24"
																		stroke="currentColor"
																		strokeWidth={3}
																	>
																		<path
																			strokeLinecap="round"
																			strokeLinejoin="round"
																			d="M5 13l4 4L19 7"
																		/>
																	</svg>
																)}
															</div>
															<span className="text-xs sm:text-sm">{option}</span>
														</label>
													))}
												</div>
												<p className="text-[10px] sm:text-xs text-zinc-500 mt-1.5 sm:mt-2 text-left">
													Select one or more engagement types
												</p>
												{formErrors.engagementType && (
													<p className="text-[10px] sm:text-xs text-red-500 mt-1">
														Please select at least one engagement type
													</p>
												)}

												{/* Others Engagement Message Field */}
												{formData.engagementTypes.includes("Others") && (
													<div className="mt-3 sm:mt-4">
														<label className="block text-xs sm:text-sm font-medium text-zinc-300 mb-1.5 sm:mb-2">
															Describe the engagement you need{" "}
															<span className="text-red-500">*</span>
														</label>
														<textarea
															value={formData.otherEngagement}
															onChange={(e) => {
																setFormData((prev) => ({
																	...prev,
																	otherEngagement: e.target.value,
																}));
																if (e.target.value.trim()) {
																	setFormErrors((prev) => ({
																		...prev,
																		otherEngagement: false,
																	}));
																}
															}}
															placeholder="Please describe the specific engagement you're looking for..."
															rows={3}
															className={`w-full px-3 sm:px-4 py-2.5 sm:py-3 bg-zinc-800/50 border rounded-lg text-sm sm:text-base text-white placeholder-zinc-500 focus:outline-none transition-colors resize-none ${
																formErrors.otherEngagement
																	? "border-red-500 focus:border-red-500"
																	: "border-zinc-700 focus:border-[#BFFF00]"
															}`}
														/>
														{formErrors.otherEngagement && (
															<p className="text-[10px] sm:text-xs text-red-500 mt-1">
																This field is required when "Others" is selected
															</p>
														)}
													</div>
												)}
											</div>
										)}

										{/* Quantity Slider - Only for Social Media Growth with engagement type selected */}
										{hasSocialPlatformSelected &&
											(formData.engagementTypes.some((t) =>
												["Followers", "Likes", "Views"].includes(t)
											) ||
												(formData.engagementTypes.includes("Others") &&
													customServiceType)) && (
												<div>
													<label className="block text-xs sm:text-sm font-medium text-zinc-300 mb-2 sm:mb-3">
														How many do you need?{" "}
														<span className="text-red-500">*</span>
													</label>
													<div className="space-y-3 sm:space-y-4">
														<div className="flex items-center justify-between">
															<span className="text-xl sm:text-2xl font-bold text-[#BFFF00]">
																{formData.engagementQuantity.toLocaleString()}
															</span>
															<span className="text-xs sm:text-sm text-zinc-400">
																{[
																	...formData.engagementTypes.filter((t) =>
																		["Followers", "Likes", "Views"].includes(t)
																	),
																	...(formData.engagementTypes.includes("Others") &&
																	customServiceType
																		? [
																				customServiceType.charAt(0).toUpperCase() +
																					customServiceType.slice(1),
																			]
																		: []),
																].join(" / ")}
															</span>
														</div>
														<input
															type="range"
															min="0"
															max={
																isCommentsService
																	? "50"
																	: isSavesService
																		? "2000"
																		: "10000"
															}
															step={
																isCommentsService
																	? "5"
																	: isSavesService
																		? "400"
																		: "500"
															}
															value={formData.engagementQuantity}
															onChange={(e) => {
																const value = Number.parseInt(e.target.value);
																setFormData((prev) => ({
																	...prev,
																	engagementQuantity: value,
																}));
																if (value > 0) {
																	setFormErrors((prev) => ({
																		...prev,
																		engagementQuantity: false,
																	}));
																}
															}}
															className="w-full h-1.5 sm:h-2 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-[#BFFF00]"
															style={{
																background: `linear-gradient(to right, #BFFF00 0%, #BFFF00 ${(formData.engagementQuantity / (isCommentsService ? 50 : isSavesService ? 2000 : 10000)) * 100}%, #3f3f46 ${(formData.engagementQuantity / (isCommentsService ? 50 : isSavesService ? 2000 : 10000)) * 100}%, #3f3f46 100%)`,
															}}
														/>
														<div className="flex justify-between text-[10px] sm:text-xs text-zinc-500">
															{isCommentsService ? (
																<>
																	<span>0</span>
																	<span className="hidden xs:inline">10</span>
																	<span>20</span>
																	<span className="hidden xs:inline">30</span>
																	<span>40</span>
																	<span>50</span>
																</>
															) : isSavesService ? (
																<>
																	<span>0</span>
																	<span className="hidden xs:inline">400</span>
																	<span>800</span>
																	<span className="hidden xs:inline">1.2k</span>
																	<span>1.6k</span>
																	<span>2k</span>
																</>
															) : (
																<>
																	<span>0</span>
																	<span className="hidden xs:inline">2.5k</span>
																	<span>5k</span>
																	<span className="hidden xs:inline">7.5k</span>
																	<span>10k</span>
																</>
															)}
														</div>
													</div>
													{formErrors.engagementQuantity && (
														<p className="text-[10px] sm:text-xs text-red-500 mt-2">
															Please select a quantity greater than 0
														</p>
													)}

													{/* Grand Total Display */}
													{formData.engagementQuantity > 0 && (
														<div className="mt-3 sm:mt-4 p-3 sm:p-4 bg-zinc-800/80 border border-[#BFFF00]/30 rounded-lg">
															<div className="flex items-center justify-between">
																<span className="text-xs sm:text-sm text-zinc-400">
																	Grand Total
																</span>
																<span className="text-lg sm:text-xl font-bold text-[#BFFF00]">
																	{formatUGX(totalPriceUGX)}
																</span>
															</div>
															<div className="mt-1.5 sm:mt-2 text-[10px] sm:text-xs text-zinc-500 space-y-1">
																{priceInfo.breakdown.map((item) => (
																	<div key={item.type}>
																		<p className="flex items-center justify-between flex-wrap gap-1">
																			<span>
																				{item.type}: {formData.engagementQuantity.toLocaleString()}
																			</span>
																			{item.discount > 0 ? (
																				<span>
																					<span className="line-through text-zinc-600 mr-1 sm:mr-2">
																						{formatUGX(item.basePrice)}
																					</span>
																					<span className="text-[#BFFF00]">
																						{formatUGX(item.finalPrice)}
																					</span>
																				</span>
																			) : (
																				<span>{formatUGX(item.finalPrice)}</span>
																			)}
																		</p>
																		{item.discount > 0 && (
																			<p className="text-[#BFFF00] text-right text-[10px] sm:text-xs">
																				TikTok 10% discount: -{formatUGX(item.discount)}
																			</p>
																		)}
																	</div>
																))}
															</div>
															{priceInfo.breakdown.some((item) => item.discount > 0) && (
																<div className="mt-1.5 sm:mt-2 pt-1.5 sm:pt-2 border-t border-zinc-700">
																	<p className="text-[10px] sm:text-xs text-[#BFFF00] flex items-center gap-1">
																		<svg
																			className="size-2.5 sm:size-3"
																			fill="currentColor"
																			viewBox="0 0 20 20"
																		>
																			<path
																				fillRule="evenodd"
																				d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
																				clipRule="evenodd"
																			/>
																		</svg>
																		TikTok discount applied!
																	</p>
																</div>
															)}
														</div>
													)}
												</div>
											)}

										{/* URL Submission */}
										<div>
											<label className="block text-xs sm:text-sm font-medium text-zinc-300 mb-1.5 sm:mb-2">
												{hasSocialPlatformSelected && formData.engagementTypes.length > 0
													? getSocialMediaUrlInfo().label
													: "URL Submission"}{" "}
												{hasSocialPlatformSelected && formData.engagementTypes.length > 0 && (
													<span className="text-red-500">*</span>
												)}
											</label>
											<input
												type="url"
												value={formData.url}
												onChange={(e) => {
													setFormData((prev) => ({
														...prev,
														url: e.target.value,
													}));
													// Clear URL error when user starts typing
													if (formErrors.socialUrl) {
														setFormErrors((prev) => ({
															...prev,
															socialUrl: false,
														}));
														setSocialUrlError("");
													}
												}}
												placeholder={
													hasSocialPlatformSelected && formData.engagementTypes.length > 0
														? getSocialMediaUrlInfo().placeholder
														: "Enter your YouTube channel or video URL"
												}
												className={`w-full px-3 sm:px-4 py-2.5 sm:py-3 bg-zinc-800/50 border rounded-lg text-sm sm:text-base text-white placeholder-zinc-500 focus:outline-none transition-colors ${
													formErrors.socialUrl
														? "border-red-500 focus:border-red-500"
														: "border-zinc-700 focus:border-[#BFFF00]"
												}`}
											/>
											{formErrors.socialUrl && socialUrlError && (
												<p className="text-[10px] sm:text-xs text-red-500 mt-1">{socialUrlError}</p>
											)}
										</div>

										{/* Audio/File Upload - Hidden for Social Media Growth */}
										{!isSocialMediaGrowth && (
											<div>
												<label className="block text-xs sm:text-sm font-medium text-zinc-300 mb-1.5 sm:mb-2">
													Audio / File Upload
												</label>
												<div className="relative">
													<input
														type="file"
														accept=".mp3,.wav,.mp4,.aiff,.flac,audio/mpeg,audio/wav,video/mp4,audio/aiff,audio/flac"
														onChange={handleFileChange}
														className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
													/>
													<div className="flex items-center gap-2 sm:gap-3 px-3 sm:px-4 py-2.5 sm:py-3 bg-zinc-800/50 border border-zinc-700 rounded-lg text-zinc-500 hover:border-zinc-500 transition-colors">
														<svg
															className="size-4 sm:size-5 flex-shrink-0"
															fill="none"
															viewBox="0 0 24 24"
															stroke="currentColor"
														>
															<path
																strokeLinecap="round"
																strokeLinejoin="round"
																strokeWidth={2}
																d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"
															/>
														</svg>
														<span className="text-sm sm:text-base truncate">
															{formData.fileName || "Choose file to upload"}
														</span>
													</div>
												</div>
												<p className="text-[10px] sm:text-xs text-zinc-500 mt-1.5 sm:mt-2 text-left">
													Supported formats: MP3, WAV, MP4, AIFF, FLAC
												</p>
											</div>
										)}

										{/* Choose Budget - Hidden for Social Media Growth */}
										{!isSocialMediaGrowth && (
											<div>
												<label className="block text-xs sm:text-sm font-medium text-zinc-300 mb-2 sm:mb-3">
													Choose Budget
												</label>
												<div className="grid grid-cols-3 gap-2 sm:gap-3">
													{budgetOptions.map((option) => (
														<label
															key={option}
															className={`flex items-center justify-center p-2 sm:p-3 rounded-lg border cursor-pointer transition-all ${
																formData.budget === option
																	? "bg-[#BFFF00]/20 border-[#BFFF00] text-[#BFFF00]"
																	: "bg-zinc-800/50 border-zinc-700 text-zinc-300 hover:border-zinc-500"
															}`}
														>
															<input
																type="radio"
																name="budget"
																value={option}
																checked={formData.budget === option}
																onChange={(e) => {
																	setFormData((prev) => ({
																		...prev,
																		budget: e.target.value,
																		customBudget:
																			e.target.value !== "Custom"
																				? ""
																				: prev.customBudget,
																	}));
																	if (e.target.value !== "Custom") {
																		setFormErrors((prev) => ({
																			...prev,
																			customBudget: false,
																		}));
																	}
																}}
																className="sr-only"
															/>
															<span className="text-xs sm:text-sm font-medium">{option}</span>
														</label>
													))}
												</div>

												{/* Custom Budget Message Field */}
												{formData.budget === "Custom" && (
													<div className="mt-3 sm:mt-4">
														<label className="block text-xs sm:text-sm font-medium text-zinc-300 mb-1.5 sm:mb-2">
															Enter your custom budget{" "}
															<span className="text-red-500">*</span>
														</label>
														<textarea
															value={formData.customBudget}
															onChange={(e) => {
																setFormData((prev) => ({
																	...prev,
																	customBudget: e.target.value,
																}));
																if (e.target.value.trim()) {
																	setFormErrors((prev) => ({
																		...prev,
																		customBudget: false,
																	}));
																}
															}}
															placeholder="Describe your budget and requirements..."
															rows={3}
															className={`w-full px-3 sm:px-4 py-2.5 sm:py-3 bg-zinc-800/50 border rounded-lg text-sm sm:text-base text-white placeholder-zinc-500 focus:outline-none transition-colors resize-none ${
																formErrors.customBudget
																	? "border-red-500 focus:border-red-500"
																	: "border-zinc-700 focus:border-[#BFFF00]"
															}`}
														/>
														{formErrors.customBudget && (
															<p className="text-[10px] sm:text-xs text-red-500 mt-1">
																This field is required when "Custom" is selected
															</p>
														)}
													</div>
												)}
											</div>
										)}
									</div>

									{/* Submit Order Button */}
									<button
										onClick={handleSubmitOrder}
										className="w-full inline-flex items-center justify-center gap-2 px-4 sm:px-6 py-3 sm:py-4 bg-[#BFFF00] text-zinc-900 font-semibold rounded-full hover:scale-105 transition-transform text-sm sm:text-base"
									>
										<svg
											className="size-4 sm:size-5"
											fill="currentColor"
											viewBox="0 0 24 24"
										>
											<path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
										</svg>
										Submit Order via WhatsApp
									</button>
								</div>
							</div>
						</div>
				</main>

				{/* Footer */}
				<footer className="border-t border-white/10 px-4 sm:px-6 lg:px-12 py-3 sm:py-4">
					<div className="flex items-center justify-center text-xs sm:text-sm text-zinc-500">
						<span>© 2025 Troy Digital Desk. All rights reserved.</span>
					</div>
				</footer>
			</div>
		</div>
	);
}

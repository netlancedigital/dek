import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronLeft, Play, Eye, Users, TrendingUp, Calendar, ExternalLink, Music, Youtube } from "lucide-react";

export const Route = createFileRoute("/active-campaigns")({
	component: ActiveCampaignsPage,
});

// Campaign data - these would typically come from an API
const campaigns = [
	{
		id: 1,
		name: "Uganda Music Video Promotion",
		status: "active",
		type: "Video Views",
		platform: "YouTube",
		budget: "$150/day",
		spent: "$2,340",
		impressions: "1.2M",
		views: "450K",
		clicks: "12.5K",
		ctr: "2.78%",
		startDate: "Jan 15, 2026",
		endDate: "Ongoing",
		targetAudience: "East Africa, Music Lovers 18-35",
		description: "Promoting trending Ugandan music videos to audiences across East Africa",
		featuredVideos: [
			{ title: "Omega 256 ft Cindy - See You Tonight", views: "2M+" },
			{ title: "Acidic Vokoz - It's Okay", views: "3.3M+" },
			{ title: "Lil Pazo - Enkudi", views: "1.5M+" },
		],
	},
	{
		id: 2,
		name: "Playlist Pitching Awareness",
		status: "active",
		type: "Awareness",
		platform: "Google Display",
		budget: "$75/day",
		spent: "$890",
		impressions: "580K",
		views: "N/A",
		clicks: "8.2K",
		ctr: "1.41%",
		startDate: "Jan 20, 2026",
		endDate: "Feb 28, 2026",
		targetAudience: "Independent Artists, Music Producers",
		description: "Reaching independent artists looking for playlist placement services",
		featuredVideos: [],
	},
	{
		id: 3,
		name: "Social Media Growth Campaign",
		status: "active",
		type: "Engagement",
		platform: "Multi-Platform",
		budget: "$100/day",
		spent: "$1,560",
		impressions: "890K",
		views: "320K",
		clicks: "15.8K",
		ctr: "1.77%",
		startDate: "Jan 10, 2026",
		endDate: "Ongoing",
		targetAudience: "Content Creators, Influencers",
		description: "Growing social media presence for artists across TikTok, Instagram, and YouTube",
		featuredVideos: [],
	},
];

function ActiveCampaignsPage() {
	const activeCampaigns = campaigns.filter((c) => c.status === "active");
	const totalImpressions = "2.67M";
	const totalSpent = "$4,790";
	const avgCTR = "1.99%";

	return (
		<div className="min-h-screen bg-[#0a0a0a] text-white">
			{/* Header */}
			<header className="sticky top-0 z-50 bg-[#0a0a0a]/95 backdrop-blur-md border-b border-white/10">
				<div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
					<div className="flex items-center justify-between">
						<Link
							to="/services/$serviceId"
							params={{ serviceId: "playlist-pitching" }}
							className="flex items-center gap-2 text-zinc-400 hover:text-white transition-colors"
						>
							<ChevronLeft className="size-5" />
							<span className="text-sm font-medium">Back to Services</span>
						</Link>
						<img
							src="https://troydigitaldesk.online/wp-content/uploads/2025/09/logo-top.png"
							alt="Troy Digital Desk"
							className="h-6 sm:h-8 w-auto"
						/>
						<div className="w-20" />
					</div>
				</div>
			</header>

			{/* Scrolling Ticker */}
			<div className="bg-[#BFFF00] flex items-center py-2.5 sm:py-3">
				{/* Static Label */}
				<div className="flex-shrink-0 bg-zinc-900 text-[#BFFF00] font-bold text-sm sm:text-base px-4 sm:px-6 py-1.5 sm:py-2 z-10">
					Active Campaigns
				</div>
				{/* Scrolling Content */}
				<div className="overflow-hidden flex-1">
					<div className="animate-marquee whitespace-nowrap flex">
						{[...Array(3)].map((_, i) => (
							<div key={i} className="flex items-center">
								<span className="mx-4 sm:mx-6 flex items-center gap-2 text-zinc-900 font-semibold text-sm sm:text-base">
									<span className="size-2 bg-zinc-900 rounded-full" />
									Wala - Generus
								</span>
								<span className="mx-4 sm:mx-6 flex items-center gap-2 text-zinc-900 font-semibold text-sm sm:text-base">
									<span className="size-2 bg-zinc-900 rounded-full" />
									Obufumbo Somero - Henry Mayanja
								</span>
								<span className="mx-4 sm:mx-6 flex items-center gap-2 text-zinc-900 font-semibold text-sm sm:text-base">
									<span className="size-2 bg-zinc-900 rounded-full" />
									Today - Levixone
								</span>
								<span className="mx-4 sm:mx-6 flex items-center gap-2 text-zinc-900 font-semibold text-sm sm:text-base">
									<span className="size-2 bg-zinc-900 rounded-full" />
									Nteesa - Dabo Pisto
								</span>
								<span className="mx-4 sm:mx-6 flex items-center gap-2 text-zinc-900 font-semibold text-sm sm:text-base">
									<span className="size-2 bg-zinc-900 rounded-full" />
									Tobingamba - Acidic Vokoz Ft. Ava Peace
								</span>
							</div>
						))}
					</div>
				</div>
			</div>

			{/* Hero Section */}
			<div className="relative overflow-hidden">
				<div className="absolute inset-0 bg-gradient-to-br from-[#BFFF00]/10 via-transparent to-purple-900/10" />
				<div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-[#BFFF00]/5 via-transparent to-transparent" />

				<div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20">
					<div className="text-center mb-10 sm:mb-14">
						<div className="inline-flex items-center gap-2 bg-[#BFFF00]/10 border border-[#BFFF00]/30 rounded-full px-4 py-1.5 mb-6">
							<span className="size-2 bg-[#BFFF00] rounded-full animate-pulse" />
							<span className="text-[#BFFF00] text-xs sm:text-sm font-medium">Live Campaign Dashboard</span>
						</div>
						<h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4">
							Active <span className="text-[#BFFF00]">Campaigns</span>
						</h1>
						<p className="text-zinc-400 text-sm sm:text-base md:text-lg max-w-2xl mx-auto">
							Real-time performance metrics from our Google Ads campaigns promoting music and content creators
						</p>
					</div>

					{/* Stats Overview */}
					<div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 mb-12">
						<div className="bg-zinc-900/50 border border-white/10 rounded-2xl p-4 sm:p-6 text-center hover:border-[#BFFF00]/30 transition-colors">
							<div className="size-10 sm:size-12 bg-[#BFFF00]/10 rounded-xl flex items-center justify-center mx-auto mb-3">
								<Play className="size-5 sm:size-6 text-[#BFFF00]" />
							</div>
							<div className="text-2xl sm:text-3xl font-bold text-white mb-1">{activeCampaigns.length}</div>
							<div className="text-xs sm:text-sm text-zinc-400">Active Campaigns</div>
						</div>
						<div className="bg-zinc-900/50 border border-white/10 rounded-2xl p-4 sm:p-6 text-center hover:border-[#BFFF00]/30 transition-colors">
							<div className="size-10 sm:size-12 bg-[#BFFF00]/10 rounded-xl flex items-center justify-center mx-auto mb-3">
								<Eye className="size-5 sm:size-6 text-[#BFFF00]" />
							</div>
							<div className="text-2xl sm:text-3xl font-bold text-white mb-1">{totalImpressions}</div>
							<div className="text-xs sm:text-sm text-zinc-400">Total Impressions</div>
						</div>
						<div className="bg-zinc-900/50 border border-white/10 rounded-2xl p-4 sm:p-6 text-center hover:border-[#BFFF00]/30 transition-colors">
							<div className="size-10 sm:size-12 bg-[#BFFF00]/10 rounded-xl flex items-center justify-center mx-auto mb-3">
								<TrendingUp className="size-5 sm:size-6 text-[#BFFF00]" />
							</div>
							<div className="text-2xl sm:text-3xl font-bold text-white mb-1">{avgCTR}</div>
							<div className="text-xs sm:text-sm text-zinc-400">Average CTR</div>
						</div>
						<div className="bg-zinc-900/50 border border-white/10 rounded-2xl p-4 sm:p-6 text-center hover:border-[#BFFF00]/30 transition-colors">
							<div className="size-10 sm:size-12 bg-[#BFFF00]/10 rounded-xl flex items-center justify-center mx-auto mb-3">
								<Users className="size-5 sm:size-6 text-[#BFFF00]" />
							</div>
							<div className="text-2xl sm:text-3xl font-bold text-white mb-1">{totalSpent}</div>
							<div className="text-xs sm:text-sm text-zinc-400">Total Ad Spend</div>
						</div>
					</div>
				</div>
			</div>

			{/* Campaigns List */}
			<div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 sm:pb-20">
				<div className="flex items-center justify-between mb-8">
					<h2 className="text-xl sm:text-2xl font-bold">Campaign Details</h2>
					<div className="flex items-center gap-2 text-xs sm:text-sm text-zinc-400">
						<Calendar className="size-4" />
						<span>Last updated: Just now</span>
					</div>
				</div>

				<div className="space-y-6">
					{activeCampaigns.map((campaign) => (
						<div
							key={campaign.id}
							className="bg-zinc-900/50 border border-white/10 rounded-2xl overflow-hidden hover:border-[#BFFF00]/30 transition-all"
						>
							{/* Campaign Header */}
							<div className="p-4 sm:p-6 border-b border-white/5">
								<div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
									<div className="flex items-start sm:items-center gap-4">
										<div className={`size-12 sm:size-14 rounded-xl flex items-center justify-center ${
											campaign.platform === "YouTube"
												? "bg-red-500/10"
												: campaign.platform === "Google Display"
													? "bg-blue-500/10"
													: "bg-purple-500/10"
										}`}>
											{campaign.platform === "YouTube" ? (
												<Youtube className={`size-6 sm:size-7 ${campaign.platform === "YouTube" ? "text-red-500" : "text-blue-500"}`} />
											) : campaign.platform === "Google Display" ? (
												<svg className="size-6 sm:size-7 text-blue-500" viewBox="0 0 24 24" fill="currentColor">
													<path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
													<path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
													<path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
													<path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
												</svg>
											) : (
												<Music className="size-6 sm:size-7 text-purple-500" />
											)}
										</div>
										<div>
											<div className="flex items-center gap-2 mb-1">
												<h3 className="text-lg sm:text-xl font-semibold">{campaign.name}</h3>
												<span className="px-2 py-0.5 bg-green-500/20 text-green-400 text-xs font-medium rounded-full">
													{campaign.status.toUpperCase()}
												</span>
											</div>
											<p className="text-sm text-zinc-400">{campaign.description}</p>
										</div>
									</div>
									<div className="flex items-center gap-2">
										<span className="px-3 py-1.5 bg-zinc-800 text-zinc-300 text-xs sm:text-sm font-medium rounded-lg">
											{campaign.type}
										</span>
										<span className="px-3 py-1.5 bg-zinc-800 text-zinc-300 text-xs sm:text-sm font-medium rounded-lg">
											{campaign.platform}
										</span>
									</div>
								</div>
							</div>

							{/* Campaign Metrics */}
							<div className="p-4 sm:p-6">
								<div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 sm:gap-6 mb-6">
									<div>
										<div className="text-xs text-zinc-500 mb-1">Daily Budget</div>
										<div className="text-lg sm:text-xl font-semibold text-[#BFFF00]">{campaign.budget}</div>
									</div>
									<div>
										<div className="text-xs text-zinc-500 mb-1">Total Spent</div>
										<div className="text-lg sm:text-xl font-semibold">{campaign.spent}</div>
									</div>
									<div>
										<div className="text-xs text-zinc-500 mb-1">Impressions</div>
										<div className="text-lg sm:text-xl font-semibold">{campaign.impressions}</div>
									</div>
									<div>
										<div className="text-xs text-zinc-500 mb-1">Views</div>
										<div className="text-lg sm:text-xl font-semibold">{campaign.views}</div>
									</div>
									<div>
										<div className="text-xs text-zinc-500 mb-1">Clicks</div>
										<div className="text-lg sm:text-xl font-semibold">{campaign.clicks}</div>
									</div>
									<div>
										<div className="text-xs text-zinc-500 mb-1">CTR</div>
										<div className="text-lg sm:text-xl font-semibold text-[#BFFF00]">{campaign.ctr}</div>
									</div>
								</div>

								{/* Campaign Details */}
								<div className="flex flex-col sm:flex-row gap-4 sm:gap-8 text-sm">
									<div className="flex items-center gap-2 text-zinc-400">
										<Calendar className="size-4" />
										<span>Start: {campaign.startDate}</span>
									</div>
									<div className="flex items-center gap-2 text-zinc-400">
										<Calendar className="size-4" />
										<span>End: {campaign.endDate}</span>
									</div>
									<div className="flex items-center gap-2 text-zinc-400">
										<Users className="size-4" />
										<span>Target: {campaign.targetAudience}</span>
									</div>
								</div>

								{/* Featured Videos (for YouTube campaign) */}
								{campaign.featuredVideos.length > 0 && (
									<div className="mt-6 pt-6 border-t border-white/5">
										<div className="text-sm font-medium text-zinc-300 mb-3">Featured Videos in Campaign</div>
										<div className="grid sm:grid-cols-3 gap-3">
											{campaign.featuredVideos.map((video, idx) => (
												<div
													key={idx}
													className="flex items-center gap-3 p-3 bg-zinc-800/50 rounded-lg"
												>
													<div className="size-10 bg-red-500/20 rounded-lg flex items-center justify-center flex-shrink-0">
														<Play className="size-4 text-red-500" />
													</div>
													<div className="min-w-0">
														<div className="text-sm font-medium truncate">{video.title}</div>
														<div className="text-xs text-[#BFFF00]">{video.views} views</div>
													</div>
												</div>
											))}
										</div>
									</div>
								)}
							</div>
						</div>
					))}
				</div>

				{/* CTA Section */}
				<div className="mt-12 sm:mt-16 text-center">
					<div className="bg-gradient-to-r from-[#BFFF00]/10 via-zinc-900/50 to-[#BFFF00]/10 border border-[#BFFF00]/20 rounded-2xl p-8 sm:p-12">
						<h3 className="text-2xl sm:text-3xl font-bold mb-4">
							Want Your Music in Our Next Campaign?
						</h3>
						<p className="text-zinc-400 text-sm sm:text-base max-w-xl mx-auto mb-6">
							Get your videos promoted to millions of targeted viewers through our Google Ads campaigns
						</p>
						<div className="flex flex-col sm:flex-row gap-4 justify-center">
							<Link
								to="/services/$serviceId"
								params={{ serviceId: "youtube-growth" }}
								className="inline-flex items-center justify-center gap-2 bg-[#BFFF00] hover:bg-[#a8e600] text-zinc-900 font-semibold px-6 sm:px-8 py-3 sm:py-4 rounded-full transition-all hover:scale-105 text-sm sm:text-base"
							>
								Start Your Campaign
								<ExternalLink className="size-4" />
							</Link>
							<a
								href="https://wa.me/256701705378?text=Hi!%20I%20saw%20your%20active%20campaigns%20and%20I'm%20interested%20in%20promoting%20my%20music"
								target="_blank"
								rel="noopener noreferrer"
								className="inline-flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 border border-white/20 text-white font-medium px-6 sm:px-8 py-3 sm:py-4 rounded-full transition-all text-sm sm:text-base"
							>
								<svg className="size-5" viewBox="0 0 24 24" fill="currentColor">
									<path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
								</svg>
								Contact Us on WhatsApp
							</a>
						</div>
					</div>
				</div>
			</div>

			{/* Footer */}
			<footer className="border-t border-white/5 px-4 sm:px-6 py-6 sm:py-8">
				<div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
					<img
						src="https://troydigitaldesk.online/wp-content/uploads/2025/09/logo-top.png"
						alt="Troy Digital Desk"
						className="h-5 sm:h-6 w-auto"
					/>
					<p className="text-zinc-500 text-xs sm:text-sm">
						© 2025 Troy Digital Desk. All rights reserved.
					</p>
					<Link to="/" className="text-zinc-400 hover:text-white text-xs sm:text-sm transition-colors">
						Back to Home
					</Link>
				</div>
			</footer>
		</div>
	);
}

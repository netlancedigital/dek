import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronRight, ChevronDown, ChevronLeft, Send, Download, FileText, X } from "lucide-react";
import { useState, useEffect } from "react";
import emailjs from "@emailjs/browser";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
	Select,
	SelectContent,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import {
	Dialog,
	DialogContent,
	DialogHeader,
	DialogTitle,
	DialogDescription,
} from "@/components/ui/dialog";

export const Route = createFileRoute("/")({
	component: App,
});

const services = [
	{
		name: "Music Promotion",
		slug: "music-promotion",
		description: "Get your music heard worldwide",
		icon: "music",
		color: "#BFFF00"
	},
	{
		name: "Youtube Growth",
		slug: "youtube-growth",
		description: "Grow your channel & subscribers",
		icon: "youtube",
		color: "#FF0000"
	},
	{
		name: "Marketing and Branding",
		slug: "marketing-and-branding",
		description: "Build your artist identity",
		icon: "brand",
		color: "#8B5CF6"
	},
	{
		name: "Playlist Pitching",
		slug: "playlist-pitching",
		description: "Get featured on top playlists",
		icon: "playlist",
		color: "#1DB954"
	},
	{
		name: "Music Distribution",
		slug: "music-distribution",
		description: "200+ platforms, 100% royalties",
		icon: "distribution",
		color: "#F97316"
	},
	{
		name: "Social Media Growth",
		slug: "social-media-growth",
		description: "Boost your social presence",
		icon: "social",
		color: "#EC4899"
	},
];

// Portfolio/Works data
const portfolios = [
	{ title: "Tonight - Omega 256 Ft. Cindy", image: "https://troydigitaldesk.online/wp-content/uploads/2025/09/om.png", date: "August 2025" },
	{ title: "Its Okay - Acidic Vokoz", image: "https://troydigitaldesk.online/wp-content/uploads/2025/09/io.png", date: "February 2024" },
	{ title: "Mikie Wine - Zuena", image: "https://troydigitaldesk.online/wp-content/uploads/2025/10/Mikie-Wine-2-edited.jpg", date: "July 2025" },
	{ title: "Acidic Vokoz - Last Chance", image: "https://troydigitaldesk.online/wp-content/uploads/2025/09/lc.png", date: "April 2024" },
	{ title: "Lil Pazo - Enkudi", image: "https://troydigitaldesk.online/wp-content/uploads/2025/09/en.png", date: "January 2024" },
	{ title: "Karitas Kario - Sweet Things", image: "https://troydigitaldesk.online/wp-content/uploads/2025/10/karitas-kario_1667661110-1024x1024.webp", date: "April 2024" },
	{ title: "Don Pitya, Fyno - Challenge", image: "https://troydigitaldesk.online/wp-content/uploads/2025/10/7d8b76e0-62f3-4c97-886a-d12a0110eca3-628x380-1.jpeg", date: "March 2025" },
	{ title: "Acidic Vokoz, Omega 256, Feffe Bussi", image: "https://troydigitaldesk.online/wp-content/uploads/2025/10/vlcsnap-2025-10-03-20h13m42s856-1024x576.png", date: "October 2025" },
	{ title: "Royal Jeff - Leero", image: "https://troydigitaldesk.online/wp-content/uploads/2025/10/maxresdefault-6-1024x576.jpg", date: "November 2023" },
	{ title: "Generus - Yankolako", image: "https://troydigitaldesk.online/wp-content/uploads/2025/10/maxresdefault-7-1024x576.jpg", date: "July 2025" },
];

// Clients data
const clients = [
	{ name: "Acidic Vokoz", image: "https://troydigitaldesk.online/wp-content/uploads/2025/10/IMG_8016-edited-1024x640.jpeg", category: "Musical Artist" },
	{ name: "Omega 256", image: "https://troydigitaldesk.online/wp-content/uploads/2025/10/howwe_1753168384.webp", category: "Musical Artist" },
	{ name: "Mikie Wine", image: "https://troydigitaldesk.online/wp-content/uploads/2025/10/Mikie-Wine-2-edited.jpg", category: "Musical Artist" },
	{ name: "Lil Pazo Lunabe", image: "https://troydigitaldesk.online/wp-content/uploads/2025/10/images.webp", category: "Musical Artist" },
	{ name: "Karitas Kario", image: "https://troydigitaldesk.online/wp-content/uploads/2025/10/karitas-kario_1667661110-1024x1024.webp", category: "Musical Artist" },
	{ name: "Royal Jeff", image: "https://troydigitaldesk.online/wp-content/uploads/2025/10/maxresdefault-6-1024x576.jpg", category: "Musical Artist" },
	{ name: "Generus", image: "https://troydigitaldesk.online/wp-content/uploads/2025/10/maxresdefault-7-1024x576.jpg", category: "Musical Artist" },
	{ name: "Metro FM", image: "https://troydigitaldesk.online/wp-content/uploads/2025/09/om.png", category: "Media Partner" },
	{ name: "Don Pitya", image: "https://troydigitaldesk.online/wp-content/uploads/2025/10/7d8b76e0-62f3-4c97-886a-d12a0110eca3-628x380-1.jpeg", category: "Musical Artist" },
	{ name: "Levixone", image: "https://www.thegmp.biz/storage/uploads/artists/profile_pics/FB_IMG_1582871997508_levixone_thegmp_1582872257.jpg", category: "Musical Artist" },
];

// Uganda Radio Stations from onlineradiobox.com/ug/
const ugandaRadioStations = [
	{ name: "Capital FM", frequency: "91.3 FM", url: "https://onlineradiobox.com/ug/capital/", genre: "Pop, Hits" },
	{ name: "Sanyu FM", frequency: "88.2 FM", url: "https://onlineradiobox.com/ug/sanyu/", genre: "Urban, RnB" },
	{ name: "Galaxy FM", frequency: "100.2 FM", url: "https://onlineradiobox.com/ug/galaxy/", genre: "Afrobeat, Dancehall" },
	{ name: "Radio City", frequency: "97.3 FM", url: "https://onlineradiobox.com/ug/city973/", genre: "Urban, Pop" },
	{ name: "Power FM", frequency: "104.1 FM", url: "https://onlineradiobox.com/ug/power/", genre: "Gospel, Inspirational" },
	{ name: "XFM", frequency: "94.8 FM", url: "https://onlineradiobox.com/ug/xfm/", genre: "Alternative, Rock" },
	{ name: "Beat FM", frequency: "96.3 FM", url: "https://onlineradiobox.com/ug/beat/", genre: "Hip Hop, RnB" },
	{ name: "KFM", frequency: "93.3 FM", url: "https://onlineradiobox.com/ug/kfm/", genre: "News, Talk" },
	{ name: "CBS FM", frequency: "88.8 FM", url: "https://onlineradiobox.com/ug/cbs/", genre: "Luganda, Cultural" },
	{ name: "Radio One", frequency: "90.0 FM", url: "https://onlineradiobox.com/ug/one/", genre: "News, Entertainment" },
	{ name: "Dembe FM", frequency: "90.4 FM", url: "https://onlineradiobox.com/ug/dembe/", genre: "Luganda, Gospel" },
	{ name: "NBS FM", frequency: "88.5 FM", url: "https://onlineradiobox.com/ug/nbs/", genre: "News, Entertainment" },
];

// Dialog configurations for different page types
type DialogType = "inquiry" | "about-us" | "radio-stations" | "playlists" | "submit-to-djs" | "submit-music" | null;

const dialogConfigs = {
	inquiry: {
		title: "Get in Touch",
		description: "Fill out the form below and we'll get back to you shortly",
		showServices: true,
		showMessage: true,
		showSubmissionFields: false,
		showInfoOnly: false,
		showDjSubmissionInfo: false,
		showMusicSubmissionForm: false,
		messageLabel: "Message",
		messagePlaceholder: "Tell us more about your project, goals, and any specific requirements you have...",
		submitText: "Submit Inquiry",
	},
	"about-us": {
		title: "About Us",
		description: "",
		showServices: false,
		showMessage: false,
		showSubmissionFields: false,
		showInfoOnly: true,
		showDjSubmissionInfo: false,
		showMusicSubmissionForm: false,
		messageLabel: "Questions or Feedback",
		messagePlaceholder: "Have questions about who we are or want to share feedback? Let us know...",
		submitText: "Send Message",
	},
	"radio-stations": {
		title: "Uganda Radio Stations",
		description: "Listen to popular Ugandan radio stations online",
		showServices: false,
		showMessage: false,
		showSubmissionFields: false,
		showInfoOnly: false,
		showDjSubmissionInfo: false,
		showMusicSubmissionForm: false,
		showRadioStations: true,
		messageLabel: "",
		messagePlaceholder: "",
		submitText: "",
	},
	playlists: {
		title: "Playlists",
		description: "Submit your music to be added to popular playlists",
		showServices: false,
		showMessage: true,
		showSubmissionFields: true,
		showInfoOnly: false,
		showDjSubmissionInfo: false,
		showMusicSubmissionForm: false,
		messageLabel: "Playlist Submission Details",
		messagePlaceholder: "Tell us about your song, the genre, mood, and which playlists you think it would fit well in...",
		submitText: "Submit to Playlists",
	},
	"submit-to-djs": {
		title: "Submit Music to DJs",
		description: "Get your music heard by a global network of influential DJs and tastemakers",
		showServices: false,
		showMessage: false,
		showSubmissionFields: false,
		showInfoOnly: false,
		showDjSubmissionInfo: true,
		showMusicSubmissionForm: false,
		messageLabel: "DJ Submission Details",
		messagePlaceholder: "Describe your track, BPM, genre, and what type of DJs or venues you're targeting for plays...",
		submitText: "Submit to DJs",
	},
	"submit-music": {
		title: "Submit Your Music",
		description: "Fill out the form below to submit your track for review",
		showServices: false,
		showMessage: false,
		showSubmissionFields: false,
		showInfoOnly: false,
		showDjSubmissionInfo: false,
		showMusicSubmissionForm: true,
		messageLabel: "",
		messagePlaceholder: "",
		submitText: "Submit Track",
	},
};

// Music Promotion Strategy Document Content
const strategyContent = {
	title: "ONLINE MUSIC PROMOTION STRATEGY",
	subtitle: "Complete Guide to Building Your Music Career",
	company: "Troy Digital Desk",
	sections: [
		{
			title: "1. EXECUTIVE SUMMARY",
			content: `This comprehensive music promotion strategy is designed to maximize your online presence, grow your fanbase, and increase streams across all major platforms. Our approach combines organic growth tactics with strategic paid promotions to deliver measurable results within defined timeframes.`
		},
		{
			title: "2. TARGET AUDIENCE ANALYSIS",
			content: `Primary Demographics:
• Age: 18-35 years old
• Interests: Music streaming, social media, live events
• Platforms: Spotify, YouTube, TikTok, Instagram, Apple Music
• Geographic Focus: East Africa, Global African diaspora, International markets

Secondary Demographics:
• Music industry professionals (DJs, playlist curators, radio hosts)
• Music bloggers and influencers
• Event organizers and venue managers`
		},
		{
			title: "3. PLATFORM-SPECIFIC STRATEGIES",
			content: `SPOTIFY PROMOTION ($200-$500/month)
• Editorial playlist pitching (2-4 weeks before release)
• Independent curator outreach (50+ curators per release)
• Spotify for Artists optimization
• Pre-save campaign setup
• Monthly listener growth target: 500-2,000 new listeners

YOUTUBE GROWTH ($300-$600/month)
• SEO-optimized video titles and descriptions
• Custom thumbnail design
• YouTube Shorts strategy (3-5 shorts/week)
• Collaboration with YouTubers (2-3/month)
• Monthly subscriber growth target: 200-500 subscribers

TIKTOK MARKETING ($150-$400/month)
• Trending sound creation and promotion
• Influencer partnerships (5-10 creators/campaign)
• Hashtag challenge campaigns
• User-generated content incentives
• Monthly view target: 100,000-500,000 views

INSTAGRAM GROWTH ($100-$300/month)
• Reels optimization strategy
• Story engagement tactics
• Influencer shoutouts
• Hashtag research and implementation
• Monthly follower growth target: 300-1,000 followers`
		},
		{
			title: "4. CONTENT CALENDAR",
			content: `WEEKLY CONTENT SCHEDULE:
Monday: Behind-the-scenes content
Tuesday: Music tips/industry insights
Wednesday: New release promotion
Thursday: Fan engagement/Q&A
Friday: Release day content blast
Saturday: Live sessions/performances
Sunday: Fan appreciation/throwbacks

MONTHLY MILESTONES:
Week 1: Pre-release campaign launch
Week 2: Release and initial push
Week 3: Sustained promotion and playlist pitching
Week 4: Analytics review and strategy adjustment`
		},
		{
			title: "5. PLAYLIST PITCHING STRATEGY",
			content: `TIER 1 - Major Playlists ($500-$1,000)
• Editorial playlist submissions to Spotify, Apple Music, Deezer
• Lead time: 4 weeks minimum
• Success rate: 5-10%

TIER 2 - Independent Curators ($200-$400)
• Outreach to 100+ independent curators
• Genre-specific targeting
• Success rate: 20-30%

TIER 3 - User-Generated Playlists ($100-$200)
• Playlist exchange networks
• Fan playlist inclusion campaigns
• Success rate: 40-50%`
		},
		{
			title: "6. RADIO & MAINSTREAM PROMOTION",
			content: `LOCAL RADIO ($300-$600/month)
• Station relationships building
• DJ networking events
• On-air interview scheduling
• Song request campaigns

INTERNATIONAL RADIO ($500-$1,000/month)
• Digital radio platforms (iHeartRadio, Pandora)
• College radio outreach
• Genre-specific stations targeting

MAINSTREAM MEDIA ($400-$800/month)
• Press release distribution
• Music blog features
• Magazine interviews
• Podcast guest appearances`
		},
		{
			title: "7. PAID ADVERTISING BUDGET",
			content: `STARTER PACKAGE: $500/month
• Facebook/Instagram Ads: $200
• YouTube Ads: $150
• TikTok Ads: $100
• Spotify Ad Studio: $50

GROWTH PACKAGE: $1,500/month
• Facebook/Instagram Ads: $500
• YouTube Ads: $400
• TikTok Ads: $300
• Spotify Ad Studio: $200
• Google Display Ads: $100

PREMIUM PACKAGE: $3,000/month
• Facebook/Instagram Ads: $1,000
• YouTube Ads: $700
• TikTok Ads: $500
• Spotify Ad Studio: $400
• Google Display Ads: $200
• Influencer Marketing: $200`
		},
		{
			title: "8. BUDGET BREAKDOWN BY GOAL",
			content: `EMERGING ARTIST (Monthly Budget: $500-$1,000)
Total Investment: $6,000-$12,000/year
• Social media management: $200-$400
• Playlist pitching: $150-$300
• Basic advertising: $100-$200
• Content creation: $50-$100

ESTABLISHED ARTIST (Monthly Budget: $1,500-$3,000)
Total Investment: $18,000-$36,000/year
• Full social media management: $500-$800
• Premium playlist services: $400-$600
• Advertising campaigns: $400-$1,000
• PR and media outreach: $200-$600

MAJOR ARTIST (Monthly Budget: $5,000-$10,000)
Total Investment: $60,000-$120,000/year
• Dedicated marketing team: $2,000-$3,000
• Comprehensive PR: $1,000-$2,000
• Premium advertising: $1,500-$3,000
• Influencer campaigns: $500-$2,000`
		},
		{
			title: "9. KEY PERFORMANCE INDICATORS (KPIs)",
			content: `STREAMING METRICS:
• Monthly listeners growth: 20-50% increase
• Stream count: 10,000-50,000 streams/release
• Save rate: 15-25% of listeners
• Playlist adds: 50-200 playlists/release

SOCIAL MEDIA METRICS:
• Follower growth: 10-20% monthly
• Engagement rate: 3-8%
• Video views: 50,000-200,000/month
• Story views: 30-50% of followers

REVENUE METRICS:
• Streaming revenue increase: 25-100%
• Merchandise sales: $500-$2,000/month
• Live performance bookings: 2-5/month`
		},
		{
			title: "10. TIMELINE & MILESTONES",
			content: `MONTH 1-3: FOUNDATION PHASE
• Profile optimization across all platforms
• Initial audience growth campaigns
• Content strategy implementation
• First playlist placements

MONTH 4-6: GROWTH PHASE
• Scaling successful campaigns
• Influencer partnership activation
• Radio promotion begins
• First major playlist features

MONTH 7-12: EXPANSION PHASE
• International market penetration
• Major media features
• Brand partnerships
• Sustainable revenue streams established`
		},
		{
			title: "11. CONTACT & NEXT STEPS",
			content: `Ready to launch your music career to the next level?

Contact Troy Digital Desk:
• Website: troydigitaldesk.online
• Services: Music Promotion, YouTube Growth, Playlist Pitching, Social Media Management

NEXT STEPS:
1. Schedule a free consultation
2. Define your goals and budget
3. Receive a customized promotion plan
4. Launch your campaign
5. Track results and optimize

Let's make your music heard worldwide!`
		}
	]
};

// Generate plain text content for download
const generateTextContent = () => {
	let text = `${strategyContent.title}\n`;
	text += `${"=".repeat(50)}\n`;
	text += `${strategyContent.subtitle}\n`;
	text += `Prepared by: ${strategyContent.company}\n`;
	text += `Date: ${new Date().toLocaleDateString()}\n\n`;

	for (const section of strategyContent.sections) {
		text += `\n${section.title}\n`;
		text += `${"-".repeat(40)}\n`;
		text += `${section.content}\n\n`;
	}

	return text;
};

// Generate HTML content for download
const generateHTMLContent = () => {
	let html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${strategyContent.title}</title>
<style>
body { font-family: 'Segoe UI', Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 40px 20px; line-height: 1.6; color: #333; }
h1 { color: #1a1a1a; border-bottom: 3px solid #BFFF00; padding-bottom: 10px; }
h2 { color: #2a2a2a; margin-top: 30px; background: linear-gradient(90deg, #BFFF00 0%, transparent 100%); padding: 10px; }
h3 { color: #444; }
p, li { color: #555; }
.header { text-align: center; margin-bottom: 40px; }
.subtitle { color: #666; font-size: 1.2em; }
.company { color: #BFFF00; font-weight: bold; }
.section { margin-bottom: 30px; padding: 20px; background: #f9f9f9; border-radius: 8px; }
.footer { text-align: center; margin-top: 40px; padding-top: 20px; border-top: 2px solid #eee; }
pre { white-space: pre-wrap; background: #f5f5f5; padding: 15px; border-radius: 5px; }
</style>
</head>
<body>
<div class="header">
<h1>${strategyContent.title}</h1>
<p class="subtitle">${strategyContent.subtitle}</p>
<p>Prepared by: <span class="company">${strategyContent.company}</span></p>
<p>Date: ${new Date().toLocaleDateString()}</p>
</div>
`;

	for (const section of strategyContent.sections) {
		html += `<div class="section">
<h2>${section.title}</h2>
<pre>${section.content}</pre>
</div>
`;
	}

	html += `<div class="footer">
<p>&copy; ${new Date().getFullYear()} ${strategyContent.company} - All Rights Reserved</p>
<p>Website: troydigitaldesk.online</p>
</div>
</body>
</html>`;

	return html;
};

// Generate RTF content for download
const generateRTFContent = () => {
	let rtf = `{\\rtf1\\ansi\\deff0
{\\fonttbl{\\f0 Arial;}}
{\\colortbl;\\red0\\green0\\blue0;\\red191\\green255\\blue0;}
\\f0\\fs24
\\pard\\qc\\b\\fs36 ${strategyContent.title}\\b0\\fs24\\par
\\par
${strategyContent.subtitle}\\par
Prepared by: ${strategyContent.company}\\par
Date: ${new Date().toLocaleDateString()}\\par
\\pard\\par
`;

	for (const section of strategyContent.sections) {
		rtf += `\\par\\b ${section.title}\\b0\\par
${section.content.replace(/\n/g, '\\par\n')}\\par
`;
	}

	rtf += `}`;
	return rtf;
};

// Download function
const downloadStrategy = (format: 'txt' | 'html' | 'rtf') => {
	let content: string;
	let mimeType: string;
	let filename: string;

	switch (format) {
		case 'txt':
			content = generateTextContent();
			mimeType = 'text/plain';
			filename = 'Music_Promotion_Strategy.txt';
			break;
		case 'html':
			content = generateHTMLContent();
			mimeType = 'text/html';
			filename = 'Music_Promotion_Strategy.html';
			break;
		case 'rtf':
			content = generateRTFContent();
			mimeType = 'application/rtf';
			filename = 'Music_Promotion_Strategy.rtf';
			break;
		default:
			return;
	}

	const blob = new Blob([content], { type: mimeType });
	const url = URL.createObjectURL(blob);
	const link = document.createElement('a');
	link.href = url;
	link.download = filename;
	document.body.appendChild(link);
	link.click();
	document.body.removeChild(link);
	URL.revokeObjectURL(url);
};

function App() {
	const [formData, setFormData] = useState({
		name: "",
		phone: "",
		email: "",
		consultationAbout: "",
		message: "",
		files: [] as File[],
		urls: [""] as string[],
		budget: 50,
		// Music submission fields
		artistName: "",
		trackTitle: "",
		musicGenre: "",
		trackLink: "",
	});
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [submitted, setSubmitted] = useState(false);
	const [activeDialog, setActiveDialog] = useState<DialogType>(null);
	const [showStrategyDropdown, setShowStrategyDropdown] = useState(false);
	const [showWhatsAppPopup, setShowWhatsAppPopup] = useState(false);

	// Show WhatsApp channel popup after a delay
	useEffect(() => {
		const hasSeenPopup = localStorage.getItem("whatsapp-channel-popup-seen");
		if (!hasSeenPopup) {
			const timer = setTimeout(() => {
				setShowWhatsAppPopup(true);
			}, 3000); // Show after 3 seconds
			return () => clearTimeout(timer);
		}
	}, []);

	const handleWhatsAppPopupClose = () => {
		setShowWhatsAppPopup(false);
		localStorage.setItem("whatsapp-channel-popup-seen", "true");
	};

	const handleWhatsAppChannelClick = () => {
		localStorage.setItem("whatsapp-channel-popup-seen", "true");
		window.open("https://whatsapp.com/channel/0029Vb768eZKrWR1ZkPEWZ1Y", "_blank");
		setShowWhatsAppPopup(false);
	};

	// Get current dialog config
	const currentDialogConfig = activeDialog ? dialogConfigs[activeDialog] : null;

	// WhatsApp number with Uganda country code
	const whatsappNumber = "256701705378";

	// Upload files to file.io and get shareable links
	const uploadFilesToFileIO = async (files: File[]): Promise<{ name: string; link: string }[]> => {
		const uploadedLinks: { name: string; link: string }[] = [];

		for (const file of files) {
			try {
				const formData = new FormData();
				formData.append("file", file);

				const response = await fetch("https://file.io", {
					method: "POST",
					body: formData,
				});

				const result = await response.json();

				if (result.success && result.link) {
					uploadedLinks.push({
						name: file.name,
						link: result.link,
					});
				} else {
					// If file.io fails, try tmpfiles.org as fallback
					const fallbackFormData = new FormData();
					fallbackFormData.append("file", file);

					const fallbackResponse = await fetch("https://tmpfiles.org/api/v1/upload", {
						method: "POST",
						body: fallbackFormData,
					});

					const fallbackResult = await fallbackResponse.json();

					if (fallbackResult.status === "success" && fallbackResult.data?.url) {
						// Convert tmpfiles.org URL to direct download link
						const directLink = fallbackResult.data.url.replace("tmpfiles.org/", "tmpfiles.org/dl/");
						uploadedLinks.push({
							name: file.name,
							link: directLink,
						});
					}
				}
			} catch (error) {
				console.error(`Failed to upload ${file.name}:`, error);
			}
		}

		return uploadedLinks;
	};

	// EmailJS configuration - Replace these with your actual EmailJS credentials
	const EMAILJS_SERVICE_ID = "service_troydigital";
	const EMAILJS_TEMPLATE_ID = "template_confirmation";
	const EMAILJS_PUBLIC_KEY = "YOUR_EMAILJS_PUBLIC_KEY";

	// Send confirmation email to user
	const sendConfirmationEmail = async (emailData: {
		to_email: string;
		to_name: string;
		inquiry_type: string;
		order_details: string;
	}) => {
		try {
			await emailjs.send(
				EMAILJS_SERVICE_ID,
				EMAILJS_TEMPLATE_ID,
				{
					to_email: emailData.to_email,
					to_name: emailData.to_name,
					inquiry_type: emailData.inquiry_type,
					order_details: emailData.order_details,
					company_name: "Troy Digital Desk",
					company_website: "troydigitaldesk.online",
					reply_to: "info@troydigitaldesk.online",
				},
				EMAILJS_PUBLIC_KEY
			);
			return true;
		} catch {
			console.error("Failed to send confirmation email");
			return false;
		}
	};

	const handleSubmit = async (e: React.FormEvent) => {
		e.preventDefault();
		setIsSubmitting(true);

		// Build WhatsApp message
		const dialogTitle = currentDialogConfig?.title ?? "General Inquiry";
		const serviceName = formData.consultationAbout
			? services.find((s) => s.slug === formData.consultationAbout)?.name ?? formData.consultationAbout
			: "Not specified";

		let message = `*${dialogTitle}*%0A%0A`;
		message += `*Name:* ${formData.name}%0A`;
		message += `*Phone:* ${formData.phone}%0A`;
		message += `*Email:* ${formData.email}%0A`;

		if (currentDialogConfig?.showServices) {
			message += `*Service:* ${serviceName}%0A`;
		}

		// Upload files and get download links
		let uploadedFileLinks: { name: string; link: string }[] = [];
		if (formData.files.length > 0) {
			uploadedFileLinks = await uploadFilesToFileIO(formData.files);
		}

		if (currentDialogConfig?.showSubmissionFields) {
			// Add files with download links
			if (uploadedFileLinks.length > 0) {
				message += `*Files:*%0A`;
				for (const fileLink of uploadedFileLinks) {
					message += `📁 ${fileLink.name}: ${fileLink.link}%0A`;
				}
			} else if (formData.files.length > 0) {
				// Files were selected but upload failed
				message += `*Files:* ${formData.files.map((f) => f.name).join(", ")} _(upload pending)_%0A`;
			}
			// Add URLs
			const validUrls = formData.urls.filter((url) => url.trim());
			if (validUrls.length > 0) {
				message += `*URLs:* ${validUrls.join(", ")}%0A`;
			}
			// Add budget
			message += `*Budget:* $${formData.budget} USD (UGX ${(formData.budget * 3750).toLocaleString()})%0A`;
		}

		// Add music submission fields
		if (currentDialogConfig?.showMusicSubmissionForm) {
			message += `*Artist Name:* ${formData.artistName}%0A`;
			message += `*Track Title:* ${formData.trackTitle}%0A`;
			message += `*Genre:* ${formData.musicGenre}%0A`;
			message += `*Track Link:* ${formData.trackLink}%0A`;
		}

		if (formData.message) {
			message += `%0A*Message:*%0A${formData.message}`;
		}

		// Build email order details
		let orderDetails = `Inquiry Type: ${dialogTitle}\n\n`;
		orderDetails += `Name: ${formData.name}\n`;
		orderDetails += `Phone: ${formData.phone}\n`;
		orderDetails += `Email: ${formData.email}\n`;

		if (currentDialogConfig?.showServices) {
			orderDetails += `Service: ${serviceName}\n`;
		}

		if (currentDialogConfig?.showSubmissionFields) {
			if (uploadedFileLinks.length > 0) {
				orderDetails += `Files:\n`;
				for (const fileLink of uploadedFileLinks) {
					orderDetails += `  - ${fileLink.name}: ${fileLink.link}\n`;
				}
			} else if (formData.files.length > 0) {
				orderDetails += `Files: ${formData.files.map((f) => f.name).join(", ")} (upload pending)\n`;
			}
			const validUrls = formData.urls.filter((url) => url.trim());
			if (validUrls.length > 0) {
				orderDetails += `URLs: ${validUrls.join(", ")}\n`;
			}
			orderDetails += `Budget: $${formData.budget} USD (UGX ${(formData.budget * 3750).toLocaleString()})\n`;
		}

		// Add music submission fields to email
		if (currentDialogConfig?.showMusicSubmissionForm) {
			orderDetails += `Artist Name: ${formData.artistName}\n`;
			orderDetails += `Track Title: ${formData.trackTitle}\n`;
			orderDetails += `Genre: ${formData.musicGenre}\n`;
			orderDetails += `Track Link: ${formData.trackLink}\n`;
		}

		if (formData.message) {
			orderDetails += `\nMessage:\n${formData.message}`;
		}

		// Open WhatsApp with the message (file links are already included)
		window.open(`https://wa.me/${whatsappNumber}?text=${message}`, "_blank");

		// Show success message if files were uploaded
		if (formData.files.length > 0 && uploadedFileLinks.length > 0) {
			setTimeout(() => {
				alert(`✅ ${uploadedFileLinks.length} file(s) uploaded successfully!\n\nDownload links have been included in your WhatsApp message.`);
			}, 500);
		} else if (formData.files.length > 0 && uploadedFileLinks.length === 0) {
			// Files were selected but upload failed
			setTimeout(() => {
				alert(
					`⚠️ File upload failed. Please share your files manually:\n\n1. Open WhatsApp\n2. Go to the chat with Troy Digital Desk\n3. Tap the attachment icon (+)\n4. Select and send your files\n\nOr use Google Drive/Dropbox and send the links.`
				);
			}, 500);
		}

		// Send confirmation email to user
		await sendConfirmationEmail({
			to_email: formData.email,
			to_name: formData.name,
			inquiry_type: dialogTitle,
			order_details: orderDetails,
		});

		// Show success state
		setTimeout(() => {
			setIsSubmitting(false);
			setSubmitted(true);
			setFormData({ name: "", phone: "", email: "", consultationAbout: "", message: "", files: [], urls: [""], budget: 50, artistName: "", trackTitle: "", musicGenre: "", trackLink: "" });
			// Reset submitted state and close dialog after 3 seconds
			setTimeout(() => {
				setSubmitted(false);
				setActiveDialog(null);
			}, 3000);
		}, 500);
	};

	return (
		<div className="min-h-screen bg-zinc-950 text-white relative overflow-hidden">
			{/* Layer 1: Background Image with Blur */}
			<div className="absolute inset-0">
				{/* Background Image */}
				<div
					className="absolute inset-0 bg-cover bg-center bg-no-repeat scale-110"
					style={{
						backgroundImage: 'url(https://certiprof.com/cdn/shop/articles/DIGITAL_MARKETING_BY_CERTIPROF.webp?v=1742398487)',
						filter: 'blur(8px)',
					}}
				/>
				{/* Dark Overlay for Readability */}
				<div className="absolute inset-0 bg-gradient-to-b from-zinc-950/85 via-zinc-950/80 to-zinc-950/90" />
				{/* Subtle Color Accent Overlay */}
				<div className="absolute inset-0 bg-gradient-to-br from-[#BFFF00]/5 via-transparent to-purple-900/10" />
			</div>
			{/* Subtle Grid Pattern Overlay */}
			<div
				className="absolute inset-0 opacity-10"
				style={{
					backgroundImage: `
						linear-gradient(rgba(255,255,255,0.05) 1px, transparent 1px),
						linear-gradient(90deg, rgba(255,255,255,0.05) 1px, transparent 1px)
					`,
					backgroundSize: '80px 80px',
					backgroundPosition: 'center bottom',
					maskImage: 'linear-gradient(to top, rgba(0,0,0,0.3) 0%, transparent 60%)',
					WebkitMaskImage: 'linear-gradient(to top, rgba(0,0,0,0.3) 0%, transparent 60%)',
				}}
			/>

			{/* Content Container */}
			<div className="relative z-10 min-h-screen flex flex-col">
				{/* Layer 2: Header Bar */}
				<header className="border-b border-white/10 px-3 sm:px-6 lg:px-12 py-2.5 sm:py-3 lg:py-4 bg-zinc-950/40 backdrop-blur-md">
					<div className="flex items-center justify-between max-w-7xl mx-auto">
						{/* Left: Troy - Digital Marketer */}
						<span className="hidden sm:block text-[10px] sm:text-xs lg:text-sm text-zinc-400 tracking-wide min-w-0 flex-shrink-0">Troy - Digital Marketer</span>

						{/* Center: Logo */}
						<div className="flex-1 sm:flex-none flex items-center justify-center px-2">
							<img
								src="https://troydigitaldesk.online/wp-content/uploads/2025/09/logo-top.png"
								alt="Troy Digital Desk"
								className="h-5 sm:h-6 lg:h-8 w-auto"
							/>
						</div>

						{/* Right: Call Me Today Button */}
						<a
							href="tel:+256701705378"
							className="hidden sm:flex items-center gap-1.5 text-[10px] sm:text-xs lg:text-sm bg-[#BFFF00] hover:bg-[#a8e600] text-zinc-900 font-semibold px-2.5 sm:px-3 lg:px-4 py-1 sm:py-1.5 rounded-full transition-all hover:scale-105"
						>
							<svg className="size-3 lg:size-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
								<path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
							</svg>
							Call Me Today
						</a>
					</div>
				</header>

				{/* Portfolio Carousel - Scrolls Left (Text Only) */}
				<div className="relative overflow-hidden bg-zinc-900/30 backdrop-blur-sm border-b border-white/5">
					{/* Gradient overlays for smooth edges */}
					<div className="absolute left-0 top-0 bottom-0 w-8 sm:w-16 lg:w-24 bg-gradient-to-r from-zinc-950 to-transparent z-10 pointer-events-none" />
					<div className="absolute right-0 top-0 bottom-0 w-8 sm:w-16 lg:w-24 bg-gradient-to-l from-zinc-950 to-transparent z-10 pointer-events-none" />

					{/* Scrolling container */}
					<div className="flex items-center animate-scroll py-1.5 sm:py-2">
						{/* First set of items */}
						{portfolios.map((item, index) => (
							<div
								key={`first-${index}`}
								className="flex-shrink-0 mx-2 sm:mx-3 lg:mx-4 group cursor-pointer flex items-center gap-1.5 sm:gap-2"
							>
								<span className="text-[#BFFF00] text-[10px] sm:text-xs">•</span>
								<div className="flex flex-col">
									<p className="text-[9px] sm:text-[10px] lg:text-xs text-white font-medium whitespace-nowrap group-hover:text-[#BFFF00] transition-colors">{item.title}</p>
									<p className="text-[7px] sm:text-[8px] lg:text-[10px] text-zinc-500">{item.date}</p>
								</div>
							</div>
						))}
						{/* Duplicate set for seamless loop */}
						{portfolios.map((item, index) => (
							<div
								key={`second-${index}`}
								className="flex-shrink-0 mx-2 sm:mx-3 lg:mx-4 group cursor-pointer flex items-center gap-1.5 sm:gap-2"
							>
								<span className="text-[#BFFF00] text-[10px] sm:text-xs">•</span>
								<div className="flex flex-col">
									<p className="text-[9px] sm:text-[10px] lg:text-xs text-white font-medium whitespace-nowrap group-hover:text-[#BFFF00] transition-colors">{item.title}</p>
									<p className="text-[7px] sm:text-[8px] lg:text-[10px] text-zinc-500">{item.date}</p>
								</div>
							</div>
						))}
					</div>
				</div>

				{/* Main Content */}
				<main className="flex-1 px-3 sm:px-5 lg:px-8 xl:px-12 py-4 sm:py-6 lg:py-8 xl:py-10">
					<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-4 sm:gap-5 lg:gap-6 xl:gap-8 h-full max-w-7xl mx-auto">
						{/* Left Column - Headline always first */}
						<div className="md:col-span-1 lg:col-span-7 flex flex-col justify-between gap-4 lg:gap-0">
							{/* Headline */}
							<div className="space-y-1.5 sm:space-y-2 text-center md:text-left">
								<h1 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl text-white/90 leading-tight">
									<span className="font-semibold">Build your network</span><br className="hidden sm:block" /><span className="sm:hidden"> </span><span className="font-bold italic text-[#BFFF00]">Gain exposure</span><br className="hidden sm:block" /><span className="sm:hidden"> </span><span className="font-normal">Get Heard</span>
								</h1>
								<p className="text-[#BFFF00] text-lg sm:text-xl md:text-2xl lg:text-3xl xl:text-4xl font-medium ml-0 md:ml-12 lg:ml-16 xl:ml-24 mt-1.5 sm:mt-2 md:mt-3">
									Get on Air.
								</p>

								{/* Submit Music & Active Campaign Buttons */}
								<div className="mt-3 sm:mt-4 flex flex-wrap justify-center sm:justify-start gap-2 sm:gap-3">
									<button
										onClick={() => setActiveDialog("submit-music")}
										className="inline-flex items-center gap-2 bg-gradient-to-r from-[#BFFF00] to-[#a8e600] rounded-full px-4 sm:px-6 py-2 sm:py-2.5 group cursor-pointer hover:from-[#a8e600] hover:to-[#BFFF00] transition-all shadow-lg shadow-[#BFFF00]/20 hover:scale-105"
									>
										<svg className="size-4 sm:size-5 text-zinc-900" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
										</svg>
										<span className="text-xs sm:text-sm font-semibold text-zinc-900">Submit Your Music</span>
										<ChevronRight className="size-3 sm:size-4 text-zinc-900 group-hover:translate-x-0.5 transition-transform" />
									</button>
									<Link
										to="/active-campaigns"
										className="inline-flex items-center gap-2 bg-zinc-900/80 border border-[#BFFF00]/50 rounded-full px-4 sm:px-6 py-2 sm:py-2.5 group cursor-pointer hover:bg-[#BFFF00]/10 hover:border-[#BFFF00] transition-all hover:scale-105"
									>
										<svg className="size-4 sm:size-5 text-[#BFFF00]" fill="currentColor" viewBox="0 0 24 24">
											<path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
										</svg>
										<span className="text-xs sm:text-sm font-semibold text-[#BFFF00]">Active Campaign</span>
										<ChevronRight className="size-3 sm:size-4 text-[#BFFF00] group-hover:translate-x-0.5 transition-transform" />
									</Link>
								</div>
							</div>

							{/* Visual Stats Graphics - Channel Crawler Style */}
							<div className="flex flex-col gap-2 lg:gap-3 mt-3 xl:mt-4">
								{/* Main Search Stat Box */}
								<div className="relative bg-gradient-to-r from-zinc-900/90 via-zinc-800/80 to-zinc-900/90 backdrop-blur-md rounded-lg p-3 lg:p-4 border border-zinc-700/40 overflow-hidden max-w-md">
									{/* Decorative gradient orb */}
									<div className="absolute -top-8 -right-8 size-20 lg:size-24 bg-[#BFFF00]/10 rounded-full blur-2xl" />
									<div className="absolute -bottom-6 -left-6 size-16 lg:size-20 bg-red-500/10 rounded-full blur-2xl" />

									{/* Content */}
									<div className="relative z-10">
										<div className="flex items-center gap-1.5 mb-1">
											<svg className="size-3 lg:size-4 text-[#BFFF00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
												<path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
											</svg>
											<span className="text-[10px] lg:text-xs text-zinc-400 font-medium">Search</span>
										</div>
										<p className="text-xl lg:text-2xl font-bold text-white">
											100<span className="text-[#BFFF00]">+</span>
										</p>
										<p className="text-[10px] lg:text-xs text-zinc-500 mt-0.5">channels managed</p>

										{/* Client Cards - Directly below 100+ */}
										<div className="flex items-center gap-2 lg:gap-3 mt-2 overflow-x-auto pb-1 scrollbar-hide">
											{/* Karitas Kario */}
											<div className="flex items-center gap-1 bg-zinc-800/50 rounded-md px-1.5 py-1 border border-zinc-700/30 hover:border-[#BFFF00]/40 transition-colors group flex-shrink-0">
												<img
													src="https://viberate-upload.ams3.cdn.digitaloceanspaces.com/prod/entity/artist/karitas-kario-SnE13"
													alt="Karitas Kario"
													className="size-5 lg:size-6 rounded-full object-cover border border-zinc-600 group-hover:border-[#BFFF00]/50"
												/>
												<span className="text-[8px] lg:text-[9px] text-zinc-400 group-hover:text-[#BFFF00] transition-colors whitespace-nowrap">Karitas Kario</span>
											</div>

											{/* Acidic Vokoz */}
											<div className="flex items-center gap-1 bg-zinc-800/50 rounded-md px-1.5 py-1 border border-zinc-700/30 hover:border-[#BFFF00]/40 transition-colors group flex-shrink-0">
												<img
													src="https://media.afrocharts.com/file/afrocharts-media/uploads/2024/6/1677167562-77010-mp3-thumb-afrocharts-66770d8797b670490326a17.jpg"
													alt="Acidic Vokoz"
													className="size-5 lg:size-6 rounded-full object-cover border border-zinc-600 group-hover:border-[#BFFF00]/50"
												/>
												<span className="text-[8px] lg:text-[9px] text-zinc-400 group-hover:text-[#BFFF00] transition-colors whitespace-nowrap">Acidic Vokoz</span>
											</div>

											{/* Lil Pazo */}
											<div className="flex items-center gap-1 bg-zinc-800/50 rounded-md px-1.5 py-1 border border-zinc-700/30 hover:border-[#BFFF00]/40 transition-colors group flex-shrink-0">
												<img
													src="https://cdn.howwe.ug/_arts_/_180_/howwe_972fea3d71eca0f68050dadddfcf879f_1485410972.jpg"
													alt="Lil Pazo"
													className="size-5 lg:size-6 rounded-full object-cover border border-zinc-600 group-hover:border-[#BFFF00]/50"
												/>
												<span className="text-[8px] lg:text-[9px] text-zinc-400 group-hover:text-[#BFFF00] transition-colors whitespace-nowrap">Lil Pazo</span>
											</div>

											{/* +50 More */}
											<div className="flex items-center gap-1 bg-zinc-800/50 rounded-md px-1.5 py-1 border border-dashed border-zinc-700/30 hover:border-[#BFFF00]/40 transition-colors group flex-shrink-0">
												<div className="size-5 lg:size-6 rounded-full bg-zinc-700/50 flex items-center justify-center border border-dashed border-zinc-600">
													<span className="text-[8px] lg:text-[9px] font-medium text-zinc-500">+</span>
												</div>
												<span className="text-[8px] lg:text-[9px] text-zinc-500 group-hover:text-[#BFFF00] transition-colors whitespace-nowrap">50+</span>
											</div>
										</div>
									</div>
								</div>

								{/* Platform Icons Row */}
								<div className="flex items-center justify-center sm:justify-start gap-2 lg:gap-3 overflow-x-auto pb-1 scrollbar-hide">
									{/* YouTube */}
									<div className="flex items-center gap-1.5 bg-zinc-900/50 rounded-lg px-2.5 py-1.5 lg:px-3 lg:py-2 border border-zinc-800/50 flex-shrink-0">
										<div className="size-5 lg:size-6 bg-red-600 rounded flex items-center justify-center">
											<svg className="size-3 lg:size-3.5 text-white" viewBox="0 0 24 24" fill="currentColor">
												<path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
											</svg>
										</div>
										<span className="text-[10px] lg:text-xs text-zinc-400">YouTube</span>
									</div>

									{/* TikTok */}
									<div className="flex items-center gap-1.5 bg-zinc-900/50 rounded-lg px-2.5 py-1.5 lg:px-3 lg:py-2 border border-zinc-800/50 flex-shrink-0">
										<div className="size-5 lg:size-6 bg-black rounded flex items-center justify-center">
											<svg className="size-3 lg:size-3.5" viewBox="0 0 24 24" fill="none">
												<path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.88 2.89 2.89 0 0 1-2.88-2.88 2.89 2.89 0 0 1 2.88-2.88c.28 0 .54.04.79.1V9.4a6.33 6.33 0 0 0-.79-.05A6.34 6.34 0 0 0 3.15 15.7a6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.34-6.34V9.26a8.28 8.28 0 0 0 4.76 1.5V7.32a4.83 4.83 0 0 1-1-.63z" fill="white"/>
											</svg>
										</div>
										<span className="text-[10px] lg:text-xs text-zinc-400">TikTok</span>
									</div>

									{/* Instagram */}
									<div className="flex items-center gap-1.5 bg-zinc-900/50 rounded-lg px-2.5 py-1.5 lg:px-3 lg:py-2 border border-zinc-800/50 flex-shrink-0">
										<div className="size-5 lg:size-6 bg-gradient-to-br from-purple-600 via-pink-500 to-orange-400 rounded flex items-center justify-center">
											<svg className="size-3 lg:size-3.5 text-white" viewBox="0 0 24 24" fill="currentColor">
												<path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
											</svg>
										</div>
										<span className="text-[10px] lg:text-xs text-zinc-400">Instagram</span>
									</div>
								</div>
							</div>

							{/* Layer 7: Quote */}
							<div className="mt-4 lg:mt-0 space-y-1.5 hidden md:block">
								<div className="flex gap-0.5 sm:gap-1">
									<div className="w-1 sm:w-1.5 h-5 sm:h-6 lg:h-7 bg-[#BFFF00]" />
									<div className="w-1 sm:w-1.5 h-5 sm:h-6 lg:h-7 bg-[#BFFF00]" />
								</div>
								<p className="text-zinc-400 text-xs sm:text-sm lg:text-base">
									Lets Handle<br />
									your <span className="text-[#BFFF00]">Music</span><br />
									Project
								</p>
							</div>
						</div>

						{/* Right Column */}
						<div className="col-span-1 md:col-span-1 lg:col-span-5 flex flex-col justify-between gap-3 sm:gap-4 lg:gap-5">
							{/* Layer 6: Services Card */}
							<div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-lg lg:rounded-xl p-3 sm:p-4 lg:p-5 shadow-xl">
								<h3 className="text-sm sm:text-base lg:text-lg font-semibold mb-2 sm:mb-3 text-white">Services</h3>
								<div className="grid grid-cols-1 gap-1.5 sm:gap-2">
									{services.map((service) => (
										<Link
											key={service.slug}
											to="/services/$serviceId"
											params={{ serviceId: service.slug }}
											className="flex items-center gap-2 sm:gap-2.5 p-2 sm:p-2.5 bg-zinc-800/50 rounded-lg border border-zinc-700/50 hover:border-[#BFFF00]/50 hover:bg-zinc-800/80 transition-all duration-200 group/service"
										>
											<div
												className="size-7 sm:size-8 rounded-lg flex items-center justify-center flex-shrink-0"
												style={{ backgroundColor: `${service.color}15` }}
											>
												{service.icon === "music" && (
													<svg className="size-3.5 sm:size-4" style={{ color: service.color }} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
														<path strokeLinecap="round" strokeLinejoin="round" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
													</svg>
												)}
												{service.icon === "youtube" && (
													<svg className="size-3.5 sm:size-4" style={{ color: service.color }} viewBox="0 0 24 24" fill="currentColor">
														<path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
													</svg>
												)}
												{service.icon === "brand" && (
													<svg className="size-3.5 sm:size-4" style={{ color: service.color }} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
														<path strokeLinecap="round" strokeLinejoin="round" d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01" />
													</svg>
												)}
												{service.icon === "playlist" && (
													<svg className="size-3.5 sm:size-4" style={{ color: service.color }} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
														<path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 10h16M4 14h10m-10 4h6" />
													</svg>
												)}
												{service.icon === "distribution" && (
													<svg className="size-3.5 sm:size-4" style={{ color: service.color }} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
														<path strokeLinecap="round" strokeLinejoin="round" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
													</svg>
												)}
												{service.icon === "social" && (
													<svg className="size-3.5 sm:size-4" style={{ color: service.color }} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
														<path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
													</svg>
												)}
											</div>
											<div className="flex-1 min-w-0">
												<p className="text-[11px] sm:text-xs lg:text-sm font-medium text-white group-hover/service:text-[#BFFF00] transition-colors truncate">{service.name}</p>
												<p className="text-[9px] sm:text-[10px] text-zinc-500 truncate">{service.description}</p>
											</div>
											<ChevronRight className="size-3 sm:size-3.5 text-zinc-600 group-hover/service:text-[#BFFF00] group-hover/service:translate-x-0.5 transition-all flex-shrink-0" />
										</Link>
									))}
								</div>

							</div>

							{/* Mobile: Quote section visible on small screens */}
							<div className="space-y-1.5 md:hidden">
								<div className="flex gap-0.5">
									<div className="w-1 h-5 bg-[#BFFF00]" />
									<div className="w-1 h-5 bg-[#BFFF00]" />
								</div>
								<p className="text-zinc-400 text-xs sm:text-sm">
									Lets Handle your <span className="text-[#BFFF00]">Music</span> Project
								</p>
							</div>

							{/* Social Icons Row - Mobile */}
							<div className="flex flex-wrap items-center gap-1.5 sm:gap-2 md:hidden">
								{/* Spotify */}
								<div className="inline-flex items-center gap-1 bg-zinc-800/50 backdrop-blur-sm rounded-md px-1.5 py-1 border border-zinc-700/50">
									<div className="size-4 bg-[#1DB954] rounded flex items-center justify-center">
										<svg className="size-2.5 text-white" viewBox="0 0 24 24" fill="currentColor">
											<path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/>
										</svg>
									</div>
									<span className="text-[8px] sm:text-[10px] text-zinc-400">Spotify</span>
								</div>
								{/* TikTok */}
								<div className="inline-flex items-center gap-1 bg-zinc-800/50 backdrop-blur-sm rounded-md px-1.5 py-1 border border-zinc-700/50">
									<div className="size-4 bg-black rounded flex items-center justify-center relative overflow-hidden">
										<svg className="size-2.5" viewBox="0 0 24 24" fill="none">
											<path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.88 2.89 2.89 0 0 1-2.88-2.88 2.89 2.89 0 0 1 2.88-2.88c.28 0 .54.04.79.1V9.4a6.33 6.33 0 0 0-.79-.05A6.34 6.34 0 0 0 3.15 15.7a6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.34-6.34V9.26a8.28 8.28 0 0 0 4.76 1.5V7.32a4.83 4.83 0 0 1-1-.63z" fill="white"/>
										</svg>
									</div>
									<span className="text-[8px] sm:text-[10px] text-zinc-400">TikTok</span>
								</div>
							</div>

							{/* Layer 5: Spotify & TikTok Icons - Desktop Only */}
							<div className="hidden md:flex justify-start gap-2 lg:gap-3">
								{/* Spotify */}
								<div className="size-7 lg:size-8 bg-[#1DB954] rounded-full flex items-center justify-center border border-zinc-700/50 shadow-md">
									<svg className="size-4 lg:size-5 text-white" viewBox="0 0 24 24" fill="currentColor">
										<path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/>
									</svg>
								</div>
								{/* TikTok */}
								<div className="size-7 lg:size-8 bg-black rounded-full flex items-center justify-center border border-zinc-700/50 shadow-md relative overflow-hidden">
									<svg className="size-4 lg:size-5" viewBox="0 0 24 24" fill="none">
										<path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.88 2.89 2.89 0 0 1-2.88-2.88 2.89 2.89 0 0 1 2.88-2.88c.28 0 .54.04.79.1V9.4a6.33 6.33 0 0 0-.79-.05A6.34 6.34 0 0 0 3.15 15.7a6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.34-6.34V9.26a8.28 8.28 0 0 0 4.76 1.5V7.32a4.83 4.83 0 0 1-1-.63z" fill="#25F4EE"/>
										<path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.88 2.89 2.89 0 0 1-2.88-2.88 2.89 2.89 0 0 1 2.88-2.88c.28 0 .54.04.79.1V9.4a6.33 6.33 0 0 0-.79-.05A6.34 6.34 0 0 0 3.15 15.7a6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.34-6.34V9.26a8.28 8.28 0 0 0 4.76 1.5V7.32a4.83 4.83 0 0 1-1-.63z" fill="#FE2C55" style={{transform: 'translate(2px, -2px)'}}/>
										<path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.88 2.89 2.89 0 0 1-2.88-2.88 2.89 2.89 0 0 1 2.88-2.88c.28 0 .54.04.79.1V9.4a6.33 6.33 0 0 0-.79-.05A6.34 6.34 0 0 0 3.15 15.7a6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.34-6.34V9.26a8.28 8.28 0 0 0 4.76 1.5V7.32a4.83 4.83 0 0 1-1-.63z" fill="white"/>
									</svg>
								</div>
							</div>

							{/* Strategy & Hire Me Row - Horizontal Layout */}
							<div className="flex gap-2 sm:gap-3">
								{/* Strategy Download Button */}
								<div className="relative flex-1">
									<button
										onClick={() => setShowStrategyDropdown(!showStrategyDropdown)}
										className="w-full bg-gradient-to-r from-zinc-800 to-zinc-900 backdrop-blur-sm border border-zinc-700 rounded-md lg:rounded-lg p-2 sm:p-2.5 lg:p-3 flex items-center justify-between group cursor-pointer hover:border-[#BFFF00]/50 hover:from-zinc-700 hover:to-zinc-800 transition-all"
									>
										<div className="flex items-center gap-1.5 sm:gap-2">
											<FileText className="size-3 sm:size-4 text-[#BFFF00]" />
											<span className="text-xs sm:text-sm lg:text-base font-semibold text-white group-hover:text-[#BFFF00] transition-colors">
												Strategy
											</span>
										</div>
										<Download className="size-3 sm:size-4 text-[#BFFF00] group-hover:translate-y-0.5 transition-transform" />
									</button>

									{/* Dropdown Menu */}
									{showStrategyDropdown && (
										<div className="absolute top-full left-0 right-0 mt-1 bg-zinc-900 border border-zinc-700 rounded-md lg:rounded-lg overflow-hidden shadow-xl shadow-black/50 z-20">
											<p className="px-2 sm:px-3 py-1.5 text-[8px] sm:text-[10px] text-zinc-400 border-b border-zinc-700 bg-zinc-800/50">
												Download Music Promotion Strategy
											</p>
											<button
												onClick={() => { downloadStrategy('html'); setShowStrategyDropdown(false); }}
												className="w-full px-2 sm:px-3 py-1.5 sm:py-2 text-left text-[10px] sm:text-xs text-white hover:bg-[#BFFF00]/10 hover:text-[#BFFF00] transition-colors flex items-center gap-2"
											>
												<span className="size-4 sm:size-5 rounded bg-orange-500/20 text-orange-400 flex items-center justify-center text-[8px] sm:text-[10px] font-bold">H</span>
												HTML Document (.html)
											</button>
											<button
												onClick={() => { downloadStrategy('rtf'); setShowStrategyDropdown(false); }}
												className="w-full px-2 sm:px-3 py-1.5 sm:py-2 text-left text-[10px] sm:text-xs text-white hover:bg-[#BFFF00]/10 hover:text-[#BFFF00] transition-colors flex items-center gap-2"
											>
												<span className="size-4 sm:size-5 rounded bg-blue-500/20 text-blue-400 flex items-center justify-center text-[8px] sm:text-[10px] font-bold">R</span>
												Rich Text Format (.rtf)
											</button>
											<button
												onClick={() => { downloadStrategy('txt'); setShowStrategyDropdown(false); }}
												className="w-full px-2 sm:px-3 py-1.5 sm:py-2 text-left text-[10px] sm:text-xs text-white hover:bg-[#BFFF00]/10 hover:text-[#BFFF00] transition-colors flex items-center gap-2"
											>
												<span className="size-4 sm:size-5 rounded bg-zinc-500/20 text-zinc-400 flex items-center justify-center text-[8px] sm:text-[10px] font-bold">T</span>
												Plain Text (.txt)
											</button>
										</div>
									)}
								</div>

								{/* Hire Me CTA Box */}
								<Link
									to="/hire-me"
									className="flex-1 bg-zinc-900/80 backdrop-blur-sm border border-zinc-800 rounded-md lg:rounded-lg p-2 sm:p-2.5 lg:p-3 relative overflow-hidden group cursor-pointer hover:border-[#BFFF00]/50 transition-colors"
								>
									{/* Yellow corner accent */}
									<div className="absolute bottom-1 right-1 sm:bottom-1.5 sm:right-1.5 size-1 sm:size-1.5 rounded-full bg-[#BFFF00]" />

									<div className="flex items-center justify-between">
										<span className="text-xs sm:text-sm lg:text-base font-bold text-[#BFFF00] group-hover:translate-x-1 transition-transform">
											Hire Me...
										</span>
										<ChevronRight className="size-3 sm:size-4 text-[#BFFF00] group-hover:translate-x-1 transition-transform" />
									</div>
								</Link>
							</div>
						</div>
					</div>
				</main>

				{/* Inquiry Form Dialog */}
				<Dialog open={activeDialog !== null} onOpenChange={(open) => !open && setActiveDialog(null)}>
					<DialogContent className="bg-zinc-900 text-white border-0 p-0 overflow-hidden shadow-2xl shadow-[#BFFF00]/10 w-[calc(100%-0.5rem)] sm:w-full max-w-md h-[calc(100vh-1rem)] sm:h-auto sm:max-h-[90vh] flex flex-col">
						{/* Gradient border wrapper */}
						<div className="absolute inset-0 rounded-lg bg-gradient-to-br from-[#BFFF00] via-zinc-600 to-[#BFFF00]/50 p-[1px]">
							<div className="absolute inset-[1px] rounded-lg bg-zinc-900" />
						</div>
						<div className="relative p-3 sm:p-6 overflow-y-auto flex-1 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
						{/* Logo above heading - only for About Us */}
						{currentDialogConfig?.showInfoOnly && (
							<div className="text-center mb-2 sm:mb-4">
								<img
									src="https://troydigitaldesk.online/wp-content/uploads/2025/09/logo-top.png"
									alt="Troy Digital Desk"
									className="h-8 sm:h-10 w-auto mx-auto"
								/>
							</div>
						)}
						<DialogHeader className="space-y-1 sm:space-y-2">
							<DialogTitle className="text-base sm:text-xl font-semibold text-white text-center">
								{currentDialogConfig?.title ?? "Get in Touch"}
							</DialogTitle>
							<DialogDescription className="text-zinc-400 text-xs sm:text-sm text-center">
								{currentDialogConfig?.description ?? "Fill out the form below and we'll get back to you shortly"}
							</DialogDescription>
						</DialogHeader>

						{/* About Us Info Popup */}
						{currentDialogConfig?.showInfoOnly ? (
							<div className="py-2 sm:py-4 space-y-3 sm:space-y-6">
								{/* Who We Are */}
								<div className="space-y-2">
									<h3 className="text-[#BFFF00] font-semibold text-sm uppercase tracking-wider">Who We Are</h3>
									<p className="text-zinc-300 text-sm leading-relaxed">
										Troy Digital Desk is a premier digital marketing agency specializing in music promotion and artist development.
										We help independent artists and labels gain exposure, grow their audience, and get their music heard worldwide.
									</p>
								</div>

								{/* What We Do */}
								<div className="space-y-2">
									<h3 className="text-[#BFFF00] font-semibold text-sm uppercase tracking-wider">What We Do</h3>
									<ul className="text-zinc-300 text-sm space-y-1.5">
										<li className="flex items-start gap-2">
											<span className="text-[#BFFF00] mt-1">•</span>
											<span>Music Promotion on Spotify, YouTube, TikTok & more</span>
										</li>
										<li className="flex items-start gap-2">
											<span className="text-[#BFFF00] mt-1">•</span>
											<span>Playlist Pitching to curators and influencers</span>
										</li>
										<li className="flex items-start gap-2">
											<span className="text-[#BFFF00] mt-1">•</span>
											<span>Social Media Growth & Marketing</span>
										</li>
										<li className="flex items-start gap-2">
											<span className="text-[#BFFF00] mt-1">•</span>
											<span>Music Distribution to 200+ platforms worldwide</span>
										</li>
										<li className="flex items-start gap-2">
											<span className="text-[#BFFF00] mt-1">•</span>
											<span>Brand Development & Marketing Strategy</span>
										</li>
									</ul>
								</div>

								{/* Our Mission */}
								<div className="space-y-2">
									<h3 className="text-[#BFFF00] font-semibold text-sm uppercase tracking-wider">Our Mission</h3>
									<p className="text-zinc-300 text-sm leading-relaxed">
										To empower artists with the tools, exposure, and support they need to build successful careers in the digital music landscape.
									</p>
								</div>

								{/* Location */}
								<div className="space-y-2">
									<h3 className="text-[#BFFF00] font-semibold text-sm uppercase tracking-wider">Our Location</h3>
									<div className="flex items-start gap-2">
										<svg className="size-4 text-[#BFFF00] mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
											<path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
										</svg>
										<p className="text-zinc-300 text-sm">Makindye - Luwafu, Kampala UG</p>
									</div>
								</div>

								{/* Contact Info */}
								<div className="bg-zinc-800/50 rounded-lg p-3 sm:p-4 border border-zinc-700/50 space-y-3">
									<h3 className="text-[#BFFF00] font-semibold text-sm uppercase tracking-wider">Contact Us</h3>
									<div className="space-y-2">
										{/* WhatsApp/Call */}
										<div className="flex items-center gap-2">
											<svg className="size-4 text-[#25D366] flex-shrink-0" viewBox="0 0 24 24" fill="currentColor">
												<path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
											</svg>
											<a href="https://wa.me/256701705378" className="text-zinc-300 text-sm hover:text-[#BFFF00] transition-colors">
												WhatsApp/Call: 0701705378
											</a>
										</div>
										{/* Email */}
										<div className="flex items-center gap-2">
											<svg className="size-4 text-[#BFFF00] flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
												<path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
											</svg>
											<a href="mailto:clients@troydigitaldesk.com" className="text-zinc-300 text-sm hover:text-[#BFFF00] transition-colors break-all">
												clients@troydigitaldesk.com
											</a>
										</div>
										{/* Gmail */}
										<div className="flex items-center gap-2">
											<svg className="size-4 text-[#EA4335] flex-shrink-0" viewBox="0 0 24 24" fill="currentColor">
												<path d="M24 5.457v13.909c0 .904-.732 1.636-1.636 1.636h-3.819V11.73L12 16.64l-6.545-4.91v9.273H1.636A1.636 1.636 0 010 19.366V5.457c0-2.023 2.309-3.178 3.927-1.964L5.455 4.64 12 9.548l6.545-4.91 1.528-1.145C21.69 2.28 24 3.434 24 5.457z"/>
											</svg>
											<a href="mailto:tunevomedia@gmail.com" className="text-zinc-300 text-sm hover:text-[#BFFF00] transition-colors">
												tunevomedia@gmail.com
											</a>
										</div>
									</div>
									<p className="text-zinc-500 text-xs pt-1 border-t border-zinc-700/50">
										Ready to take your music to the next level? Click "Talk to Us" to start your journey!
									</p>
								</div>

								{/* Back to Home Button */}
								<Link
									to="/"
									onClick={() => setActiveDialog(null)}
									className="mt-4 flex items-center justify-center gap-2 w-full py-2.5 bg-zinc-800/50 hover:bg-zinc-800 border border-zinc-700/50 hover:border-[#BFFF00]/50 rounded-lg text-zinc-400 hover:text-[#BFFF00] transition-all text-sm"
								>
									<ChevronLeft className="size-4" />
									Back to Home
								</Link>
							</div>
						) : currentDialogConfig?.showDjSubmissionInfo ? (
							<div className="py-2 sm:py-4 space-y-3 sm:space-y-5">
								{/* How It Works */}
								<div className="space-y-2">
									<h3 className="text-[#BFFF00] font-semibold text-sm uppercase tracking-wider">How It Works</h3>
									<p className="text-zinc-300 text-sm leading-relaxed">
										Submit your track and our team will review it, develop a customized promotion approach, and distribute your music to our network of over <span className="text-[#BFFF00] font-semibold">2,000+ DJs</span> across multiple genres worldwide.
									</p>
								</div>

								{/* Supported Genres */}
								<div className="space-y-2">
									<h3 className="text-[#BFFF00] font-semibold text-sm uppercase tracking-wider">Supported Genres</h3>
									<div className="flex flex-wrap gap-1.5">
										{["Afro House", "Bass House", "Dance Pop", "Deep House", "Jackin House", "Future House", "House", "Indie Dance", "Melodic House & Techno", "Minimal Deep Tech", "Nu Disco", "Disco House", "Progressive House", "Tech House", "Techno", "Afrobeats", "Amapiano"].map((genre) => (
											<span key={genre} className="px-2 py-0.5 bg-zinc-800/70 border border-zinc-700/50 rounded text-[10px] sm:text-xs text-zinc-300">
												{genre}
											</span>
										))}
									</div>
								</div>

								{/* What You Need to Submit */}
								<div className="space-y-2">
									<h3 className="text-[#BFFF00] font-semibold text-sm uppercase tracking-wider">What You Need to Submit</h3>
									<ul className="space-y-1.5 text-sm text-zinc-300">
										<li className="flex items-start gap-2">
											<svg className="size-4 text-[#BFFF00] mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
												<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
											</svg>
											<span>Your full name & contact details</span>
										</li>
										<li className="flex items-start gap-2">
											<svg className="size-4 text-[#BFFF00] mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
												<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
											</svg>
											<span>Artist name & track title</span>
										</li>
										<li className="flex items-start gap-2">
											<svg className="size-4 text-[#BFFF00] mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
												<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
											</svg>
											<span>Music genre classification</span>
										</li>
										<li className="flex items-start gap-2">
											<svg className="size-4 text-[#BFFF00] mt-0.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
												<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
											</svg>
											<span>Track link (SoundCloud, Dropbox, or Drive)</span>
										</li>
									</ul>
								</div>

								{/* Available Services */}
								<div className="space-y-2">
									<h3 className="text-[#BFFF00] font-semibold text-sm uppercase tracking-wider">Available Services</h3>
									<div className="grid grid-cols-1 gap-2">
										<div className="flex items-center gap-2 p-2 bg-zinc-800/50 rounded-lg border border-zinc-700/50">
											<div className="size-8 bg-[#BFFF00]/10 rounded-lg flex items-center justify-center">
												<svg className="size-4 text-[#BFFF00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
													<path strokeLinecap="round" strokeLinejoin="round" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
												</svg>
											</div>
											<div className="flex-1">
												<p className="text-sm font-medium text-white">DJ Promotional Campaigns</p>
												<p className="text-[10px] text-zinc-400">Get your track played by top DJs</p>
											</div>
										</div>
										<div className="flex items-center gap-2 p-2 bg-zinc-800/50 rounded-lg border border-zinc-700/50">
											<div className="size-8 bg-[#1DB954]/10 rounded-lg flex items-center justify-center">
												<svg className="size-4 text-[#1DB954]" viewBox="0 0 24 24" fill="currentColor">
													<path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/>
												</svg>
											</div>
											<div className="flex-1">
												<p className="text-sm font-medium text-white">Spotify & Apple Music Promotion</p>
												<p className="text-[10px] text-zinc-400">Algorithmic playlist promotion</p>
											</div>
										</div>
										<div className="flex items-center gap-2 p-2 bg-zinc-800/50 rounded-lg border border-zinc-700/50">
											<div className="size-8 bg-purple-500/10 rounded-lg flex items-center justify-center">
												<svg className="size-4 text-purple-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
													<path strokeLinecap="round" strokeLinejoin="round" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
												</svg>
											</div>
											<div className="flex-1">
												<p className="text-sm font-medium text-white">Remix Services</p>
												<p className="text-[10px] text-zinc-400">Professional remix production</p>
											</div>
										</div>
										<div className="flex items-center gap-2 p-2 bg-zinc-800/50 rounded-lg border border-zinc-700/50">
											<div className="size-8 bg-orange-500/10 rounded-lg flex items-center justify-center">
												<svg className="size-4 text-orange-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
													<path strokeLinecap="round" strokeLinejoin="round" d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
												</svg>
											</div>
											<div className="flex-1">
												<p className="text-sm font-medium text-white">Press Release & Artwork</p>
												<p className="text-[10px] text-zinc-400">Professional PR & design</p>
											</div>
										</div>
									</div>
								</div>

								{/* CTA */}
								<div className="bg-gradient-to-r from-[#BFFF00]/10 to-zinc-800/50 rounded-lg p-3 sm:p-4 border border-[#BFFF00]/30">
									<p className="text-sm text-zinc-300 mb-3">Ready to get your music in front of top DJs worldwide?</p>
									<a
										href="https://wa.me/256701705378?text=Hi!%20I'd%20like%20to%20submit%20my%20music%20to%20DJs.%20Here%20are%20my%20details:%0A%0AName:%20%0AArtist%20Name:%20%0ATrack%20Title:%20%0AGenre:%20%0ATrack%20Link:%20"
										target="_blank"
										rel="noopener noreferrer"
										className="inline-flex items-center gap-2 bg-[#BFFF00] hover:bg-[#a8e600] text-zinc-900 font-semibold px-4 py-2 rounded-lg transition-all text-sm"
									>
										<svg className="size-4" viewBox="0 0 24 24" fill="currentColor">
											<path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
										</svg>
										Submit via WhatsApp
									</a>
								</div>

								{/* Back to Home Button */}
								<Link
									to="/"
									onClick={() => setActiveDialog(null)}
									className="mt-4 flex items-center justify-center gap-2 w-full py-2.5 bg-zinc-800/50 hover:bg-zinc-800 border border-zinc-700/50 hover:border-[#BFFF00]/50 rounded-lg text-zinc-400 hover:text-[#BFFF00] transition-all text-sm"
								>
									<ChevronLeft className="size-4" />
									Back to Home
								</Link>
							</div>
						) : activeDialog === "radio-stations" ? (
							<div className="py-2 sm:py-4 space-y-3 sm:space-y-4">
								{/* Intro */}
								<div className="text-center mb-4">
									<p className="text-zinc-400 text-xs sm:text-sm">
										Click on any station to listen live on OnlineRadioBox
									</p>
								</div>

								{/* Radio Stations Grid */}
								<div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3 max-h-[50vh] overflow-y-auto pr-1 [&::-webkit-scrollbar]:w-1 [&::-webkit-scrollbar-thumb]:bg-zinc-700 [&::-webkit-scrollbar-thumb]:rounded-full">
									{ugandaRadioStations.map((station, idx) => (
										<a
											key={idx}
											href={station.url}
											target="_blank"
											rel="noopener noreferrer"
											className="flex items-center gap-3 p-3 bg-zinc-800/50 hover:bg-zinc-800 border border-zinc-700/50 hover:border-[#BFFF00]/50 rounded-lg transition-all group"
										>
											{/* Radio Icon */}
											<div className="size-10 sm:size-12 bg-gradient-to-br from-[#BFFF00]/20 to-[#BFFF00]/5 rounded-lg flex items-center justify-center flex-shrink-0 group-hover:from-[#BFFF00]/30 group-hover:to-[#BFFF00]/10 transition-all">
												<svg className="size-5 sm:size-6 text-[#BFFF00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
													<path strokeLinecap="round" strokeLinejoin="round" d="M5.636 18.364a9 9 0 010-12.728m12.728 0a9 9 0 010 12.728m-9.9-2.829a5 5 0 010-7.07m7.072 0a5 5 0 010 7.07M13 12a1 1 0 11-2 0 1 1 0 012 0z" />
												</svg>
											</div>
											{/* Station Info */}
											<div className="min-w-0 flex-1">
												<div className="font-semibold text-white text-sm group-hover:text-[#BFFF00] transition-colors truncate">
													{station.name}
												</div>
												<div className="flex items-center gap-2 text-xs text-zinc-400">
													<span className="text-[#BFFF00] font-medium">{station.frequency}</span>
													<span className="text-zinc-600">•</span>
													<span className="truncate">{station.genre}</span>
												</div>
											</div>
											{/* Play Icon */}
											<div className="size-8 bg-[#BFFF00]/10 rounded-full flex items-center justify-center group-hover:bg-[#BFFF00]/20 transition-all flex-shrink-0">
												<svg className="size-4 text-[#BFFF00] ml-0.5" fill="currentColor" viewBox="0 0 24 24">
													<path d="M8 5v14l11-7z"/>
												</svg>
											</div>
										</a>
									))}
								</div>

								{/* View All Link */}
								<div className="text-center pt-2 border-t border-zinc-700/50">
									<a
										href="https://onlineradiobox.com/ug/"
										target="_blank"
										rel="noopener noreferrer"
										className="inline-flex items-center gap-2 text-sm text-[#BFFF00] hover:underline"
									>
										View all Uganda radio stations
										<svg className="size-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
											<path strokeLinecap="round" strokeLinejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
										</svg>
									</a>
								</div>

								{/* Back to Home Button */}
								<Link
									to="/"
									onClick={() => setActiveDialog(null)}
									className="flex items-center justify-center gap-2 w-full py-2.5 bg-zinc-800/50 hover:bg-zinc-800 border border-zinc-700/50 hover:border-[#BFFF00]/50 rounded-lg text-zinc-400 hover:text-[#BFFF00] transition-all text-sm"
								>
									<ChevronLeft className="size-4" />
									Back to Home
								</Link>
							</div>
						) : currentDialogConfig?.showMusicSubmissionForm ? (
							<form onSubmit={handleSubmit} className="space-y-3 sm:space-y-4">
								{/* Full Name & Contact Details */}
								<div className="space-y-1 sm:space-y-2">
									<Label htmlFor="music-name" className="text-xs sm:text-sm text-zinc-300">
										Full Name
									</Label>
									<Input
										id="music-name"
										type="text"
										placeholder="Your full name"
										value={formData.name}
										onChange={(e) => setFormData({ ...formData, name: e.target.value })}
										required
										className="bg-zinc-800/50 border-zinc-600 text-white placeholder:text-zinc-500 focus:border-[#BFFF00] focus:ring-[#BFFF00]/20 h-9 sm:h-10 text-sm"
									/>
								</div>

								<div className="grid grid-cols-2 gap-2 sm:gap-3">
									<div className="space-y-1 sm:space-y-2">
										<Label htmlFor="music-phone" className="text-xs sm:text-sm text-zinc-300">
											Phone
										</Label>
										<Input
											id="music-phone"
											type="tel"
											placeholder="Phone number"
											value={formData.phone}
											onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
											required
											className="bg-zinc-800/50 border-zinc-600 text-white placeholder:text-zinc-500 focus:border-[#BFFF00] focus:ring-[#BFFF00]/20 h-9 sm:h-10 text-sm"
										/>
									</div>
									<div className="space-y-1 sm:space-y-2">
										<Label htmlFor="music-email" className="text-xs sm:text-sm text-zinc-300">
											Email
										</Label>
										<Input
											id="music-email"
											type="email"
											placeholder="Your email"
											value={formData.email}
											onChange={(e) => setFormData({ ...formData, email: e.target.value })}
											required
											className="bg-zinc-800/50 border-zinc-600 text-white placeholder:text-zinc-500 focus:border-[#BFFF00] focus:ring-[#BFFF00]/20 h-9 sm:h-10 text-sm"
										/>
									</div>
								</div>

								{/* Artist Name & Track Title */}
								<div className="grid grid-cols-2 gap-2 sm:gap-3">
									<div className="space-y-1 sm:space-y-2">
										<Label htmlFor="music-artist" className="text-xs sm:text-sm text-zinc-300">
											Artist Name
										</Label>
										<Input
											id="music-artist"
											type="text"
											placeholder="Artist/Stage name"
											value={formData.artistName}
											onChange={(e) => setFormData({ ...formData, artistName: e.target.value })}
											required
											className="bg-zinc-800/50 border-zinc-600 text-white placeholder:text-zinc-500 focus:border-[#BFFF00] focus:ring-[#BFFF00]/20 h-9 sm:h-10 text-sm"
										/>
									</div>
									<div className="space-y-1 sm:space-y-2">
										<Label htmlFor="music-track" className="text-xs sm:text-sm text-zinc-300">
											Track Title
										</Label>
										<Input
											id="music-track"
											type="text"
											placeholder="Song title"
											value={formData.trackTitle}
											onChange={(e) => setFormData({ ...formData, trackTitle: e.target.value })}
											required
											className="bg-zinc-800/50 border-zinc-600 text-white placeholder:text-zinc-500 focus:border-[#BFFF00] focus:ring-[#BFFF00]/20 h-9 sm:h-10 text-sm"
										/>
									</div>
								</div>

								{/* Music Genre */}
								<div className="space-y-1 sm:space-y-2">
									<Label htmlFor="music-genre" className="text-xs sm:text-sm text-zinc-300">
										Music Genre
									</Label>
									<Select
										value={formData.musicGenre}
										onValueChange={(value) => setFormData({ ...formData, musicGenre: value })}
									>
										<SelectTrigger className="bg-zinc-800/50 border-zinc-600 text-white focus:border-[#BFFF00] focus:ring-[#BFFF00]/20 h-9 sm:h-10 text-sm">
											<SelectValue placeholder="Select genre" />
										</SelectTrigger>
										<SelectContent className="bg-zinc-800 border-zinc-700">
											<SelectItem value="afrobeats">Afrobeats</SelectItem>
											<SelectItem value="amapiano">Amapiano</SelectItem>
											<SelectItem value="hiphop">Hip Hop / Rap</SelectItem>
											<SelectItem value="rnb">R&B / Soul</SelectItem>
											<SelectItem value="dancehall">Dancehall / Reggae</SelectItem>
											<SelectItem value="afropop">Afropop</SelectItem>
											<SelectItem value="gospel">Gospel</SelectItem>
											<SelectItem value="edm">EDM / Electronic</SelectItem>
											<SelectItem value="house">House / Deep House</SelectItem>
											<SelectItem value="pop">Pop</SelectItem>
											<SelectItem value="other">Other</SelectItem>
										</SelectContent>
									</Select>
								</div>

								{/* Track Link */}
								<div className="space-y-1 sm:space-y-2">
									<Label htmlFor="music-link" className="text-xs sm:text-sm text-zinc-300">
										Track Link
									</Label>
									<Input
										id="music-link"
										type="url"
										placeholder="SoundCloud, Dropbox, or Google Drive link"
										value={formData.trackLink}
										onChange={(e) => setFormData({ ...formData, trackLink: e.target.value })}
										required
										className="bg-zinc-800/50 border-zinc-600 text-white placeholder:text-zinc-500 focus:border-[#BFFF00] focus:ring-[#BFFF00]/20 h-9 sm:h-10 text-sm"
									/>
									<p className="text-[10px] text-zinc-500">Accepted: SoundCloud, Dropbox, Google Drive links</p>
								</div>

								{/* Submit Button */}
								<Button
									type="submit"
									disabled={isSubmitting}
									className="w-full bg-[#BFFF00] hover:bg-[#a8e600] text-zinc-900 font-semibold h-10 sm:h-11 text-sm sm:text-base transition-all disabled:opacity-50"
								>
									{isSubmitting ? (
										<div className="flex items-center gap-2">
											<div className="size-4 border-2 border-zinc-900/30 border-t-zinc-900 rounded-full animate-spin" />
											Submitting...
										</div>
									) : (
										<div className="flex items-center gap-2">
											<Send className="size-4" />
											{currentDialogConfig.submitText}
										</div>
									)}
								</Button>

								{/* Back to Home Button */}
								<Link
									to="/"
									onClick={() => setActiveDialog(null)}
									className="mt-3 flex items-center justify-center gap-2 w-full py-2.5 bg-zinc-800/50 hover:bg-zinc-800 border border-zinc-700/50 hover:border-[#BFFF00]/50 rounded-lg text-zinc-400 hover:text-[#BFFF00] transition-all text-sm"
								>
									<ChevronLeft className="size-4" />
									Back to Home
								</Link>
							</form>
						) : submitted ? (
							<div className="text-center py-4 sm:py-8">
								<div className="size-12 sm:size-16 mx-auto mb-3 sm:mb-4 bg-[#BFFF00]/20 rounded-full flex items-center justify-center">
									<svg className="size-6 sm:size-8 text-[#BFFF00]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
										<path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
									</svg>
								</div>
								<h3 className="text-base sm:text-lg font-semibold text-[#BFFF00] mb-1 sm:mb-2">Thank You!</h3>
								<p className="text-zinc-400 text-xs sm:text-sm">Your inquiry has been submitted successfully.</p>

								{/* Back to Home Button */}
								<Link
									to="/"
									onClick={() => setActiveDialog(null)}
									className="mt-4 inline-flex items-center justify-center gap-2 px-6 py-2.5 bg-zinc-800/50 hover:bg-zinc-800 border border-zinc-700/50 hover:border-[#BFFF00]/50 rounded-lg text-zinc-400 hover:text-[#BFFF00] transition-all text-sm"
								>
									<ChevronLeft className="size-4" />
									Back to Home
								</Link>
							</div>
						) : (
							<form onSubmit={handleSubmit} className="space-y-2.5 sm:space-y-4">
								{/* Name Field */}
								<div className="space-y-1 sm:space-y-2">
									<Label htmlFor="dialog-name" className="text-xs sm:text-sm text-zinc-300">
										Name
									</Label>
									<Input
										id="dialog-name"
										type="text"
										placeholder="Your full name"
										value={formData.name}
										onChange={(e) => setFormData({ ...formData, name: e.target.value })}
										required
										className="bg-zinc-800/50 border-zinc-600 text-white placeholder:text-zinc-500 focus:border-[#BFFF00] focus:ring-[#BFFF00]/20 h-9 sm:h-10 text-sm"
									/>
								</div>

								{/* Phone Number Field */}
								<div className="space-y-1 sm:space-y-2">
									<Label htmlFor="dialog-phone" className="text-xs sm:text-sm text-zinc-300">
										Phone Number
									</Label>
									<Input
										id="dialog-phone"
										type="tel"
										placeholder="+256 700 000 000"
										value={formData.phone}
										onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
										required
										className="bg-zinc-800/50 border-zinc-600 text-white placeholder:text-zinc-500 focus:border-[#BFFF00] focus:ring-[#BFFF00]/20 h-9 sm:h-10 text-sm"
									/>
								</div>

								{/* Email Field */}
								<div className="space-y-1 sm:space-y-2">
									<Label htmlFor="dialog-email" className="text-xs sm:text-sm text-zinc-300">
										Email Address
									</Label>
									<Input
										id="dialog-email"
										type="email"
										placeholder="your@email.com"
										value={formData.email}
										onChange={(e) => setFormData({ ...formData, email: e.target.value })}
										required
										className="bg-zinc-800/50 border-zinc-600 text-white placeholder:text-zinc-500 focus:border-[#BFFF00] focus:ring-[#BFFF00]/20 h-9 sm:h-10 text-sm"
									/>
								</div>

								{/* Consultation About Field - Only shown for inquiry dialog */}
								{currentDialogConfig?.showServices && (
									<div className="space-y-1 sm:space-y-2">
										<Label htmlFor="dialog-consultation" className="text-xs sm:text-sm text-zinc-300">
											Consultation About
										</Label>
										<Select
											value={formData.consultationAbout}
											onValueChange={(value) => setFormData({ ...formData, consultationAbout: value })}
											required
										>
											<SelectTrigger className="bg-zinc-800/50 border-zinc-600 text-white focus:border-[#BFFF00] focus:ring-[#BFFF00]/20 h-9 sm:h-10 text-sm">
												<SelectValue placeholder="Select a service" />
											</SelectTrigger>
											<SelectContent className="bg-zinc-900 border-zinc-700">
												{services.map((service) => (
													<SelectItem
														key={service.slug}
														value={service.slug}
														className="text-white hover:bg-zinc-800 focus:bg-zinc-800 focus:text-[#BFFF00] text-sm"
													>
														{service.name}
													</SelectItem>
												))}
											</SelectContent>
										</Select>
									</div>
								)}

								{/* Submission Fields - Only shown for mainstream, playlists, submit-to-djs */}
								{currentDialogConfig?.showSubmissionFields && (
									<>
										{/* File Upload Field - Multiple Files */}
										<div className="space-y-1 sm:space-y-2">
											<Label htmlFor="dialog-file" className="text-xs sm:text-sm text-zinc-300">
												Upload Track/Video <span className="text-zinc-500 text-[10px] sm:text-xs">(multiple allowed)</span>
											</Label>
											<div className="relative">
												<Input
													id="dialog-file"
													type="file"
													multiple
													accept=".mp3,.wav,.flac,.aif,.aiff,.mp4,.mov,.vob,.mkv,audio/*,video/*"
													onChange={(e) => {
														const selectedFiles = Array.from(e.target.files || []);
														const maxSize = 4 * 1024 * 1024 * 1024; // 4GB in bytes
														const validFiles: File[] = [];
														const oversizedFiles: string[] = [];

														for (const file of selectedFiles) {
															if (file.size > maxSize) {
																oversizedFiles.push(file.name);
															} else {
																validFiles.push(file);
															}
														}

														if (oversizedFiles.length > 0) {
															alert(`The following files exceed 4GB limit and were not added:\n${oversizedFiles.join("\n")}`);
														}

														setFormData({ ...formData, files: [...formData.files, ...validFiles] });
													}}
													className="bg-zinc-800/50 border-zinc-600 text-white file:bg-[#BFFF00] file:text-zinc-900 file:border-0 file:rounded-full file:px-2 sm:file:px-4 file:py-1 sm:file:py-1.5 file:mr-2 sm:file:mr-3 file:font-medium file:text-[10px] sm:file:text-xs hover:file:bg-[#a8e600] file:cursor-pointer focus:border-[#BFFF00] focus:ring-[#BFFF00]/20 h-9 sm:h-10 text-xs sm:text-sm"
												/>
											</div>
											<p className="text-[9px] sm:text-[10px] text-zinc-500">
												Audio: mp3, wav, flac, aif | Video: mp4, mov, vob, mkv | Max: 4GB each
											</p>
											{formData.files.length > 0 && (
												<div className="space-y-0.5 sm:space-y-1">
													<p className="text-[10px] sm:text-xs text-[#BFFF00]">Selected files ({formData.files.length}):</p>
													{formData.files.map((file, index) => (
														<div key={index} className="flex items-center justify-between text-[10px] sm:text-xs text-zinc-400 bg-zinc-800/50 rounded px-1.5 sm:px-2 py-0.5 sm:py-1">
															<span className="truncate flex-1">{file.name}</span>
															<button
																type="button"
																onClick={() => setFormData({ ...formData, files: formData.files.filter((_, i) => i !== index) })}
																className="ml-2 text-red-400 hover:text-red-300"
															>
																×
															</button>
														</div>
													))}
												</div>
											)}
										</div>

										{/* URL Submission Fields - Multiple URLs */}
										<div className="space-y-1 sm:space-y-2">
											<Label className="text-xs sm:text-sm text-zinc-300">
												Music URLs <span className="text-zinc-500 text-[10px] sm:text-xs">(Spotify, Audiomack, YouTube, etc.)</span>
											</Label>
											{formData.urls.map((url, index) => (
												<div key={index} className="flex gap-1.5 sm:gap-2">
													<Input
														id={`dialog-url-${index}`}
														type="url"
														placeholder="https://open.spotify.com/track/..."
														value={url}
														onChange={(e) => {
															const newUrls = [...formData.urls];
															newUrls[index] = e.target.value;
															setFormData({ ...formData, urls: newUrls });
														}}
														className="bg-zinc-800/50 border-zinc-600 text-white placeholder:text-zinc-500 focus:border-[#BFFF00] focus:ring-[#BFFF00]/20 flex-1 h-9 sm:h-10 text-xs sm:text-sm"
													/>
													{formData.urls.length > 1 && (
														<button
															type="button"
															onClick={() => setFormData({ ...formData, urls: formData.urls.filter((_, i) => i !== index) })}
															className="px-1.5 sm:px-2 text-red-400 hover:text-red-300 text-base sm:text-lg"
														>
															×
														</button>
													)}
												</div>
											))}
											<button
												type="button"
												onClick={() => setFormData({ ...formData, urls: [...formData.urls, ""] })}
												className="text-[10px] sm:text-xs text-[#BFFF00] hover:text-[#a8e600] flex items-center gap-1"
											>
												<span>+</span> Add another URL
											</button>
										</div>

										{/* Budget Slider Field */}
										<div className="space-y-2 sm:space-y-3">
											<Label htmlFor="dialog-budget" className="text-xs sm:text-sm text-zinc-300">
												Budget
											</Label>
											<Slider
												id="dialog-budget"
												min={50}
												max={1000}
												step={10}
												value={[Math.min(formData.budget, 1000)]}
												onValueChange={(value) => setFormData({ ...formData, budget: value[0] })}
												className="w-full [&_[data-slot=slider-track]]:bg-zinc-700 [&_[data-slot=slider-range]]:bg-[#BFFF00] [&_[data-slot=slider-thumb]]:border-[#BFFF00] [&_[data-slot=slider-thumb]]:bg-zinc-900"
											/>
											<div className="flex justify-between text-[10px] sm:text-xs text-zinc-500">
												<span>$50</span>
												<button
													type="button"
													onClick={() => {
														const customBudget = prompt("Enter your custom budget (USD):", String(formData.budget));
														if (customBudget !== null) {
															const parsed = parseInt(customBudget, 10);
															if (!isNaN(parsed) && parsed >= 50) {
																setFormData({ ...formData, budget: parsed });
															} else if (!isNaN(parsed) && parsed < 50) {
																alert("Minimum budget is $50");
															}
														}
													}}
													className="text-[#BFFF00] hover:text-[#a8e600] underline cursor-pointer"
												>
													$1000+
												</button>
											</div>

											{/* Grand Total Display */}
											<div className="bg-zinc-800/70 rounded-lg p-2 sm:p-3 mt-1 sm:mt-2 border border-zinc-700">
												<p className="text-[10px] sm:text-xs text-zinc-400 mb-0.5 sm:mb-1">Grand Total</p>
												<p className="text-base sm:text-xl font-bold text-[#BFFF00]">${formData.budget.toLocaleString()} USD</p>
												<p className="text-xs sm:text-sm text-zinc-300">UGX {(formData.budget * 3750).toLocaleString()}</p>
											</div>
										</div>
									</>
								)}

								{/* Message Field */}
								<div className="space-y-1 sm:space-y-2">
									<Label htmlFor="dialog-message" className="text-xs sm:text-sm text-zinc-300">
										{currentDialogConfig?.messageLabel ?? "Message"} <span className="text-zinc-500 text-[10px] sm:text-xs">(min. 20 characters)</span>
									</Label>
									<Textarea
										id="dialog-message"
										placeholder={currentDialogConfig?.messagePlaceholder ?? "Tell us more about your project, goals, and any specific requirements you have..."}
										value={formData.message}
										onChange={(e) => setFormData({ ...formData, message: e.target.value })}
										required
										minLength={20}
										rows={3}
										className="bg-zinc-800/50 border-zinc-600 text-white placeholder:text-zinc-500 focus:border-[#BFFF00] focus:ring-[#BFFF00]/20 resize-none text-sm sm:text-base min-h-[60px] sm:min-h-[80px]"
									/>
									<p className="text-[10px] sm:text-xs text-zinc-500 text-right">
										{formData.message.length}/20 characters
									</p>
								</div>

								{/* Submit Button */}
								<Button
									type="submit"
									disabled={isSubmitting}
									className="w-full bg-[#BFFF00] hover:bg-[#a8e600] text-zinc-900 font-semibold py-2 sm:py-3 rounded-lg transition-all duration-200 hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed mt-1 sm:mt-2 text-sm sm:text-base h-9 sm:h-11"
								>
									{isSubmitting ? (
										<span className="flex items-center justify-center gap-1.5 sm:gap-2">
											<svg className="animate-spin size-3 sm:size-4" viewBox="0 0 24 24" fill="none">
												<circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
												<path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
											</svg>
											Submitting...
										</span>
									) : (
										<span className="flex items-center justify-center gap-1.5 sm:gap-2">
											<Send className="size-3 sm:size-4" />
											{currentDialogConfig?.submitText ?? "Submit Inquiry"}
										</span>
									)}
								</Button>

								{/* Back to Home Button */}
								<Link
									to="/"
									onClick={() => setActiveDialog(null)}
									className="mt-3 flex items-center justify-center gap-2 w-full py-2.5 bg-zinc-800/50 hover:bg-zinc-800 border border-zinc-700/50 hover:border-[#BFFF00]/50 rounded-lg text-zinc-400 hover:text-[#BFFF00] transition-all text-sm"
								>
									<ChevronLeft className="size-4" />
									Back to Home
								</Link>
							</form>
						)}
						</div>
					</DialogContent>
				</Dialog>

				{/* Clients Carousel - Above Footer - Text by default, thumbnail on hover */}
				<div className="relative overflow-hidden bg-zinc-900/50 border-t border-white/5">
					{/* Gradient overlays for smooth edges */}
					<div className="absolute left-0 top-0 bottom-0 w-8 sm:w-12 lg:w-16 bg-gradient-to-r from-zinc-950 to-transparent z-10 pointer-events-none" />
					<div className="absolute right-0 top-0 bottom-0 w-8 sm:w-12 lg:w-16 bg-gradient-to-l from-zinc-950 to-transparent z-10 pointer-events-none" />

					{/* Scrolling container - Reverse direction */}
					<div className="flex items-center animate-scroll-reverse py-2 sm:py-2.5 lg:py-3">
						{/* First set of items */}
						{clients.map((item, index) => (
							<div
								key={`client-first-${index}`}
								className="flex-shrink-0 mx-2.5 sm:mx-3 lg:mx-4 group cursor-pointer relative h-8 sm:h-9 lg:h-10 flex items-center"
							>
								{/* Text content - visible by default, hidden on hover */}
								<div className="flex items-center gap-1.5 sm:gap-2 group-hover:opacity-0 transition-opacity duration-300">
									<span className="text-[#BFFF00] text-[10px] sm:text-xs">•</span>
									<div className="flex flex-col">
										<p className="text-[10px] sm:text-xs lg:text-sm text-white font-medium whitespace-nowrap">{item.name}</p>
										<p className="text-[8px] sm:text-[10px] lg:text-xs text-zinc-500">{item.category}</p>
									</div>
								</div>
								{/* Thumbnail - hidden by default, visible on hover */}
								<div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
									<div className="size-8 sm:size-9 lg:size-10 rounded-full overflow-hidden border-[1.5px] sm:border-2 border-[#BFFF00] shadow-md shadow-[#BFFF00]/30">
										<img
											src={item.image}
											alt={item.name}
											className="w-full h-full object-cover"
										/>
									</div>
								</div>
							</div>
						))}
						{/* Duplicate set for seamless loop */}
						{clients.map((item, index) => (
							<div
								key={`client-second-${index}`}
								className="flex-shrink-0 mx-2.5 sm:mx-3 lg:mx-4 group cursor-pointer relative h-8 sm:h-9 lg:h-10 flex items-center"
							>
								{/* Text content - visible by default, hidden on hover */}
								<div className="flex items-center gap-1.5 sm:gap-2 group-hover:opacity-0 transition-opacity duration-300">
									<span className="text-[#BFFF00] text-[10px] sm:text-xs">•</span>
									<div className="flex flex-col">
										<p className="text-[10px] sm:text-xs lg:text-sm text-white font-medium whitespace-nowrap">{item.name}</p>
										<p className="text-[8px] sm:text-[10px] lg:text-xs text-zinc-500">{item.category}</p>
									</div>
								</div>
								{/* Thumbnail - hidden by default, visible on hover */}
								<div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
									<div className="size-8 sm:size-9 lg:size-10 rounded-full overflow-hidden border-[1.5px] sm:border-2 border-[#BFFF00] shadow-md shadow-[#BFFF00]/30">
										<img
											src={item.image}
											alt={item.name}
											className="w-full h-full object-cover"
										/>
									</div>
								</div>
							</div>
						))}
					</div>
				</div>

				{/* Layer 9: Footer */}
				<footer className="border-t border-white/10 px-2 sm:px-4 lg:px-8 py-1.5 sm:py-2 lg:py-2.5">
					<div className="flex flex-col sm:flex-row items-center justify-between gap-1.5 sm:gap-2 max-w-7xl mx-auto">
						{/* Page Links */}
						<nav className="flex items-center gap-1.5 sm:gap-2 lg:gap-3 text-[10px] sm:text-xs lg:text-sm">
							<button
								onClick={() => setActiveDialog("about-us")}
								className="text-zinc-400 hover:text-[#BFFF00] transition-colors cursor-pointer px-0.5"
							>
								About Us
							</button>
							<span className="text-zinc-600 text-[8px] sm:text-xs">|</span>
							<button
								onClick={() => setActiveDialog("radio-stations")}
								className="text-zinc-400 hover:text-[#BFFF00] transition-colors cursor-pointer px-0.5"
							>
								Radio Stations
							</button>
							<span className="text-zinc-600 text-[8px] sm:text-xs">|</span>
							<button
								onClick={() => setActiveDialog("playlists")}
								className="text-zinc-400 hover:text-[#BFFF00] transition-colors cursor-pointer px-0.5"
							>
								Playlists
							</button>
							<span className="text-zinc-600 text-[8px] sm:text-xs">|</span>
							<button
								onClick={() => setActiveDialog("submit-to-djs")}
								className="text-zinc-400 hover:text-[#BFFF00] transition-colors cursor-pointer px-0.5"
							>
								Submit to Djs
							</button>
						</nav>

						<div className="flex items-center gap-1.5 sm:gap-2">
							{/* Talk to Us Button */}
							<button
								onClick={() => setActiveDialog("inquiry")}
								className="px-2 sm:px-3 lg:px-4 py-0.5 sm:py-1 lg:py-1.5 bg-zinc-800 text-zinc-300 text-[8px] sm:text-[10px] lg:text-xs font-medium rounded-full border border-zinc-700 hover:bg-[#BFFF00] hover:text-zinc-900 hover:border-[#BFFF00] hover:scale-105 transition-all duration-200"
							>
								Talk to Us
							</button>

							{/* Arrow Button */}
							<div className="size-5 sm:size-6 lg:size-7 bg-[#BFFF00] rounded-full flex items-center justify-center cursor-pointer hover:scale-110 transition-transform">
								<ChevronDown className="size-2.5 sm:size-3 lg:size-3.5 text-zinc-900 rotate-[-90deg]" />
							</div>
						</div>
					</div>
				</footer>

				{/* WhatsApp Channel Popup */}
				{showWhatsAppPopup && (
					<div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in duration-300">
						<div className="relative bg-zinc-900 border border-zinc-700 rounded-2xl p-6 sm:p-8 max-w-sm w-full shadow-2xl shadow-[#25D366]/20 animate-in zoom-in-95 duration-300">
							{/* Close Button */}
							<button
								onClick={handleWhatsAppPopupClose}
								className="absolute top-3 right-3 p-1.5 rounded-full bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white transition-colors"
							>
								<X className="size-4" />
							</button>

							{/* WhatsApp Icon */}
							<div className="flex justify-center mb-4">
								<div className="size-16 sm:size-20 bg-gradient-to-br from-[#25D366] to-[#128C7E] rounded-full flex items-center justify-center shadow-lg shadow-[#25D366]/30">
									<svg className="size-8 sm:size-10 text-white" viewBox="0 0 24 24" fill="currentColor">
										<path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
									</svg>
								</div>
							</div>

							{/* Content */}
							<div className="text-center">
								<h3 className="text-xl sm:text-2xl font-bold text-white mb-2">
									Follow Our WhatsApp Channel!
								</h3>
								<p className="text-zinc-400 text-sm sm:text-base mb-6">
									Get exclusive updates, music tips, and promotions delivered straight to your WhatsApp.
								</p>

								{/* CTA Button */}
								<button
									onClick={handleWhatsAppChannelClick}
									className="w-full inline-flex items-center justify-center gap-2 bg-gradient-to-r from-[#25D366] to-[#128C7E] hover:from-[#20BD5A] hover:to-[#0E7A6B] text-white font-semibold px-6 py-3 sm:py-4 rounded-full transition-all hover:scale-105 shadow-lg shadow-[#25D366]/30"
								>
									<svg className="size-5" viewBox="0 0 24 24" fill="currentColor">
										<path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
									</svg>
									Follow Channel
								</button>

								{/* Skip Button */}
								<button
									onClick={handleWhatsAppPopupClose}
									className="mt-3 text-zinc-500 hover:text-zinc-300 text-sm transition-colors"
								>
									Maybe later
								</button>
							</div>
						</div>
					</div>
				)}
			</div>
		</div>
	);
}

export type McpServerId = keyof typeof MCP_SERVERS;

// { "mcp-id": { id: string, name: string, url: string } }
export const MCP_SERVERS = {
  "68770d542dee48ccb69d7bcd": {
    "id": "68770d542dee48ccb69d7bcd",
    "name": "Youtube",
    "url": "https://backend.composio.dev/v3/mcp/f29d4eaf-72ac-4234-adc8-9c9f9f8d0e12/mcp?user_id=697542d56161383003f6a91f"
  },
  "686de33a6fd1cae1afbb55b4": {
    "id": "686de33a6fd1cae1afbb55b4",
    "name": "GoogleDocs",
    "url": "https://backend.composio.dev/v3/mcp/ec0e99e9-94b9-49dd-b136-a8a062279c21/mcp?user_id=697542d56161383003f6a91f"
  },
  "68f0a290f81ae7b79782adc9": {
    "id": "68f0a290f81ae7b79782adc9",
    "name": "Firecrawl",
    "url": "https://backend.composio.dev/v3/mcp/6f8c6c8b-f19d-4152-b3ac-3c62f7ff4540/mcp?user_id=697542d56161383003f6a91f"
  },
  "686de5276fd1cae1afbb55be": {
    "id": "686de5276fd1cae1afbb55be",
    "name": "GMAIL",
    "url": "https://backend.composio.dev/v3/mcp/64ddd793-75d0-4c3d-8abf-56c7554f19be/mcp?user_id=697542d56161383003f6a91f"
  },
  "686de4e26fd1cae1afbb55bc": {
    "id": "686de4e26fd1cae1afbb55bc",
    "name": "Github",
    "url": "https://backend.composio.dev/v3/mcp/4e4720cb-01e7-4e14-88f8-3567f0453182/mcp?user_id=697542d56161383003f6a91f"
  }
};